import { motion } from 'framer-motion';
import { Play, Plus, Star, Info, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useTranslationsSafe } from '@/hooks/useTranslationsSafe';
import { useRouter } from 'next/navigation';
import { useNavigationLoading } from '@/hooks/useNavigationLoading';
import { useCourses } from '@/hooks/useCourses';
import Image from 'next/image';
import { useState, useRef, useEffect } from 'react';

export function Hero() {
    const { ref, inView, animationProps } = useScrollAnimation();
    const { t } = useTranslationsSafe('landing');
    const { t: tCourses } = useTranslationsSafe('courses');
    const { t: tCommon } = useTranslationsSafe('common');
    const { locale } = useTranslationsSafe('landing');
    const router = useRouter();
    const { navigateWithLoading, isLoading } = useNavigationLoading();
    const [isMuted, setIsMuted] = useState(true);
    const videoRef = useRef<HTMLVideoElement>(null);

    // Fetch featured course data
    const { courses: featuredCourses, loading } = useCourses({ limit: 1 });
    const featuredCourse = featuredCourses.length > 0 ? featuredCourses[0] : null;

    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.play().catch(error => {
                console.log('Auto-play prevented:', error);
            });
        }
    }, []);

    const toggleMute = () => {
        if (videoRef.current) {
            videoRef.current.muted = !videoRef.current.muted;
            setIsMuted(!isMuted);
        }
    };

    return (
        <section ref={ref} className="relative h-screen w-full flex items-center overflow-hidden">
            {/* Full Screen Background with Parallax */}
            <div className="absolute inset-0 z-0">
                {/* Video Element with Scale Animation */}
                <motion.div
                    initial={{ scale: 1.1 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 10, ease: "easeOut" }}
                    className="absolute inset-0"
                >
                    <video
                        ref={videoRef}
                        className="absolute inset-0 w-full h-full object-cover"
                        autoPlay
                        loop
                        muted={isMuted}
                        playsInline
                        poster={featuredCourse?.thumbnailUrl || 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=1920'}
                    >
                        <source src="/videos/demo/course-promo.mp4" type="video/mp4" />
                    </video>

                    {/* Fallback Image if no video */}
                    {featuredCourse?.thumbnailUrl && (
                        <div className="absolute inset-0 w-full h-full -z-10">
                            <Image
                                src={featuredCourse.thumbnailUrl}
                                alt={featuredCourse.title || 'Featured Course'}
                                fill
                                className="object-cover"
                                priority
                            />
                        </div>
                    )}
                </motion.div>

                {/* Cinematic Vignette - Multiple Gradient Layers */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30" />
                <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
                <div className="absolute bottom-0 left-0 right-0 h-2/3 bg-gradient-to-t from-black via-black/80 to-transparent" />
                
                {/* Animated Purple Glow Effect */}
                <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-transparent to-pink-500/20"
                    animate={{
                        opacity: [0.2, 0.4, 0.2],
                    }}
                    transition={{
                        duration: 4,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                />
            </div>

            {/* Enhanced Control Buttons */}
            <div className="absolute top-24 right-6 z-20 flex gap-3">
                <motion.button
                    onClick={toggleMute}
                    className="p-3 bg-background/50 hover:bg-background/70 backdrop-blur-xl border border-purple-500/30 hover:border-purple-500/60 rounded-xl transition-all duration-300 shadow-lg shadow-purple-500/10"
                    whileHover={{ scale: 1.05, y: -2 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.8 }}
                >
                    {isMuted ? (
                        <VolumeX className="w-5 h-5 text-foreground" />
                    ) : (
                        <Volume2 className="w-5 h-5 text-purple-400" />
                    )}
                </motion.button>
            </div>

            {/* Enhanced Content Section - Centered */}
            <motion.div
                className="relative z-10 w-full px-6 sm:px-8 lg:px-12"
                {...animationProps}
            >
                <div className="max-w-7xl mx-auto">
                    <div className="max-w-3xl">
                        {/* Eyebrow Text */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.2 }}
                            className="flex items-center gap-2 mb-6"
                        >
                            <div className="h-1 w-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
                            <span className="text-purple-400 text-sm font-semibold tracking-wider uppercase">
                                {featuredCourse?.category || tCourses('featuredCourses')}
                            </span>
                            {featuredCourse?.rating && (
                                <>
                                    <span className="text-purple-500">•</span>
                                    <div className="flex items-center gap-1.5">
                                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                        <span className="text-sm font-bold text-yellow-400">{featuredCourse.rating}</span>
                                    </div>
                                </>
                            )}
                        </motion.div>

                        {/* Dramatic Title */}
                        <motion.h1
                            className="text-5xl sm:text-6xl lg:text-7xl font-black mb-6 leading-none"
                            initial={{ opacity: 0, y: 30 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                            transition={{ duration: 0.8, delay: 0.3 }}
                        >
                            <span className="text-foreground drop-shadow-2xl" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.8)' }}>
                                {featuredCourse?.title || t('hero.featuredCourseTitle')}
                            </span>
                        </motion.h1>

                        {/* Description - 3 lines max with better styling */}
                        <motion.p
                            className="text-lg sm:text-xl text-gray-200 mb-6 leading-relaxed line-clamp-3 max-w-2xl"
                            style={{ textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}
                            initial={{ opacity: 0, y: 20 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                            transition={{ duration: 0.6, delay: 0.4 }}
                        >
                            {featuredCourse?.description || t('hero.featuredCourseDescription')}
                        </motion.p>

                        {/* Enhanced Meta Information */}
                        <motion.div
                            className="flex items-center gap-4 mb-8 text-sm font-medium"
                            initial={{ opacity: 0, y: 20 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                            transition={{ duration: 0.6, delay: 0.5 }}
                        >
                            <div className="px-3 py-1 bg-purple-500/20 border border-purple-500/30 rounded-lg text-purple-400">
                                2024
                            </div>
                            {featuredCourse?.duration && (
                                <div className="px-3 py-1 bg-white/10 border border-border rounded-lg text-foreground backdrop-blur-sm">
                                    {Math.floor(featuredCourse.duration / 60)}h {featuredCourse.duration % 60}m
                                </div>
                            )}
                            <div className="px-3 py-1 bg-white/10 border border-border rounded-lg text-foreground backdrop-blur-sm">
                                <span className="font-bold">HD</span>
                            </div>
                            <div className="px-3 py-1 bg-green-500/20 border border-green-500/30 rounded-lg text-green-400">
                                ✓ {t('hero.enrollNow') || 'Available'}
                            </div>
                        </motion.div>

                        {/* Enhanced Action Buttons */}
                        <motion.div
                            className="flex items-center gap-4 flex-wrap"
                            initial={{ opacity: 0, y: 20 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                            transition={{ duration: 0.6, delay: 0.6 }}
                        >
                            <motion.button
                                onClick={() => navigateWithLoading(
                                    featuredCourse ? `/${locale}/courses/${featuredCourse.id}` : `/${locale}/courses`, 
                                    'hero-course-view'
                                )}
                                disabled={isLoading('hero-course-view')}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className="group flex items-center gap-3 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-foreground px-8 py-4 rounded-xl font-bold text-lg shadow-2xl shadow-purple-500/30 transition-all disabled:opacity-50"
                            >
                                {isLoading('hero-course-view') ? (
                                    <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                                ) : (
                                    <Play className="w-6 h-6 fill-white" />
                                )}
                                {t('hero.startWatching') || 'Start Learning'}
                            </motion.button>

                            <motion.button
                                onClick={() => navigateWithLoading(
                                    featuredCourse ? `/${locale}/courses/${featuredCourse.id}` : `/${locale}/courses`, 
                                    'hero-more-info'
                                )}
                                disabled={isLoading('hero-more-info')}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className="flex items-center gap-3 bg-white/10 hover:bg-white/20 backdrop-blur-xl border-2 border-white/30 hover:border-white/50 text-foreground px-8 py-4 rounded-xl font-bold text-lg transition-all disabled:opacity-50"
                            >
                                {isLoading('hero-more-info') ? (
                                    <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                                ) : (
                                    <Info className="w-6 h-6" />
                                )}
                                {tCommon('moreInfo') || 'More Info'}
                            </motion.button>

                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className="w-12 h-12 rounded-full bg-background/40 hover:bg-background/60 backdrop-blur-xl border-2 border-white/30 hover:border-white/50 flex items-center justify-center transition-all"
                            >
                                <Plus className="w-6 h-6 text-foreground" />
                            </motion.button>
                        </motion.div>
                    </div>
                </div>
            </motion.div>

            {/* Scroll Indicator */}
            <motion.div
                className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
            >
                <div className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2">
                    <motion.div
                        className="w-1.5 h-2 bg-background rounded-full"
                        animate={{ y: [0, 12, 0] }}
                        transition={{ duration: 2, repeat: Infinity }}
                    />
                </div>
            </motion.div>
        </section>
    );
}
