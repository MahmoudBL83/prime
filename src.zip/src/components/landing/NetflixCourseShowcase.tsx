'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight, Play, Plus, Heart, Star, Clock, Users, BookOpen, X } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface Course {
    id: string
    title?: string
    titleAr?: string
    description?: string
    descriptionAr?: string
    thumbnail?: string
    category?: string
    categoryAr?: string
    skillLevel?: string
    duration?: number | string
    rating?: number
    instructor?: string
    instructorEn?: string
    studentCount?: number
    isEnrolled?: boolean
    userProgress?: number
}

interface NetflixCourseShowcaseProps {
    title: string
    courses: Course[]
    lang?: string
    onCourseClick?: (courseId: string) => void
}

const SKILL_LEVELS = [
    { id: 'Beginner', name: 'Beginner', nameAr: 'مبتدئ', color: 'bg-green-500' },
    { id: 'Intermediate', name: 'Intermediate', nameAr: 'متوسط', color: 'bg-yellow-500' },
    { id: 'Advanced', name: 'Advanced', nameAr: 'متقدم', color: 'bg-red-500' },
]

// Generate random educational image based on course ID
function getRandomCourseImage(courseId: string): string {
    const educationalImages = [
        'https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1571171637578-41bc2dd41cd2?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1550439062-609e1531270e?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1517433456452-f9633a875f6f?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1562774053-701939374585?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800&h=1200&fit=crop',
        'https://images.unsplash.com/photo-1553877522-43269d4ea984?w=800&h=1200&fit=crop',
    ]
    
    const hash = courseId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)
    return educationalImages[hash % educationalImages.length]
}

function CourseCard({ course, lang, onClick }: { course: Course; lang: string; onClick: () => void }) {
    const [isHovered, setIsHovered] = useState(false)
    const courseImage = getRandomCourseImage(course.id)

    return (
        <motion.div
            className="relative cursor-pointer flex-shrink-0"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            animate={{
                width: isHovered ? '400px' : '280px',
                zIndex: isHovered ? 999 : 1,
            }}
            transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
        >
            <div className={`relative rounded-lg overflow-hidden transition-all duration-300 ${
                isHovered 
                    ? 'shadow-2xl shadow-purple-500/30 ring-4 ring-purple-500/40' 
                    : 'shadow-xl'
            }`}>
                <div className="relative overflow-hidden bg-background" style={{ height: '420px' }}>
                    <img
                        src={course.thumbnail || courseImage}
                        alt={lang === 'ar' ? (course.titleAr || course.title) : course.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                            e.currentTarget.src = courseImage
                        }}
                    />
                    
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: isHovered ? 0.95 : 0 }}
                        transition={{ duration: 0.3 }}
                        className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"
                    />
                </div>

                <AnimatePresence>
                    {isHovered && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="absolute inset-0 flex flex-col justify-between p-6 z-20"
                        >
                            <div className="flex items-start justify-between">
                                <motion.div
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ delay: 0.1, duration: 0.3, type: "spring" }}
                                    className="flex items-center gap-2 bg-purple-600 text-foreground px-3 py-1.5 rounded-md text-xs font-bold shadow-xl"
                                >
                                    <div className="w-4 h-4 rounded-full bg-white/30 flex items-center justify-center">
                                        <Star className="w-2.5 h-2.5 fill-white text-foreground" />
                                    </div>
                                    {course.isEnrolled ? (lang === 'ar' ? 'مسجل بالفعل' : 'Enrolled') : (lang === 'ar' ? 'متاح الآن' : 'Available')}
                                </motion.div>

                                <motion.button
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ delay: 0.1, duration: 0.3, type: "spring" }}
                                    className="w-9 h-9 rounded-full bg-gray-900/90 hover:bg-background flex items-center justify-center backdrop-blur-md border border-white/30 transition-all hover:border-white/60"
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        setIsHovered(false)
                                    }}
                                >
                                    <X className="w-5 h-5 text-foreground" strokeWidth={2.5} />
                                </motion.button>
                            </div>

                            <div className="space-y-3">
                                <motion.h2
                                    initial={{ y: 20, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.15, duration: 0.3 }}
                                    className="text-foreground font-black text-3xl leading-[1.1] drop-shadow-2xl uppercase tracking-tight line-clamp-2"
                                    style={{ textShadow: '0 4px 12px rgba(0,0,0,0.8)' }}
                                >
                                    {lang === 'ar' ? (course.titleAr || course.title) : course.title}
                                </motion.h2>

                                <motion.div
                                    initial={{ y: 10, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.2, duration: 0.3 }}
                                    className="flex items-center gap-2.5 text-sm font-medium text-gray-100"
                                >
                                    {course.duration && (
                                        <span className="font-semibold">
                                            {typeof course.duration === 'number' 
                                                ? `${Math.floor(course.duration / 60)}h ${course.duration % 60}m`
                                                : course.duration
                                            }
                                        </span>
                                    )}
                                    
                                    {course.duration && course.category && <span className="text-green-400 text-lg">•</span>}
                                    
                                    {course.category && (
                                        <span className="font-semibold">{lang === 'ar' ? course.categoryAr : course.category}</span>
                                    )}
                                    
                                    {course.skillLevel && course.category && <span className="text-green-400 text-lg">•</span>}
                                    
                                    {course.skillLevel && SKILL_LEVELS.find(level => level.id === course.skillLevel) && (
                                        <span className="font-semibold capitalize">
                                            {lang === 'ar'
                                                ? SKILL_LEVELS.find(level => level.id === course.skillLevel)?.nameAr
                                                : SKILL_LEVELS.find(level => level.id === course.skillLevel)?.name
                                            }
                                        </span>
                                    )}
                                </motion.div>

                                {course.isEnrolled && course.userProgress !== undefined && course.userProgress > 0 && (
                                    <motion.div
                                        initial={{ scaleX: 0, opacity: 0 }}
                                        animate={{ scaleX: 1, opacity: 1 }}
                                        transition={{ delay: 0.25, duration: 0.4 }}
                                        className="w-full bg-gray-700/50 rounded-full h-1.5 overflow-hidden"
                                    >
                                        <div
                                            className="h-full bg-gradient-to-r from-green-400 to-green-500 transition-all duration-500"
                                            style={{ width: `${course.userProgress}%` }}
                                        />
                                    </motion.div>
                                )}

                                <motion.div
                                    initial={{ y: 10, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.3, duration: 0.3 }}
                                    className="flex items-center gap-3"
                                >
                                    <button
                                        onClick={onClick}
                                        className="flex-1 flex items-center justify-center gap-2 bg-background hover:bg-gray-200 text-foreground px-4 py-2.5 rounded-lg font-bold text-sm transition-colors shadow-lg"
                                    >
                                        <Play className="w-4 h-4 fill-black" />
                                        {lang === 'ar' ? 'ابدأ الآن' : 'Start Now'}
                                    </button>
                                </motion.div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.div>
    )
}

export function NetflixCourseShowcase({ title, courses, lang = 'en', onCourseClick }: NetflixCourseShowcaseProps) {
    const scrollRef = useRef<HTMLDivElement>(null)
    const [canScrollLeft, setCanScrollLeft] = useState(false)
    const [canScrollRight, setCanScrollRight] = useState(true)
    const router = useRouter()

    const checkScroll = () => {
        if (scrollRef.current) {
            const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current
            setCanScrollLeft(scrollLeft > 0)
            setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10)
        }
    }

    useEffect(() => {
        checkScroll()
        const scrollEl = scrollRef.current
        if (scrollEl) {
            scrollEl.addEventListener('scroll', checkScroll)
            return () => scrollEl.removeEventListener('scroll', checkScroll)
        }
    }, [courses])

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const scrollAmount = 600
            scrollRef.current.scrollBy({
                left: direction === 'left' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            })
        }
    }

    const handleCourseClick = (courseId: string) => {
        if (onCourseClick) {
            onCourseClick(courseId)
        } else {
            router.push(`/${lang}/courses/${courseId}`)
        }
    }

    if (courses.length === 0) return null

    return (
        <div className="relative group/row mb-16">
            {/* Category Title */}
            <div className="px-6 mb-6 flex items-center justify-between group">
                <div className="flex items-center gap-4">
                    <motion.div
                        className="h-8 w-1 bg-gradient-to-b from-purple-500 to-pink-600 rounded-full"
                        initial={{ height: 0 }}
                        whileInView={{ height: 32 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5 }}
                    />
                    
                    <div>
                        <h2 className="text-3xl font-black text-foreground tracking-tight group-hover:text-purple-400 transition-colors">
                            {title}
                        </h2>
                        <div className="h-0.5 w-0 group-hover:w-full bg-gradient-to-r from-purple-500 to-transparent transition-all duration-500 mt-1" />
                    </div>
                </div>

                <div className="flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-border rounded-full">
                    <BookOpen className="w-4 h-4 text-purple-400" />
                    <span className="text-sm font-semibold text-muted-foreground">
                        {courses.length} {lang === 'ar' ? 'دورة' : 'courses'}
                    </span>
                </div>
            </div>

            {/* Scroll Container */}
            <div className="relative">
                {canScrollLeft && (
                    <button
                        onClick={() => scroll('left')}
                        className="absolute left-0 top-0 bottom-0 z-40 bg-background/80 hover:bg-background/95 text-foreground p-2 opacity-0 group-hover/row:opacity-100 transition-opacity duration-300"
                        style={{ width: '40px' }}
                    >
                        <ChevronLeft className="w-6 h-6" />
                    </button>
                )}

                <div
                    ref={scrollRef}
                    className="flex overflow-x-auto scrollbar-hide px-6 py-2 gap-4"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                    {courses.map((course) => (
                        <CourseCard
                            key={course.id}
                            course={course}
                            lang={lang}
                            onClick={() => handleCourseClick(course.id)}
                        />
                    ))}
                </div>

                {canScrollRight && (
                    <button
                        onClick={() => scroll('right')}
                        className="absolute right-0 top-0 bottom-0 z-40 bg-background/80 hover:bg-background/95 text-foreground p-2 opacity-0 group-hover/row:opacity-100 transition-opacity duration-300"
                        style={{ width: '40px' }}
                    >
                        <ChevronRight className="w-6 h-6" />
                    </button>
                )}
            </div>
        </div>
    )
}
