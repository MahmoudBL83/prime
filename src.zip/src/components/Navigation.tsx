'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Menu, X, Search, Globe, ChevronDown, FileText, Video, DollarSign, BarChart3, Trophy, Award, Gift, BookOpen } from 'lucide-react';
import { NavigationAuthSection } from '@/components/navigation/NavigationAuthSection';
import { SearchModal } from '@/components/landing/SearchModal';
import { LanguageSwitcher } from '@/components/i18n/LanguageSwitcher';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useTranslationsSafe, useLocaleSafe } from '@/hooks/useTranslationsSafe';
import { useRouter, usePathname } from 'next/navigation';
import { useNavigationLoading } from '@/hooks/useNavigationLoading';

export function Navigation() {
    const session = useSession();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [isLanguageOpen, setIsLanguageOpen] = useState(false);
    const [isCreatorMenuOpen, setIsCreatorMenuOpen] = useState(false);
    const [isDashboardMenuOpen, setIsDashboardMenuOpen] = useState(false);
    const router = useRouter();
    const pathname = usePathname();
    const { navigateWithLoading, isLoading } = useNavigationLoading();
    
    const locale = useLocaleSafe();
    const t = useTranslationsSafe('navigation');

    const getActivePage = () => {
        if (!pathname) return 'home';
        const pathSegments = pathname.split('/').filter(segment => segment);
        if (pathSegments.length === 0) return 'home';
        if (pathSegments[0] === locale && pathSegments.length === 1) return 'home';
        if (pathSegments.includes('signature-courses')) return 'signature';
        if (pathSegments.includes('courses')) return 'courses';
        if (pathSegments.includes('mentors')) return 'mentors';
        if (pathSegments.includes('leaderboard')) return 'leaderboard';
        if (pathSegments.includes('achievements')) return 'achievements';
        if (pathSegments.includes('rewards')) return 'rewards';
        if (pathSegments.includes('dashboard')) return 'dashboard';
        if (pathSegments.includes('messaging')) return 'messaging';
        if (pathSegments.includes('profile')) return 'profile';
        if (pathSegments.includes('earnings')) return 'earnings';
        if (pathSegments.includes('content')) return 'content';
        if (pathSegments.includes('analytics')) return 'analytics';
        if (pathSegments.includes('community')) return 'community';
        if (pathSegments.includes('live')) return 'liveSessions';
        return 'home';
    };

    const activePage = getActivePage();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 20);
        };
        
        const handleClickOutside = (event: MouseEvent) => {
            if (isLanguageOpen) {
                setIsLanguageOpen(false);
            }
            if (isCreatorMenuOpen) {
                setIsCreatorMenuOpen(false);
            }
            if (isDashboardMenuOpen) {
                setIsDashboardMenuOpen(false);
            }
        };
        
        window.addEventListener('scroll', handleScroll);
        document.addEventListener('click', handleClickOutside);
        
        return () => {
            window.removeEventListener('scroll', handleScroll);
            document.removeEventListener('click', handleClickOutside);
        };
    }, [isLanguageOpen, isCreatorMenuOpen, isDashboardMenuOpen]);

    const navClasses = "fixed top-0 left-0 right-0 z-50 transition-all duration-300 " + 
        (isScrolled 
            ? 'bg-background/95 backdrop-blur-xl border-b border-border shadow-2xl shadow-purple-500/5' 
            : 'bg-gradient-to-b from-background/80 to-transparent backdrop-blur-sm'
        );

    return (
        <div>
            <nav className={navClasses}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-20">
                        {/* Logo Section */}
                        <button
                            onClick={() => navigateWithLoading(`/${locale}`, 'nav-home')}
                            disabled={isLoading('nav-home')}
                            className="flex items-center group transition-all duration-300 hover:scale-105"
                        >
                            <div className="relative">
                                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 via-purple-600 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/25 group-hover:shadow-purple-500/40 transition-all duration-300">
                                    <span className="text-foreground text-lg font-bold">P</span>
                                </div>
                                {isLoading('nav-home') && (
                                    <div className="absolute -top-1 -right-1 w-3 h-3 border border-purple-400 border-t-transparent rounded-full animate-spin"></div>
                                )}
                            </div>
                            <div className="ml-3 hidden sm:block">
                                <span className="text-foreground text-xl font-bold tracking-tight">Prime</span>
                                <div className="text-purple-400 text-xs font-medium tracking-wider">EGYPT</div>
                            </div>
                        </button>

                        {/* Navigation Links */}
                        <div className="hidden lg:flex items-center space-x-2">
                            {/* Show Home link only for non-creator users */}
                            {session.data?.user.role !== 'CREATOR' && (
                                <button
                                    onClick={() => navigateWithLoading(`/${locale}`, 'nav-home')}
                                    disabled={isLoading('nav-home')}
                                    className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center group ${
                                        activePage === 'home' 
                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                    }`}
                                >
                                    {isLoading('nav-home') && (
                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                    )}
                                    {t.t('home')}
                                    {activePage === 'home' && (
                                        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
                                    )}
                                </button>
                            )}
                            
                            <button
                                onClick={() => navigateWithLoading(`/${locale}/courses`, 'nav-courses')}
                                disabled={isLoading('nav-courses')}
                                className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center group ${
                                    activePage === 'courses' 
                                        ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                        : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                }`}
                            >
                                {isLoading('nav-courses') && (
                                    <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                )}
                                {t.t('courses')}
                                {activePage === 'courses' && (
                                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
                                )}
                            </button>

                            <button
                                onClick={() => navigateWithLoading(`/${locale}/signature-courses`, 'nav-signature')}
                                disabled={isLoading('nav-signature')}
                                className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center group ${
                                    activePage === 'signature' 
                                        ? 'text-foreground bg-gradient-to-r from-amber-600/20 to-orange-600/20 border border-amber-500/30' 
                                        : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                }`}
                            >
                                {isLoading('nav-signature') && (
                                    <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                )}
                                <Award className="w-4 h-4 mr-1.5" />
                                Signature Courses
                                {activePage === 'signature' && (
                                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full"></div>
                                )}
                            </button>

                            <button
                                onClick={() => navigateWithLoading(`/${locale}/mentors`, 'nav-mentors')}
                                disabled={isLoading('nav-mentors')}
                                className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center group ${
                                    activePage === 'mentors' 
                                        ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                        : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                }`}
                            >
                                {isLoading('nav-mentors') && (
                                    <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                )}
                                {t.t('mentors') || 'Mentors'}
                                {activePage === 'mentors' && (
                                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
                                )}
                            </button>

                            {session.data && (
                                <>
                                    {/* Dashboard with dropdown if creator */}
                                    {session.data.user.role === 'CREATOR' ? (
                                        <div className="relative">
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setIsDashboardMenuOpen(!isDashboardMenuOpen);
                                                }}
                                                className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center gap-1 group ${
                                                    activePage === 'dashboard'
                                                        ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                        : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                                }`}
                                            >
                                                <span>{t.t('dashboard')}</span>
                                                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${
                                                    isDashboardMenuOpen ? 'rotate-180' : ''
                                                }`} />
                                                {activePage === 'dashboard' && (
                                                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
                                                )}
                                            </button>
                                            
                                            {isDashboardMenuOpen && (
                                                <div className="absolute top-full mt-2 right-0 w-56 bg-background/95 backdrop-blur-xl border border-border rounded-xl shadow-2xl shadow-purple-500/10 overflow-hidden z-50">
                                                    <div className="py-2">
                                                        <button
                                                            onClick={() => {
                                                                navigateWithLoading(`/${locale}/dashboard`, 'nav-learner-dashboard');
                                                                setIsDashboardMenuOpen(false);
                                                            }}
                                                            className="w-full text-left px-4 py-2.5 text-muted-foreground hover:bg-card-hover hover:text-foreground transition-colors"
                                                        >
                                                            <div className="flex items-center gap-3">
                                                                <BookOpen className="w-4 h-4" />
                                                                <span className="text-sm font-medium">Learner Dashboard</span>
                                                            </div>
                                                        </button>
                                                        
                                                        <button
                                                            onClick={() => {
                                                                navigateWithLoading(`/${locale}/creator/dashboard`, 'nav-creator-dashboard');
                                                                setIsDashboardMenuOpen(false);
                                                            }}
                                                            className="w-full text-left px-4 py-2.5 text-muted-foreground hover:bg-card-hover hover:text-foreground transition-colors"
                                                        >
                                                            <div className="flex items-center gap-3">
                                                                <Award className="w-4 h-4" />
                                                                <span className="text-sm font-medium">Creator Dashboard</span>
                                                            </div>
                                                        </button>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        <button
                                            onClick={() => navigateWithLoading(`/${locale}/dashboard`, 'nav-dashboard')}
                                            disabled={isLoading('nav-dashboard')}
                                            className={`relative px-4 py-3 rounded-xl font-medium text-sm transition-all duration-300 flex items-center group ${
                                                activePage === 'dashboard' 
                                                    ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                    : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                            }`}
                                        >
                                            {isLoading('nav-dashboard') && (
                                                <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                            )}
                                            {t.t('dashboard')}
                                            {activePage === 'dashboard' && (
                                                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
                                            )}
                                        </button>
                                    )}
                                </>
                            )}
                        </div>

                        {/* Right Section */}
                        <div className="flex items-center space-x-3">
                            {/* Search Button */}
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setIsSearchOpen(true)}
                                className="text-muted-foreground hover:text-foreground hover:bg-card-hover rounded-xl p-2.5 transition-all duration-300"
                            >
                                <Search className="w-5 h-5" />
                            </Button>

                            {/* Language Switcher */}
                            <div className="relative">
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setIsLanguageOpen(!isLanguageOpen);
                                    }}
                                    className="text-muted-foreground hover:text-foreground hover:bg-card-hover rounded-xl p-2.5 transition-all duration-300 flex items-center gap-1"
                                >
                                    <Globe className="w-4 h-4" />
                                    <span className="text-sm font-medium">
                                        {locale === 'ar' ? 'عربي' : locale === 'de' ? 'DE' : 'EN'}
                                    </span>
                                    <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${
                                        isLanguageOpen ? 'rotate-180' : ''
                                    }`} />
                                </Button>
                                
                                {isLanguageOpen && (
                                    <div className="absolute right-0 top-full mt-2 z-50">
                                        <div className="bg-background/95 backdrop-blur-xl border border-border rounded-2xl shadow-2xl shadow-black/50 overflow-hidden">
                                            <LanguageSwitcher />
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Theme Toggle */}
                            <ThemeToggle />

                            {/* Auth Section */}
                            <NavigationAuthSection />

                            {/* Mobile Menu Button */}
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setIsMenuOpen(!isMenuOpen)}
                                className="lg:hidden text-muted-foreground hover:text-foreground hover:bg-card-hover rounded-xl p-2.5 transition-all duration-300"
                            >
                                <div className="relative w-6 h-6">
                                    <span className={`absolute block w-5 h-0.5 bg-current transform transition-all duration-300 ${
                                        isMenuOpen ? 'rotate-45 translate-y-2' : 'translate-y-1'
                                    }`} />
                                    <span className={`absolute block w-5 h-0.5 bg-current transform transition-all duration-300 ${
                                        isMenuOpen ? 'opacity-0' : 'translate-y-2.5'
                                    }`} />
                                    <span className={`absolute block w-5 h-0.5 bg-current transform transition-all duration-300 ${
                                        isMenuOpen ? '-rotate-45 translate-y-2' : 'translate-y-4'
                                    }`} />
                                </div>
                            </Button>
                        </div>
                    </div>

                    {/* Mobile Menu */}
                    {isMenuOpen && (
                        <div className="lg:hidden absolute top-full left-0 right-0 bg-gray-900/98 backdrop-blur-xl border-b border-border shadow-2xl">
                            <div className="px-4 py-6 space-y-1">
                                {/* Show Home link only for non-creator users */}
                                {session.data?.user.role !== 'CREATOR' && (
                                    <button
                                        onClick={() => {
                                            navigateWithLoading(`/${locale}`, 'mobile-nav-home');
                                            setIsMenuOpen(false);
                                        }}
                                        disabled={isLoading('mobile-nav-home')}
                                        className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                            activePage === 'home' 
                                                ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                        }`}
                                    >
                                        {isLoading('mobile-nav-home') && (
                                            <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                        )}
                                        {t.t('home')}
                                    </button>
                                )}

                                <button
                                    onClick={() => {
                                        navigateWithLoading(`/${locale}/courses`, 'mobile-nav-courses');
                                        setIsMenuOpen(false);
                                    }}
                                    disabled={isLoading('mobile-nav-courses')}
                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                        activePage === 'courses' 
                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                    }`}
                                >
                                    {isLoading('mobile-nav-courses') && (
                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                    )}
                                    {t.t('courses')}
                                </button>

                                <button
                                    onClick={() => {
                                        navigateWithLoading(`/${locale}/signature-courses`, 'mobile-nav-signature');
                                        setIsMenuOpen(false);
                                    }}
                                    disabled={isLoading('mobile-nav-signature')}
                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                        activePage === 'signature' 
                                            ? 'text-foreground bg-gradient-to-r from-amber-600/20 to-orange-600/20 border border-amber-500/30' 
                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                    }`}
                                >
                                    {isLoading('mobile-nav-signature') && (
                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                    )}
                                    <Award className="w-4 h-4 mr-2" />
                                    Signature Courses
                                </button>

                                <button
                                    onClick={() => {
                                        navigateWithLoading(`/${locale}/mentors`, 'mobile-nav-mentors');
                                        setIsMenuOpen(false);
                                    }}
                                    disabled={isLoading('mobile-nav-mentors')}
                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                        activePage === 'mentors' 
                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                    }`}
                                >
                                    {isLoading('mobile-nav-mentors') && (
                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                    )}
                                    {t.t('mentors') || 'Mentors'}
                                </button>

                                {session.data && (
                                    <div className="border-t border-border pt-3 mt-3">
                                        <button
                                            onClick={() => {
                                                const dashboardUrl = session.data.user.role === 'CREATOR' 
                                                    ? `/${locale}/creator/dashboard` 
                                                    : `/${locale}/dashboard`;
                                                navigateWithLoading(dashboardUrl, 'mobile-nav-dashboard');
                                                setIsMenuOpen(false);
                                            }}
                                            disabled={isLoading('mobile-nav-dashboard')}
                                            className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                                activePage === 'dashboard' 
                                                    ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                    : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                            }`}
                                        >
                                            {isLoading('mobile-nav-dashboard') && (
                                                <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                            )}
                                            {t.t('dashboard')}
                                        </button>

                                        {/* Creator-specific mobile menu items */}
                                        {session.data.user.role === 'CREATOR' && (
                                            <>
                                                <button
                                                    onClick={() => {
                                                        navigateWithLoading(`/${locale}/creator/content/posts`, 'mobile-nav-content');
                                                        setIsMenuOpen(false);
                                                    }}
                                                    disabled={isLoading('mobile-nav-content')}
                                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                                        activePage === 'content' 
                                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                                    }`}
                                                >
                                                    {isLoading('mobile-nav-content') && (
                                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                                    )}
                                                    {t.t('content') || 'Content'}
                                                </button>

                                                <button
                                                    onClick={() => {
                                                        navigateWithLoading(`/${locale}/creator/live`, 'mobile-nav-live');
                                                        setIsMenuOpen(false);
                                                    }}
                                                    disabled={isLoading('mobile-nav-live')}
                                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                                        activePage === 'liveSessions' 
                                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                                    }`}
                                                >
                                                    {isLoading('mobile-nav-live') && (
                                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                                    )}
                                                    {t.t('liveSessions') || 'Live Sessions'}
                                                </button>

                                                <button
                                                    onClick={() => {
                                                        navigateWithLoading(`/${locale}/creator/earnings`, 'mobile-nav-earnings');
                                                        setIsMenuOpen(false);
                                                    }}
                                                    disabled={isLoading('mobile-nav-earnings')}
                                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                                        activePage === 'earnings' 
                                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                                    }`}
                                                >
                                                    {isLoading('mobile-nav-earnings') && (
                                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                                    )}
                                                    {t.t('earnings')}
                                                </button>

                                                <button
                                                    onClick={() => {
                                                        navigateWithLoading(`/${locale}/creator/analytics`, 'mobile-nav-analytics');
                                                        setIsMenuOpen(false);
                                                    }}
                                                    disabled={isLoading('mobile-nav-analytics')}
                                                    className={`w-full text-left px-4 py-3.5 rounded-xl font-medium transition-all duration-300 flex items-center group ${
                                                        activePage === 'analytics' 
                                                            ? 'text-foreground bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30' 
                                                            : 'text-muted-foreground hover:text-foreground hover:bg-card-hover'
                                                    }`}
                                                >
                                                    {isLoading('mobile-nav-analytics') && (
                                                        <div className="w-3 h-3 border border-white/50 border-t-white rounded-full animate-spin mr-2"></div>
                                                    )}
                                                    {t.t('analytics')}
                                                </button>
                                            </>
                                        )}
                                    </div>
                                )}

                                <div className="border-t border-border pt-3 mt-3">
                                    <NavigationAuthSection isMobile={true} />
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </nav>

            <SearchModal
                isOpen={isSearchOpen}
                onClose={() => setIsSearchOpen(false)}
            />
        </div>
    );
}