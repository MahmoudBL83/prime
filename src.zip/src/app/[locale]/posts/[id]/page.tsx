'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { motion } from 'framer-motion'
import {
    ArrowLeft,
    Heart,
    MessageCircle,
    Share2,
    Bookmark,
    MoreHorizontal,
    Send,
    Image as ImageIcon,
    Smile,
    CheckCircle,
    Crown,
    Lock,
    Play
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import Image from 'next/image'
import toast from 'react-hot-toast'

interface Post {
    id: string
    channelId: string
    title?: string
    titleAr?: string
    content: string
    contentAr?: string
    type: 'TEXT' | 'VIDEO' | 'IMAGE' | 'DOCUMENT' | 'POLL' | 'ANNOUNCEMENT'
    mediaUrl?: string
    thumbnailUrl?: string
    duration?: number
    publishedAt: string
    tier: string
    isPinned: boolean
    viewCount: number
    channel: {
        id: string
        name: string
        nameAr?: string
        creator: {
            user: {
                id: string
                name: string
                arabicName?: string
                profileImage: string | null
            }
            expertise: string
        }
    }
    likes: { id: string; userId: string }[]
    comments: Comment[]
    _count?: {
        likes: number
        comments: number
    }
}

interface Comment {
    id: string
    userId: string
    content: string
    createdAt: string
    updatedAt: string
    user?: {
        id: string
        name: string
        arabicName?: string
        profileImage: string | null
    }
}

export default function PostDetailPage() {
    const router = useRouter()
    const params = useParams()
    const { data: session } = useSession()
    const locale = (params.locale as string) || 'en'
    const isArabic = locale === 'ar'
    const postId = params.id as string

    const [post, setPost] = useState<Post | null>(null)
    const [loading, setLoading] = useState(true)
    const [commentText, setCommentText] = useState('')
    const [submittingComment, setSubmittingComment] = useState(false)
    const [isLiked, setIsLiked] = useState(false)
    const [likeCount, setLikeCount] = useState(0)
    const [isBookmarked, setIsBookmarked] = useState(false)
    const [hasAccess, setHasAccess] = useState(false)

    useEffect(() => {
        fetchPost()
    }, [postId])

    const fetchPost = async () => {
        try {
            const response = await fetch(`/api/posts/${postId}`)
            if (response.ok) {
                const data = await response.json()
                setPost(data.post)
                setLikeCount(data.post._count?.likes || data.post.likes?.length || 0)
                setIsLiked(data.post.likes?.some((like: any) => like.userId === session?.user?.id) || false)
                setHasAccess(data.hasAccess || false)
            } else {
                toast.error(isArabic ? 'فشل في تحميل المنشور' : 'Failed to load post')
                router.push(`/${locale}/mentors`)
            }
        } catch (error) {
            console.error('Failed to fetch post:', error)
            toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
        } finally {
            setLoading(false)
        }
    }

    const handleLike = async () => {
        if (!session) {
            toast.error(isArabic ? 'يرجى تسجيل الدخول' : 'Please sign in')
            return
        }

        try {
            const response = await fetch(`/api/posts/${postId}/like`, {
                method: isLiked ? 'DELETE' : 'POST',
            })

            if (response.ok) {
                setIsLiked(!isLiked)
                setLikeCount(prev => isLiked ? prev - 1 : prev + 1)
            }
        } catch (error) {
            console.error('Failed to like post:', error)
        }
    }

    const handleComment = async () => {
        if (!session) {
            toast.error(isArabic ? 'يرجى تسجيل الدخول' : 'Please sign in')
            return
        }

        if (!commentText.trim()) {
            toast.error(isArabic ? 'الرجاء كتابة تعليق' : 'Please write a comment')
            return
        }

        if (!hasAccess) {
            toast.error(isArabic ? 'يجب الاشتراك للتعليق' : 'Subscribe to comment')
            return
        }

        setSubmittingComment(true)
        try {
            const response = await fetch(`/api/posts/${postId}/comments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ content: commentText }),
            })

            if (response.ok) {
                const data = await response.json()
                setPost(prev => prev ? {
                    ...prev,
                    comments: [data.comment, ...prev.comments]
                } : null)
                setCommentText('')
                toast.success(isArabic ? 'تم إضافة التعليق' : 'Comment added')
            } else {
                toast.error(isArabic ? 'فشل في إضافة التعليق' : 'Failed to add comment')
            }
        } catch (error) {
            console.error('Failed to comment:', error)
            toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
        } finally {
            setSubmittingComment(false)
        }
    }

    const handleShare = () => {
        const url = `${window.location.origin}/${locale}/posts/${postId}`
        navigator.clipboard.writeText(url)
        toast.success(isArabic ? 'تم نسخ الرابط!' : 'Link copied!')
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
            </div>
        )
    }

    if (!post) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-white mb-4">
                        {isArabic ? 'المنشور غير موجود' : 'Post not found'}
                    </h2>
                    <Button
                        onClick={() => router.push(`/${locale}/mentors`)}
                        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 py-3 rounded-full"
                    >
                        {isArabic ? 'العودة' : 'Go Back'}
                    </Button>
                </div>
            </div>
        )
    }

    const tierColors = {
        BRONZE: 'from-orange-700 to-orange-500',
        SILVER: 'from-gray-400 to-gray-200',
        GOLD: 'from-yellow-500 to-yellow-300',
        VIP: 'from-purple-500 to-pink-500',
    }

    return (
        <div className="min-h-screen bg-black text-white">
            {/* Header */}
            <div className="sticky top-0 z-50 bg-black/95 backdrop-blur-xl border-b border-white/10">
                <div className="container mx-auto px-4 py-4">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => router.back()}
                            className="p-2 hover:bg-white/10 rounded-full transition-colors"
                        >
                            <ArrowLeft className="w-6 h-6" />
                        </button>
                        <div>
                            <h1 className="text-xl font-bold">{isArabic ? 'المنشور' : 'Post'}</h1>
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="container mx-auto max-w-3xl">
                {/* Post */}
                <div className="border-b border-white/10 p-6">
                    {/* Creator Info */}
                    <div className="flex items-start gap-4 mb-4">
                        <div
                            className="cursor-pointer"
                            onClick={() => router.push(`/${locale}/mentors/${post.channel.creator.user.id}`)}
                        >
                            {post.channel.creator.user.profileImage ? (
                                <Image
                                    src={post.channel.creator.user.profileImage}
                                    alt={post.channel.creator.user.name}
                                    width={48}
                                    height={48}
                                    className="rounded-full object-cover"
                                />
                            ) : (
                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                    <span className="text-xl font-bold">
                                        {post.channel.creator.user.name[0]}
                                    </span>
                                </div>
                            )}
                        </div>
                        <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                                <span
                                    className="font-bold text-white hover:underline cursor-pointer"
                                    onClick={() => router.push(`/${locale}/mentors/${post.channel.creator.user.id}`)}
                                >
                                    {isArabic && post.channel.creator.user.arabicName
                                        ? post.channel.creator.user.arabicName
                                        : post.channel.creator.user.name}
                                </span>
                                <CheckCircle className="w-5 h-5 text-purple-500 fill-purple-500" />
                                {post.tier !== 'BRONZE' && (
                                    <Crown className={`w-5 h-5 bg-gradient-to-r ${tierColors[post.tier as keyof typeof tierColors]} bg-clip-text text-transparent`} />
                                )}
                            </div>
                            <p className="text-sm text-gray-400">{post.channel.creator.expertise}</p>
                            <p className="text-sm text-gray-500">
                                {new Date(post.publishedAt).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
                                    year: 'numeric',
                                    month: 'long',
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                })}
                            </p>
                        </div>
                    </div>

                    {/* Title */}
                    {post.title && (
                        <h2 className="text-2xl font-bold text-white mb-4">
                            {isArabic && post.titleAr ? post.titleAr : post.title}
                        </h2>
                    )}

                    {/* Content */}
                    <div className="text-lg text-white mb-4 whitespace-pre-wrap">
                        {isArabic && post.contentAr ? post.contentAr : post.content}
                    </div>

                    {/* Media */}
                    {!hasAccess && post.tier !== 'BRONZE' ? (
                        <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-br from-purple-900/30 to-pink-900/30">
                            <div className="aspect-video flex flex-col items-center justify-center p-8 backdrop-blur-sm">
                                <Lock className="w-16 h-16 text-purple-400 mb-4" />
                                <h3 className="text-xl font-bold text-white mb-2">
                                    {isArabic ? 'محتوى حصري' : 'Exclusive Content'}
                                </h3>
                                <p className="text-gray-400 text-center mb-4">
                                    {isArabic
                                        ? `اشترك في باقة ${post.tier} أو أعلى لمشاهدة هذا المحتوى`
                                        : `Subscribe to ${post.tier} tier or higher to view this content`}
                                </p>
                                <Button
                                    onClick={() => router.push(`/${locale}/mentors/${post.channel.creator.user.id}`)}
                                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 py-3 rounded-full"
                                >
                                    <Crown className="w-5 h-5 mr-2" />
                                    {isArabic ? 'اشترك الآن' : 'Subscribe Now'}
                                </Button>
                            </div>
                        </div>
                    ) : (
                        <>
                            {post.type === 'IMAGE' && post.mediaUrl && (
                                <div className="relative rounded-2xl overflow-hidden border border-white/10 mb-4">
                                    <Image
                                        src={post.mediaUrl}
                                        alt="Post media"
                                        width={800}
                                        height={600}
                                        className="w-full object-cover"
                                    />
                                </div>
                            )}

                            {post.type === 'VIDEO' && post.mediaUrl && (
                                <div className="relative rounded-2xl overflow-hidden border border-white/10 mb-4">
                                    <video
                                        controls
                                        poster={post.thumbnailUrl}
                                        className="w-full"
                                    >
                                        <source src={post.mediaUrl} type="video/mp4" />
                                    </video>
                                </div>
                            )}
                        </>
                    )}

                    {/* Stats */}
                    <div className="flex items-center gap-4 text-sm text-gray-400 mb-4 pt-4 border-t border-white/10">
                        <span>{post.viewCount.toLocaleString()} {isArabic ? 'مشاهدة' : 'views'}</span>
                        <span>·</span>
                        <span>{likeCount} {isArabic ? 'إعجاب' : 'likes'}</span>
                        <span>·</span>
                        <span>{post.comments.length} {isArabic ? 'تعليق' : 'comments'}</span>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-around py-2 border-t border-b border-white/10">
                        <button
                            onClick={handleLike}
                            className={`flex items-center gap-2 px-4 py-2 rounded-full hover:bg-pink-500/10 transition-all group ${
                                isLiked ? 'text-pink-500' : 'text-gray-400'
                            }`}
                        >
                            <Heart className={`w-5 h-5 ${isLiked ? 'fill-pink-500' : ''} group-hover:scale-110 transition-transform`} />
                            <span className="font-semibold">{isArabic ? 'إعجاب' : 'Like'}</span>
                        </button>

                        <button
                            onClick={() => document.getElementById('comment-input')?.focus()}
                            className="flex items-center gap-2 px-4 py-2 rounded-full hover:bg-purple-500/10 text-gray-400 hover:text-purple-400 transition-all group"
                        >
                            <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                            <span className="font-semibold">{isArabic ? 'تعليق' : 'Comment'}</span>
                        </button>

                        <button
                            onClick={handleShare}
                            className="flex items-center gap-2 px-4 py-2 rounded-full hover:bg-purple-500/10 text-gray-400 hover:text-purple-400 transition-all group"
                        >
                            <Share2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
                            <span className="font-semibold">{isArabic ? 'مشاركة' : 'Share'}</span>
                        </button>

                        <button
                            onClick={() => {
                                setIsBookmarked(!isBookmarked)
                                toast.success(isArabic ? (isBookmarked ? 'تمت الإزالة' : 'تم الحفظ') : (isBookmarked ? 'Removed' : 'Saved'))
                            }}
                            className={`flex items-center gap-2 px-4 py-2 rounded-full hover:bg-purple-500/10 transition-all group ${
                                isBookmarked ? 'text-purple-500' : 'text-gray-400'
                            }`}
                        >
                            <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-purple-500' : ''} group-hover:scale-110 transition-transform`} />
                            <span className="font-semibold">{isArabic ? 'حفظ' : 'Save'}</span>
                        </button>
                    </div>
                </div>

                {/* Comment Input */}
                {session && hasAccess ? (
                    <div className="p-6 border-b border-white/10">
                        <div className="flex gap-3">
                            <div className="flex-shrink-0">
                                {session.user?.image ? (
                                    <Image
                                        src={session.user.image}
                                        alt={session.user.name || 'User'}
                                        width={40}
                                        height={40}
                                        className="rounded-full object-cover"
                                    />
                                ) : (
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                        <span className="text-sm font-bold">
                                            {session.user?.name?.[0] || 'U'}
                                        </span>
                                    </div>
                                )}
                            </div>
                            <div className="flex-1">
                                <Textarea
                                    id="comment-input"
                                    value={commentText}
                                    onChange={(e) => setCommentText(e.target.value)}
                                    placeholder={isArabic ? 'اكتب تعليقك...' : 'Write your comment...'}
                                    className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 min-h-[80px] resize-none focus:border-purple-500"
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                                            handleComment()
                                        }
                                    }}
                                />
                                <div className="flex items-center justify-between mt-2">
                                    <div className="flex items-center gap-2">
                                        <button className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white">
                                            <ImageIcon className="w-5 h-5" />
                                        </button>
                                        <button className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white">
                                            <Smile className="w-5 h-5" />
                                        </button>
                                    </div>
                                    <Button
                                        onClick={handleComment}
                                        disabled={submittingComment || !commentText.trim()}
                                        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 py-2 rounded-full disabled:opacity-50"
                                    >
                                        {submittingComment ? (
                                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        ) : (
                                            <>
                                                <Send className="w-4 h-4 mr-2" />
                                                {isArabic ? 'نشر' : 'Post'}
                                            </>
                                        )}
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : !session ? (
                    <div className="p-6 border-b border-white/10 text-center">
                        <p className="text-gray-400 mb-4">
                            {isArabic ? 'يجب تسجيل الدخول للتعليق' : 'Sign in to comment'}
                        </p>
                        <Button
                            onClick={() => router.push(`/${locale}/login`)}
                            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 py-2 rounded-full"
                        >
                            {isArabic ? 'تسجيل الدخول' : 'Sign In'}
                        </Button>
                    </div>
                ) : (
                    <div className="p-6 border-b border-white/10 text-center">
                        <Lock className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                        <p className="text-gray-400 mb-4">
                            {isArabic ? 'اشترك لإضافة تعليق' : 'Subscribe to comment'}
                        </p>
                        <Button
                            onClick={() => router.push(`/${locale}/mentors/${post.channel.creator.user.id}`)}
                            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold px-6 py-2 rounded-full"
                        >
                            <Crown className="w-5 h-5 mr-2" />
                            {isArabic ? 'اشترك الآن' : 'Subscribe Now'}
                        </Button>
                    </div>
                )}

                {/* Comments List */}
                <div className="divide-y divide-white/10">
                    {post.comments.length === 0 ? (
                        <div className="p-12 text-center">
                            <MessageCircle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                            <h3 className="text-xl font-bold text-white mb-2">
                                {isArabic ? 'لا توجد تعليقات بعد' : 'No comments yet'}
                            </h3>
                            <p className="text-gray-400">
                                {isArabic ? 'كن أول من يعلق!' : 'Be the first to comment!'}
                            </p>
                        </div>
                    ) : (
                        post.comments.map((comment) => (
                            <motion.div
                                key={comment.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="p-6 hover:bg-white/[0.02] transition-colors"
                            >
                                <div className="flex gap-3">
                                    <div className="flex-shrink-0">
                                        {comment.user?.profileImage ? (
                                            <Image
                                                src={comment.user.profileImage}
                                                alt={comment.user.name}
                                                width={40}
                                                height={40}
                                                className="rounded-full object-cover"
                                            />
                                        ) : (
                                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center">
                                                <span className="text-sm font-bold">
                                                    {comment.user?.name?.[0] || 'U'}
                                                </span>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <span className="font-bold text-white">
                                                {isArabic && comment.user?.arabicName
                                                    ? comment.user.arabicName
                                                    : comment.user?.name || 'User'}
                                            </span>
                                            <span className="text-gray-500 text-sm">
                                                {new Date(comment.createdAt).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
                                                    month: 'short',
                                                    day: 'numeric',
                                                    hour: '2-digit',
                                                    minute: '2-digit'
                                                })}
                                            </span>
                                        </div>
                                        <p className="text-white whitespace-pre-wrap">{comment.content}</p>
                                        <div className="flex items-center gap-4 mt-2">
                                            <button className="text-gray-400 hover:text-pink-400 text-sm font-semibold transition-colors">
                                                <Heart className="w-4 h-4 inline mr-1" />
                                                {isArabic ? 'إعجاب' : 'Like'}
                                            </button>
                                            <button className="text-gray-400 hover:text-purple-400 text-sm font-semibold transition-colors">
                                                {isArabic ? 'رد' : 'Reply'}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        ))
                    )}
                </div>
            </div>
        </div>
    )
}
