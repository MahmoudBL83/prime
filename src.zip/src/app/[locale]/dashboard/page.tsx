'use client'

import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import { toast } from 'react-hot-toast'
import { useTranslations, useLocale } from 'next-intl'
import { 
    BookOpen, 
    Calendar, 
    Users, 
    TrendingUp, 
    Award, 
    Clock,
    ChevronRight,
    Star,
    Play,
    MessageSquare,
    Settings,
    BarChart3,
    Target,
    Zap,
    BookmarkPlus,
    Bookmark,
    ThumbsUp,
    Heart,
    CheckCircle
} from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useNavigationLoading } from '@/hooks/useNavigationLoading'

interface UserProfile {
    id: string
    name: string
    email: string
    arabicName?: string
    phone?: string
    interests?: string[]
    goals?: string[]
    skillLevel?: string
    learningMode?: string
    onboardingCompleted?: boolean
    role: string
    subscriptionStatus?: 'NONE' | 'ACTIVE' | 'EXPIRED' | 'CANCELLED'
}

interface Course {
    id: string
    title: string
    titleAr: string
    description: string
    thumbnail?: string
    creatorId: string
    category: string
    skillLevel: string
    duration: number
    totalViews: number
    totalEnrollments: number
    rating: number
    creator: {
        user: {
            name: string
            arabicName?: string
        }
    }
}

interface LearningStats {
    totalCourses: number
    completedCourses: number
    inProgressCourses: number
    averageProgress: number
    totalLearningHours: number
    averageRating: number
    upcomingMeetingsCount: number
    totalMeetingsCount: number
    unreadMessagesCount: number
    studyBuddyMatches: number
    continueLearning: {
        id: string
        title: string
        titleAr: string
        progress: number
        lastAccessed: string
        instructor: {
            name: string
            arabicName?: string
        }
    }[]
    recentActivities: {
        type: string
        title: string
        titleAr: string
        description: string
        descriptionAr: string
        timestamp: string
        icon: string
    }[]
}

function DashboardContent() {
    const { data: session, status } = useSession()
    const router = useRouter()
    const searchParams = useSearchParams()
    const locale = useLocale()
    const t = useTranslations('dashboard')
    const tCommon = useTranslations('common')
    const { navigateWithLoading, isLoading } = useNavigationLoading()
    const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
    const [learningStats, setLearningStats] = useState<LearningStats | null>(null)
    const [recommendedCourses, setRecommendedCourses] = useState<Course[]>([])
    const [loading, setLoading] = useState(true)
    const [isClient, setIsClient] = useState(false)
    const [activeTab, setActiveTab] = useState<string>('overview')
    const [myListCourses, setMyListCourses] = useState<Course[]>([])
    const [likedCourses, setLikedCourses] = useState<Course[]>([])
    const [tabLoading, setTabLoading] = useState(false)

    // Direction based on locale
    const dir = locale === 'ar' ? 'rtl' : 'ltr'
    const isArabic = locale === 'ar'

    // Handle client-side mounting
    useEffect(() => {
        setIsClient(true)
    }, [])

    // Handle tab from URL query
    useEffect(() => {
        const tab = searchParams.get('tab')
        if (tab && ['overview', 'my-list', 'liked'].includes(tab)) {
            setActiveTab(tab)
        }
    }, [searchParams])

    // Fetch tab-specific data
    useEffect(() => {
        if (!session || !isClient) return

        const fetchTabData = async () => {
            setTabLoading(true)
            try {
                if (activeTab === 'my-list' && myListCourses.length === 0) {
                    const response = await fetch('/api/user/my-list')
                    if (response.ok) {
                        const data = await response.json()
                        setMyListCourses(data.courses)
                    }
                } else if (activeTab === 'liked' && likedCourses.length === 0) {
                    const response = await fetch('/api/user/liked-courses')
                    if (response.ok) {
                        const data = await response.json()
                        setLikedCourses(data.courses)
                    }
                }
            } catch (error) {
                console.error('Error fetching tab data:', error)
            } finally {
                setTabLoading(false)
            }
        }

        fetchTabData()
    }, [activeTab, session, isClient])

    useEffect(() => {
        if (!isClient || status === 'loading') return
        if (!session) {
            router.push(`/${locale}/auth/login`)
            return
        }

        const checkOnboarding = async () => {
            try {
                const [profileResponse, statsResponse] = await Promise.all([
                    fetch('/api/user/profile'),
                    fetch('/api/user/learning-stats')
                ])
                
                if (profileResponse.ok) {
                    const profileData = await profileResponse.json()
                    setUserProfile(profileData.user)

                    // Admin users don't need onboarding - redirect to admin panel
                    if (profileData.user.role === 'ADMIN') {
                        window.location.href = '/admin'
                        return
                    }

                    // Check if user has completed onboarding
                    if (!profileData.user.onboardingCompleted) {
                        navigateWithLoading(`/${locale}/onboarding`, 'onboarding-redirect')
                        return
                    }

                    // Fetch recommended courses based on user interests
                    if (profileData.user.interests) {
                        await fetchRecommendedCourses(profileData.user.interests)
                    }
                } else {
                    navigateWithLoading(`/${locale}/onboarding`, 'onboarding-redirect')
                    return
                }

                if (statsResponse.ok) {
                    const statsData = await statsResponse.json()
                    setLearningStats(statsData.stats)
                }
            } catch (error) {
                console.error('Error checking profile:', error)
                navigateWithLoading(`/${locale}/onboarding`, 'onboarding-redirect')
            } finally {
                setLoading(false)
            }
        }

        checkOnboarding()
    }, [session, status, router, isClient, locale])

    const fetchRecommendedCourses = async (interests: string[]) => {
        try {
            const response = await fetch('/api/courses')
            if (response.ok) {
                const data = await response.json()
                const interestsArray = Array.isArray(interests) ? interests : []
                const recommended = data.courses.filter((course: Course) => {
                    return interestsArray.some(interest =>
                        course.title.toLowerCase().includes(interest.toLowerCase()) ||
                        course.description.toLowerCase().includes(interest.toLowerCase())
                    )
                }).slice(0, 6)
                setRecommendedCourses(recommended)
            }
        } catch (error) {
            console.error('Error fetching courses:', error)
        }
    }

    const handleStudyBuddyClick = () => {
        navigateWithLoading(`/${locale}/study-buddy`, 'study-buddy')
    }

    const handleCourseClick = (courseId: string) => {
        navigateWithLoading(`/${locale}/courses/${courseId}`, `course-${courseId}`)
    }

    // Show loading during hydration or data fetching
    if (!isClient || status === 'loading' || loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
                <div className="text-center">
                    <div className="relative">
                        {/* Decorative loading elements */}
                        <div className="absolute inset-0 w-16 h-16 border-4 border-purple-500/30 rounded-full animate-ping"></div>
                        <div className="w-16 h-16 border-4 border-purple-500/50 border-t-purple-400 rounded-full animate-spin mx-auto mb-6"></div>
                    </div>
                    <p className="text-purple-200 text-lg font-medium">Loading your dashboard...</p>
                    <p className="text-gray-400 text-sm mt-2">Preparing your personalized experience</p>
                </div>
            </div>
        )
    }

    // Handle unauthenticated state
    if (!session) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
                <div className="text-purple-200 text-lg">Redirecting to login...</div>
            </div>
        )
    }

    // Handle missing profile
    if (!userProfile) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
                <div className="text-purple-200 text-lg">Setting up your profile...</div>
            </div>
        )
    }

    const displayName = isArabic ? (userProfile.arabicName || userProfile.name) : userProfile.name
    const welcomeText = isArabic ? `مرحباً، ${displayName}` : `Welcome back, ${displayName}`

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900" dir={dir}>
            {/* Header */}
            <div className="relative overflow-hidden">
                {/* Background Elements */}
                <div className="absolute inset-0">
                    <div className="absolute top-20 left-20 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl"></div>
                    <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl"></div>
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-purple-600/10 to-blue-600/10 rounded-full blur-3xl"></div>
                </div>
                
                <div className="relative bg-gradient-to-br from-gray-900 via-purple-900/30 to-blue-900/30 py-16 px-6">
                    <div className="max-w-7xl mx-auto">
                        <div className="mb-8">
                            <div className="inline-flex items-center gap-2 bg-purple-600/20 backdrop-blur-sm border border-purple-500/30 rounded-full px-6 py-3 mb-6">
                                <Award className="w-5 h-5 text-purple-400" />
                                <span className="text-purple-200 font-medium">
                                    {isArabic ? 'تجربة تعليمية متميزة' : 'Premium Learning Experience'}
                                </span>
                            </div>
                            
                            <h1 className="text-5xl lg:text-6xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent mb-4 leading-tight">
                                {welcomeText}
                            </h1>
                            <p className="text-xl text-purple-100/80 mb-8 leading-relaxed max-w-3xl">
                                {isArabic 
                                    ? 'جاهز لمواصلة رحلة التعلم؟ استكشف دوراتك وتابع تقدمك وتواصل مع مدربيك المفضلين' 
                                    : 'Ready to continue your learning journey? Explore your courses, track progress, and connect with your favorite instructors'
                                }
                            </p>
                            
                            {/* Enhanced Quick stats */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
                                <div className="text-center bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-purple-400/60 transition-all duration-300">
                                    <div className="text-3xl lg:text-4xl font-bold text-white mb-2">
                                        {learningStats?.totalCourses || 0}
                                    </div>
                                    <div className="text-purple-300 text-sm uppercase tracking-wider">
                                        {isArabic ? 'الدورات' : 'Courses'}
                                    </div>
                                </div>
                                <div className="text-center bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-blue-400/60 transition-all duration-300">
                                    <div className="text-3xl lg:text-4xl font-bold text-white mb-2">
                                        {learningStats?.averageRating || 4.8}
                                    </div>
                                    <div className="text-blue-300 text-sm uppercase tracking-wider">
                                        {isArabic ? 'التقييم' : 'Rating'}
                                    </div>
                                </div>
                                <div className="text-center bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-green-400/60 transition-all duration-300">
                                    <div className="text-3xl lg:text-4xl font-bold text-white mb-2">
                                        {learningStats?.totalLearningHours || 0}h
                                    </div>
                                    <div className="text-green-300 text-sm uppercase tracking-wider">
                                        {isArabic ? 'ساعات التعلم' : 'Hours Learned'}
                                    </div>
                                </div>
                                <div className="text-center bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-yellow-400/60 transition-all duration-300">
                                    <div className="text-3xl lg:text-4xl font-bold text-white mb-2">
                                        {learningStats?.averageProgress || 0}%
                                    </div>
                                    <div className="text-yellow-300 text-sm uppercase tracking-wider">
                                        {isArabic ? 'الإنجاز' : 'Completion'}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="max-w-7xl mx-auto px-6 py-8">
                {/* Tab Navigation */}
                <div className="bg-gray-900/40 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-2 mb-8 inline-flex gap-2">
                    <button
                        onClick={() => setActiveTab('overview')}
                        className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 flex items-center gap-2 ${
                            activeTab === 'overview'
                                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                                : 'text-gray-400 hover:text-white hover:bg-gray-800/60'
                        }`}
                    >
                        <BarChart3 className="w-5 h-5" />
                        {isArabic ? 'نظرة عامة' : 'Overview'}
                    </button>
                    <button
                        onClick={() => setActiveTab('my-list')}
                        className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 flex items-center gap-2 ${
                            activeTab === 'my-list'
                                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                                : 'text-gray-400 hover:text-white hover:bg-gray-800/60'
                        }`}
                    >
                        <Bookmark className="w-5 h-5" />
                        {isArabic ? 'قائمتي' : 'My List'}
                        {myListCourses.length > 0 && (
                            <span className="ml-1 px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold">
                                {myListCourses.length}
                            </span>
                        )}
                    </button>
                    <button
                        onClick={() => setActiveTab('liked')}
                        className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 flex items-center gap-2 ${
                            activeTab === 'liked'
                                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                                : 'text-gray-400 hover:text-white hover:bg-gray-800/60'
                        }`}
                    >
                        <Heart className="w-5 h-5" />
                        {isArabic ? 'الدورات المفضلة' : 'Liked Courses'}
                        {likedCourses.length > 0 && (
                            <span className="ml-1 px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 text-xs font-bold">
                                {likedCourses.length}
                            </span>
                        )}
                    </button>
                </div>

                {/* Tab Content */}
                {activeTab === 'overview' && (
                <>
                {/* Quick Actions Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                    {/* My Learning */}
                    <div 
                        className="group relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-cyan-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-cyan-500/20 cursor-pointer" 
                        onClick={() => navigateWithLoading(`/${locale}/dashboard/my-learning`, 'my-learning')}
                    >
                        {/* Loading Overlay */}
                        {isLoading('my-learning') && (
                            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-3xl flex items-center justify-center z-20">
                                <div className="flex flex-col items-center gap-4 text-white">
                                    <div className="w-8 h-8 border-3 border-cyan-300/30 border-t-cyan-400 rounded-full animate-spin"></div>
                                    <span className="text-sm font-medium">Loading courses...</span>
                                </div>
                            </div>
                        )}
                        
                        {/* Decorative Elements */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
                        
                        <div className="relative p-8">
                            <div className="flex items-center justify-between mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <BookOpen className="w-7 h-7 text-white" />
                                </div>
                                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:translate-x-1 group-hover:text-cyan-400 transition-all duration-300" />
                            </div>
                            <h3 className="font-bold text-xl mb-3 text-white group-hover:text-cyan-200 transition-colors">
                                {isArabic ? 'دوراتي' : 'My Learning'}
                            </h3>
                            <p className="text-gray-400 text-sm mb-6 leading-relaxed group-hover:text-gray-300 transition-colors">
                                {isArabic 
                                    ? 'الوصول إلى جميع دوراتك المسجلة'
                                    : 'Access all your enrolled courses'
                                }
                            </p>
                            <div className="flex items-center gap-2">
                                <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-500/30 hover:bg-cyan-500/30 transition-colors">
                                    {learningStats?.totalCourses || 0} {isArabic ? 'دورات' : 'courses'}
                                </Badge>
                            </div>
                        </div>
                        
                        {/* Hover Effect Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/10 to-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-3xl"></div>
                    </div>

                    {/* My Meetings */}
                    <div 
                        className="group relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-purple-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-purple-500/20 cursor-pointer" 
                        onClick={() => navigateWithLoading(`/${locale}/dashboard/meetings`, 'meetings')}
                    >
                        {/* Loading Overlay */}
                        {isLoading('meetings') && (
                            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-3xl flex items-center justify-center z-20">
                                <div className="flex flex-col items-center gap-4 text-white">
                                    <div className="w-8 h-8 border-3 border-purple-300/30 border-t-purple-400 rounded-full animate-spin"></div>
                                    <span className="text-sm font-medium">Loading meetings...</span>
                                </div>
                            </div>
                        )}
                        
                        {/* Decorative Elements */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
                        
                        <div className="relative p-8">
                            <div className="flex items-center justify-between mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-blue-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <Calendar className="w-7 h-7 text-white" />
                                </div>
                                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:translate-x-1 group-hover:text-purple-400 transition-all duration-300" />
                            </div>
                            <h3 className="font-bold text-xl mb-3 text-white group-hover:text-purple-200 transition-colors">
                                {isArabic ? 'اجتماعاتي' : 'My Meetings'}
                            </h3>
                            <p className="text-gray-400 text-sm mb-6 leading-relaxed group-hover:text-gray-300 transition-colors">
                                {isArabic 
                                    ? 'عرض وإدارة جلساتك المحجوزة مع المدربين'
                                    : 'View and manage your scheduled sessions'
                                }
                            </p>
                            <div className="flex items-center gap-2">
                                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 hover:bg-purple-500/30 transition-colors">
                                    {learningStats?.upcomingMeetingsCount || 0} {isArabic ? 'قادمة' : 'upcoming'}
                                </Badge>
                            </div>
                        </div>
                        
                        {/* Hover Effect Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-3xl"></div>
                    </div>

                    {/* Study Buddy */}
                    <div 
                        className="group relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-green-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-green-500/20 cursor-pointer" 
                        onClick={handleStudyBuddyClick}
                    >
                        {/* Loading Overlay */}
                        {isLoading('study-buddy') && (
                            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-3xl flex items-center justify-center z-20">
                                <div className="flex flex-col items-center gap-4 text-white">
                                    <div className="w-8 h-8 border-3 border-green-300/30 border-t-green-400 rounded-full animate-spin"></div>
                                    <span className="text-sm font-medium">Finding study buddies...</span>
                                </div>
                            </div>
                        )}
                        
                        {/* Decorative Elements */}
                        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-green-500/20 to-emerald-500/20 rounded-full blur-2xl"></div>
                        
                        <div className="relative p-8">
                            <div className="flex items-center justify-between mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <Users className="w-7 h-7 text-white" />
                                </div>
                                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:translate-x-1 group-hover:text-green-400 transition-all duration-300" />
                            </div>
                            <h3 className="font-bold text-xl mb-3 text-white group-hover:text-green-200 transition-colors">
                                {isArabic ? 'رفيق الدراسة' : 'Study Buddy'}
                            </h3>
                            <p className="text-gray-400 text-sm mb-6 leading-relaxed group-hover:text-gray-300 transition-colors">
                                {isArabic 
                                    ? 'ابحث عن شريك التعلم المثالي'
                                    : 'Find the perfect learning partner'
                                }
                            </p>
                            <div className="flex items-center gap-2">
                                <Badge className="bg-green-500/20 text-green-300 border-green-500/30 hover:bg-green-500/30 transition-colors">
                                    {learningStats?.studyBuddyMatches || 0} {isArabic ? 'مطابقة' : 'matches'}
                                </Badge>
                            </div>
                        </div>
                        
                        {/* Hover Effect Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-br from-green-600/10 to-emerald-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-3xl"></div>
                    </div>

                    {/* My Progress */}
                    <div 
                        className="group relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-blue-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-blue-500/20 cursor-pointer" 
                        onClick={() => navigateWithLoading(`/${locale}/dashboard/progress`, 'progress')}
                    >
                        {/* Loading Overlay */}
                        {isLoading('progress') && (
                            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-3xl flex items-center justify-center z-20">
                                <div className="flex flex-col items-center gap-4 text-white">
                                    <div className="w-8 h-8 border-3 border-blue-300/30 border-t-blue-400 rounded-full animate-spin"></div>
                                    <span className="text-sm font-medium">Loading progress...</span>
                                </div>
                            </div>
                        )}
                        
                        {/* Decorative Elements */}
                        <div className="absolute top-0 right-0 w-28 h-28 bg-gradient-to-bl from-blue-500/20 to-indigo-500/20 rounded-full blur-2xl"></div>
                        
                        <div className="relative p-8">
                            <div className="flex items-center justify-between mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <TrendingUp className="w-7 h-7 text-white" />
                                </div>
                                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:translate-x-1 group-hover:text-blue-400 transition-all duration-300" />
                            </div>
                            <h3 className="font-bold text-xl mb-3 text-white group-hover:text-blue-200 transition-colors">
                                {isArabic ? 'تقدمي' : 'My Progress'}
                            </h3>
                            <p className="text-gray-400 text-sm mb-6 leading-relaxed group-hover:text-gray-300 transition-colors">
                                {isArabic 
                                    ? 'تتبع تقدمك التعليمي وإنجازاتك'
                                    : 'Track your learning progress'
                                }
                            </p>
                            <div className="mb-2">
                                <div className="w-full bg-gray-700/50 rounded-full h-2 mb-2">
                                    <div 
                                        className="bg-gradient-to-r from-blue-500 to-indigo-500 h-2 rounded-full transition-all duration-500" 
                                        style={{ width: `${learningStats?.averageProgress || 0}%` }}
                                    ></div>
                                </div>
                                <p className="text-xs text-blue-300 font-medium">
                                    {learningStats?.averageProgress || 0}% {isArabic ? 'مكتمل' : 'complete'}
                                </p>
                            </div>
                        </div>
                        
                        {/* Hover Effect Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-indigo-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-3xl"></div>
                    </div>

                    {/* Messages */}
                    <div 
                        className="group relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-orange-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-orange-500/20 cursor-pointer" 
                        onClick={() => navigateWithLoading(`/${locale}/messaging`, 'messaging')}
                    >
                        {/* Loading Overlay */}
                        {isLoading('messaging') && (
                            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm rounded-3xl flex items-center justify-center z-20">
                                <div className="flex flex-col items-center gap-4 text-white">
                                    <div className="w-8 h-8 border-3 border-orange-300/30 border-t-orange-400 rounded-full animate-spin"></div>
                                    <span className="text-sm font-medium">Loading messages...</span>
                                </div>
                            </div>
                        )}
                        
                        {/* Decorative Elements */}
                        <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-tl from-orange-500/20 to-red-500/20 rounded-full blur-2xl"></div>
                        
                        <div className="relative p-8">
                            <div className="flex items-center justify-between mb-6">
                                <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                    <MessageSquare className="w-7 h-7 text-white" />
                                </div>
                                <ChevronRight className="w-6 h-6 text-gray-400 group-hover:translate-x-1 group-hover:text-orange-400 transition-all duration-300" />
                            </div>
                            <h3 className="font-bold text-xl mb-3 text-white group-hover:text-orange-200 transition-colors">
                                {isArabic ? 'الرسائل' : 'Messages'}
                            </h3>
                            <p className="text-gray-400 text-sm mb-6 leading-relaxed group-hover:text-gray-300 transition-colors">
                                {isArabic 
                                    ? 'تواصل مع المدربين والطلاب'
                                    : 'Connect with instructors and students'
                                }
                            </p>
                            <div className="flex items-center gap-2">
                                <Badge className={`${learningStats?.unreadMessagesCount && learningStats.unreadMessagesCount > 0 ? 'bg-red-500/20 text-red-300 border-red-500/30' : 'bg-gray-500/20 text-gray-300 border-gray-500/30'} hover:bg-red-500/30 transition-colors`}>
                                    {learningStats?.unreadMessagesCount || 0} {isArabic ? 'جديدة' : 'new'}
                                </Badge>
                            </div>
                        </div>
                        
                        {/* Hover Effect Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 to-red-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-3xl"></div>
                    </div>
                </div>

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left Column - Continue Learning & Recommended */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Continue Learning */}
                        <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-purple-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-purple-500/20">
                            {/* Decorative Elements */}
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-3xl"></div>
                            
                            <div className="relative p-8">
                                <div className="flex flex-row items-center justify-between mb-8">
                                    <div className="flex items-center gap-3">
                                        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                                            <Play className="w-6 h-6 text-white" />
                                        </div>
                                        <h2 className="text-2xl font-bold text-white">
                                            {isArabic ? 'تابع التعلم' : 'Continue Learning'}
                                        </h2>
                                    </div>
                                    <Button variant="ghost" size="sm" className="text-purple-300 hover:text-purple-200 hover:bg-purple-500/20">
                                        {isArabic ? 'عرض الكل' : 'View all'}
                                    </Button>
                                </div>
                                
                                <div className="space-y-6">
                                    {learningStats?.continueLearning && learningStats.continueLearning.length > 0 ? (
                                        learningStats.continueLearning.map((course, index) => (
                                            <div 
                                                key={course.id} 
                                                className="bg-gray-900/60 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:bg-gray-800/60 hover:border-purple-400/60 transition-all duration-300 cursor-pointer group"
                                                onClick={() => handleCourseClick(course.id)}
                                            >
                                                <div className="flex items-center gap-6">
                                                    <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-300">
                                                        <BookOpen className="w-10 h-10 text-white" />
                                                    </div>
                                                    <div className="flex-1">
                                                        <h4 className="font-bold text-lg text-white mb-2 group-hover:text-purple-200 transition-colors">
                                                            {isArabic && course.titleAr ? course.titleAr : course.title}
                                                        </h4>
                                                        <p className="text-gray-400 text-sm mb-4 group-hover:text-gray-300 transition-colors">
                                                            {isArabic ? 'بواسطة' : 'by'} {(isArabic && course.instructor.arabicName) ? course.instructor.arabicName : course.instructor.name}
                                                        </p>
                                                        <div className="mb-3">
                                                            <div className="w-full bg-gray-700/50 rounded-full h-3 mb-2">
                                                                <div 
                                                                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-500" 
                                                                    style={{ width: `${course.progress}%` }}
                                                                ></div>
                                                            </div>
                                                            <p className="text-xs text-blue-300 font-medium">{course.progress}% {isArabic ? 'مكتمل' : 'complete'}</p>
                                                        </div>
                                                    </div>
                                                    <Button 
                                                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            handleCourseClick(course.id)
                                                        }}
                                                        disabled={isLoading(`course-${course.id}`)}
                                                    >
                                                        {isLoading(`course-${course.id}`) ? (
                                                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                                                        ) : null}
                                                        {isArabic ? 'متابعة' : 'Continue'}
                                                    </Button>
                                                </div>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="text-center py-12">
                                            <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                                <BookOpen className="w-8 h-8 text-gray-400" />
                                            </div>
                                            <p className="text-gray-400 mb-4">
                                                {isArabic ? 'لا توجد دورات قيد التقدم حالياً' : 'No courses in progress'}
                                            </p>
                                            <Button 
                                                variant="outline" 
                                                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20 hover:border-purple-400"
                                                onClick={() => navigateWithLoading(`/${locale}/courses`, 'browse-courses')}
                                                disabled={isLoading('browse-courses')}
                                            >
                                                {isLoading('browse-courses') && (
                                                    <div className="w-4 h-4 border-2 border-purple-300/30 border-t-purple-400 rounded-full animate-spin mr-2"></div>
                                                )}
                                                {isArabic ? 'تصفح الدورات' : 'Browse Courses'}
                                            </Button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Recommended Courses */}
                        {recommendedCourses.length > 0 && (
                            <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-yellow-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-yellow-500/20">
                                {/* Decorative Elements */}
                                <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-yellow-500/20 to-orange-500/20 rounded-full blur-3xl"></div>
                                
                                <div className="relative p-8">
                                    <div className="flex flex-row items-center justify-between mb-8">
                                        <div className="flex items-center gap-3">
                                            <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                                                <Zap className="w-6 h-6 text-white" />
                                            </div>
                                            <h2 className="text-2xl font-bold text-white">
                                                {isArabic ? 'موصى به لك' : 'Recommended for You'}
                                            </h2>
                                        </div>
                                        <Button variant="ghost" size="sm" className="text-yellow-300 hover:text-yellow-200 hover:bg-yellow-500/20" onClick={() => router.push(`/${locale}/courses`)}>
                                            {isArabic ? 'عرض الكل' : 'View all'}
                                        </Button>
                                    </div>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        {recommendedCourses.slice(0, 4).map((course) => (
                                            <div 
                                                key={course.id}
                                                className="bg-gray-900/60 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:bg-gray-800/60 hover:border-yellow-400/60 hover:shadow-lg hover:shadow-yellow-500/20 transition-all duration-300 cursor-pointer group"
                                                onClick={() => handleCourseClick(course.id)}
                                            >
                                                <div className="aspect-video bg-gray-700/50 rounded-xl mb-4 flex items-center justify-center group-hover:bg-gray-600/50 transition-colors">
                                                    <Play className="w-10 h-10 text-gray-400 group-hover:text-yellow-400 transition-colors" />
                                                </div>
                                                <h4 className="font-bold text-white mb-2 group-hover:text-yellow-200 transition-colors">{course.title}</h4>
                                                <p className="text-gray-400 text-sm mb-3 group-hover:text-gray-300 transition-colors">
                                                    {isArabic ? 'بواسطة' : 'by'} {course.creator.user.arabicName || course.creator.user.name}
                                                </p>
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                                        <span className="text-white font-medium">{course.rating.toFixed(1)}</span>
                                                    </div>
                                                    <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 hover:bg-yellow-500/30 transition-colors">
                                                        {course.category}
                                                    </Badge>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Right Column - Activity */}
                    <div className="space-y-8">

                        {/* Recent Activity */}
                        <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-green-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-green-500/20">
                            {/* Decorative Elements */}
                            <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-green-500/20 to-emerald-500/20 rounded-full blur-3xl"></div>
                            
                            <div className="relative p-8">
                                <div className="flex items-center gap-3 mb-8">
                                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                                        <Clock className="w-6 h-6 text-white" />
                                    </div>
                                    <h2 className="text-2xl font-bold text-white">
                                        {isArabic ? 'النشاط الأخير' : 'Recent Activity'}
                                    </h2>
                                </div>
                                
                                <div className="space-y-6">
                                    {learningStats?.recentActivities && learningStats.recentActivities.length > 0 ? (
                                        learningStats.recentActivities.map((activity, index) => {
                                            const IconComponent = activity.icon === 'book' ? BookOpen : 
                                                                activity.icon === 'users' ? Users : Award
                                            const gradientColors = activity.icon === 'book' ? 'from-blue-500 to-purple-600' :
                                                                   activity.icon === 'users' ? 'from-green-500 to-emerald-600' :
                                                                   'from-yellow-500 to-orange-600'
                                            const textColors = activity.icon === 'book' ? 'group-hover:text-blue-200' :
                                                              activity.icon === 'users' ? 'group-hover:text-green-200' :
                                                              'group-hover:text-yellow-200'
                                            
                                            const timeAgo = new Date(activity.timestamp).toLocaleDateString(
                                                isArabic ? 'ar' : 'en',
                                                { 
                                                    month: 'short', 
                                                    day: 'numeric',
                                                    hour: '2-digit',
                                                    minute: '2-digit'
                                                }
                                            )
                                            
                                            return (
                                                <div key={index} className="flex items-center gap-4 group">
                                                    <div className={`w-12 h-12 bg-gradient-to-br ${gradientColors} rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-300`}>
                                                        <IconComponent className="w-6 h-6 text-white" />
                                                    </div>
                                                    <div className="flex-1">
                                                        <p className={`text-white font-semibold ${textColors} transition-colors`}>
                                                            {isArabic ? activity.descriptionAr : activity.description}
                                                        </p>
                                                        <p className="text-gray-400 text-sm">
                                                            {timeAgo}
                                                        </p>
                                                    </div>
                                                </div>
                                            )
                                        })
                                    ) : (
                                        <div className="text-center py-8">
                                            <div className="w-12 h-12 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-3">
                                                <Clock className="w-6 h-6 text-gray-400" />
                                            </div>
                                            <p className="text-gray-400 text-sm">
                                                {isArabic ? 'لا يوجد نشاط حديث' : 'No recent activity'}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Learning Goals */}
                        <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-yellow-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-yellow-500/20">
                            {/* Decorative Elements */}
                            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-yellow-500/20 to-orange-500/20 rounded-full blur-2xl"></div>
                            
                            <div className="relative p-8">
                                <div className="flex items-center gap-3 mb-6">
                                    <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                                        <Target className="w-6 h-6 text-white" />
                                    </div>
                                    <h2 className="text-xl font-bold text-white">
                                        {isArabic ? 'أهدافك' : 'Your Goals'}
                                    </h2>
                                </div>
                                
                                <div className="space-y-3">
                                    {userProfile.goals && userProfile.goals.length > 0 ? (
                                        userProfile.goals.map((goal, index) => (
                                            <div key={index} className="flex items-center gap-3 p-3 bg-gray-900/60 backdrop-blur-sm border border-gray-700/50 rounded-xl">
                                                <CheckCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">{goal}</span>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="text-center py-4">
                                            <Target className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                                            <p className="text-gray-400 text-sm">
                                                {isArabic ? 'لم تحدد أهداف بعد' : 'No goals set yet'}
                                            </p>
                                        </div>
                                    )}
                                </div>
                                
                                <Button 
                                    className="w-full mt-6 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white font-semibold py-3 shadow-lg hover:shadow-xl transition-all duration-300"
                                    onClick={() => navigateWithLoading(`/${locale}/profile?tab=overview`, 'profile-goals')}
                                    disabled={isLoading('profile-goals')}
                                >
                                    {isLoading('profile-goals') ? (
                                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                                    ) : (
                                        <Settings className="w-5 h-5 mr-2" />
                                    )}
                                    {isArabic ? 'تحديث الأهداف' : 'Update Goals'}
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
                </>
                )}

                {/* My List Tab */}
                {activeTab === 'my-list' && (
                    <div className="space-y-8">
                        <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-blue-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-blue-500/20">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-full blur-3xl"></div>
                            
                            <div className="relative p-8">
                                <div className="flex items-center gap-3 mb-8">
                                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                                        <Bookmark className="w-6 h-6 text-white" />
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-bold text-white">
                                            {isArabic ? 'قائمتي' : 'My List'}
                                        </h2>
                                        <p className="text-gray-400 text-sm">
                                            {isArabic ? `${myListCourses.length} دورات محفوظة` : `${myListCourses.length} saved courses`}
                                        </p>
                                    </div>
                                </div>

                                {tabLoading ? (
                                    <div className="text-center py-12">
                                        <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-400 rounded-full animate-spin mx-auto mb-4"></div>
                                        <p className="text-gray-400">{isArabic ? 'جاري التحميل...' : 'Loading...'}</p>
                                    </div>
                                ) : myListCourses.length > 0 ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {myListCourses.map((course) => (
                                            <div
                                                key={course.id}
                                                className="bg-gray-900/60 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:bg-gray-800/60 hover:border-blue-400/60 hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300 cursor-pointer group"
                                                onClick={() => handleCourseClick(course.id)}
                                            >
                                                <div className="aspect-video bg-gray-700/50 rounded-xl mb-4 flex items-center justify-center group-hover:bg-gray-600/50 transition-colors overflow-hidden">
                                                    {course.thumbnail ? (
                                                        <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                                                    ) : (
                                                        <Play className="w-10 h-10 text-gray-400 group-hover:text-blue-400 transition-colors" />
                                                    )}
                                                </div>
                                                <h4 className="font-bold text-white mb-2 group-hover:text-blue-200 transition-colors line-clamp-2">
                                                    {isArabic && course.titleAr ? course.titleAr : course.title}
                                                </h4>
                                                <p className="text-gray-400 text-sm mb-3 group-hover:text-gray-300 transition-colors">
                                                    {isArabic ? 'بواسطة' : 'by'} {course.creator?.user?.arabicName || course.creator?.user?.name}
                                                </p>
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                                        <span className="text-white font-medium">{course.rating?.toFixed(1) || '4.5'}</span>
                                                    </div>
                                                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                                                        {isArabic ? 'في القائمة' : 'In List'}
                                                    </Badge>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-12">
                                        <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <Bookmark className="w-8 h-8 text-gray-400" />
                                        </div>
                                        <p className="text-gray-400 mb-4">
                                            {isArabic ? 'قائمتك فارغة' : 'Your list is empty'}
                                        </p>
                                        <Button
                                            variant="outline"
                                            className="border-blue-500/50 text-blue-300 hover:bg-blue-500/20 hover:border-blue-400"
                                            onClick={() => router.push(`/${locale}/courses`)}
                                        >
                                            {isArabic ? 'تصفح الدورات' : 'Browse Courses'}
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* Liked Courses Tab */}
                {activeTab === 'liked' && (
                    <div className="space-y-8">
                        <div className="relative bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-sm rounded-3xl border border-gray-700/50 overflow-hidden hover:border-red-400/60 transition-all duration-500 hover:shadow-2xl hover:shadow-red-500/20">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-red-500/20 to-pink-500/20 rounded-full blur-3xl"></div>
                            
                            <div className="relative p-8">
                                <div className="flex items-center gap-3 mb-8">
                                    <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                                        <Heart className="w-6 h-6 text-white" />
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-bold text-white">
                                            {isArabic ? 'الدورات المفضلة' : 'Liked Courses'}
                                        </h2>
                                        <p className="text-gray-400 text-sm">
                                            {isArabic ? `${likedCourses.length} دورات مفضلة` : `${likedCourses.length} liked courses`}
                                        </p>
                                    </div>
                                </div>

                                {tabLoading ? (
                                    <div className="text-center py-12">
                                        <div className="w-16 h-16 border-4 border-red-500/30 border-t-red-400 rounded-full animate-spin mx-auto mb-4"></div>
                                        <p className="text-gray-400">{isArabic ? 'جاري التحميل...' : 'Loading...'}</p>
                                    </div>
                                ) : likedCourses.length > 0 ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                        {likedCourses.map((course) => (
                                            <div
                                                key={course.id}
                                                className="bg-gray-900/60 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:bg-gray-800/60 hover:border-red-400/60 hover:shadow-lg hover:shadow-red-500/20 transition-all duration-300 cursor-pointer group"
                                                onClick={() => handleCourseClick(course.id)}
                                            >
                                                <div className="aspect-video bg-gray-700/50 rounded-xl mb-4 flex items-center justify-center group-hover:bg-gray-600/50 transition-colors overflow-hidden">
                                                    {course.thumbnail ? (
                                                        <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover" />
                                                    ) : (
                                                        <Play className="w-10 h-10 text-gray-400 group-hover:text-red-400 transition-colors" />
                                                    )}
                                                </div>
                                                <h4 className="font-bold text-white mb-2 group-hover:text-red-200 transition-colors line-clamp-2">
                                                    {isArabic && course.titleAr ? course.titleAr : course.title}
                                                </h4>
                                                <p className="text-gray-400 text-sm mb-3 group-hover:text-gray-300 transition-colors">
                                                    {isArabic ? 'بواسطة' : 'by'} {course.creator?.user?.arabicName || course.creator?.user?.name}
                                                </p>
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                                                        <span className="text-white font-medium">{course.rating?.toFixed(1) || '4.5'}</span>
                                                    </div>
                                                    <Badge className="bg-red-500/20 text-red-300 border-red-500/30">
                                                        {isArabic ? 'مفضل' : 'Liked'} ❤️
                                                    </Badge>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-12">
                                        <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <Heart className="w-8 h-8 text-gray-400" />
                                        </div>
                                        <p className="text-gray-400 mb-4">
                                            {isArabic ? 'لم تعجب بأي دورات بعد' : "You haven't liked any courses yet"}
                                        </p>
                                        <Button
                                            variant="outline"
                                            className="border-red-500/50 text-red-300 hover:bg-red-500/20 hover:border-red-400"
                                            onClick={() => router.push(`/${locale}/courses`)}
                                        >
                                            {isArabic ? 'تصفح الدورات' : 'Browse Courses'}
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

// Use dynamic import to disable SSR for the dashboard content
export default function DashboardPage() {
    return <DashboardContent />
}