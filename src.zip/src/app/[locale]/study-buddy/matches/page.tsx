'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter } from 'next/navigation'
import {
  MessageCircle,
  Users,
  BookOpen,
  Target,
  Heart,
  ArrowLeft,                        </div>
                      </div>

                      {/* Shared Subjects */}dar,
  Video
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import toast from 'react-hot-toast'
import Link from 'next/link'
import Image from 'next/image'

interface StudyBuddyMatch {
  id: string
  status: string
  sharedSubjects?: string[]
  sharedGoals?: string[]
  createdAt: string
  updatedAt: string
  chatRoomId?: string | null
  otherUser: {
    id: string
    name: string
    arabicName?: string | null
    profileImage?: string | null
    interests: string[]
    goals: string[]
    skillLevel: string | null
    learningMode?: string | null
  }
}

export default function StudyBuddyMatchesPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const params = useParams()
  const locale = params.locale as string || 'en'
  const isArabic = locale === 'ar'

  const [matches, setMatches] = useState<StudyBuddyMatch[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push(`/${locale}/auth/login`)
      return
    }

    if (status === 'authenticated') {
      fetchMatches()
    }
  }, [status, router, locale])

  const fetchMatches = async () => {
    try {
      const response = await fetch('/api/study-buddy/matches')
      if (response.ok) {
        const data = await response.json()
        setMatches(data.matches || [])
      } else {
        toast.error(isArabic ? 'فشل تحميل التطابقات' : 'Failed to load matches')
      }
    } catch (error) {
      console.error('Error fetching matches:', error)
      toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const getMatchedUser = (match: StudyBuddyMatch) => {
    return match.otherUser
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto"></div>
          <p className="mt-6 text-xl text-purple-200">
            {isArabic ? 'جار تحميل التطابقات...' : 'Loading matches...'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4" dir={isArabic ? 'rtl' : 'ltr'}>
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-4xl mx-auto relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href={`/${locale}/dashboard`}>
            <Button variant="ghost" className="text-white">
              <ArrowLeft className={`w-5 h-5 ${isArabic ? 'rotate-180' : ''}`} />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Heart className="w-8 h-8 text-pink-400 fill-pink-400" />
            {isArabic ? 'شركاء الدراسة' : 'Study Buddies'}
          </h1>
          <Link href={`/${locale}/study-buddy/swipe`}>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90">
              {isArabic ? 'البحث عن المزيد' : 'Find More'}
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{matches.length}</p>
                <p className="text-sm text-gray-400">
                  {isArabic ? 'إجمالي التطابقات' : 'Total Matches'}
                </p>
              </div>
            </div>
          </Card>

          <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {matches.filter(m => m.status === 'ACTIVE').length}
                </p>
                <p className="text-sm text-gray-400">
                  {isArabic ? 'نشط' : 'Active'}
                </p>
              </div>
            </div>
          </Card>

          <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                <Heart className="w-6 h-6 text-pink-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">
                  {matches.filter(m => new Date(m.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length}
                </p>
                <p className="text-sm text-gray-400">
                  {isArabic ? 'هذا الأسبوع' : 'This Week'}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Matches List */}
        {matches.length === 0 ? (
          <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-12 text-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mx-auto mb-6">
              <Users className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">
              {isArabic ? 'لا توجد تطابقات حتى الآن' : 'No Matches Yet'}
            </h2>
            <p className="text-gray-300 mb-6">
              {isArabic 
                ? 'ابدأ في البحث عن شركاء الدراسة للعثور على تطابقك المثالي!'
                : 'Start swiping to find your perfect study buddy!'}
            </p>
            <Link href={`/${locale}/study-buddy/swipe`}>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90">
                {isArabic ? 'ابدأ البحث' : 'Start Swiping'}
              </Button>
            </Link>
          </Card>
        ) : (
          <div className="space-y-4">
            {matches.map((match) => {
              const matchedUser = getMatchedUser(match)
              const userName = isArabic && matchedUser.arabicName 
                ? matchedUser.arabicName 
                : matchedUser.name

              return (
                <Card
                  key={match.id}
                  className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-6 hover:border-purple-500/50 transition-all"
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Profile Image */}
                    <div className="flex-shrink-0">
                      <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-purple-500/30">
                        {matchedUser.profileImage ? (
                          <Image
                            src={matchedUser.profileImage}
                            alt={userName}
                            width={96}
                            height={96}
                            className="object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                            <Users className="w-12 h-12 text-white" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Match Info */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-xl font-bold text-white mb-1">{userName}</h3>
                          <p className="text-sm text-gray-400">
                            {isArabic ? 'تطابق منذ' : 'Matched'}{' '}
                            {new Date(match.createdAt).toLocaleDateString(isArabic ? 'ar' : 'en', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric'
                            })}
                          </p>
                        </div>
                        <Badge
                          className={
                            match.status === 'ACTIVE'
                              ? 'bg-green-500/20 text-green-300 border-green-400/30'
                              : 'bg-gray-500/20 text-gray-300 border-gray-400/30'
                          }
                        >
                          {match.status}
                        </Badge>
                      </div>

                      {matchedUser.bio && (
                        <p className="text-gray-300 text-sm mb-4">{matchedUser.bio}</p>
                      )}

                      {/* Shared Subjects */}
                      {match.sharedSubjects && match.sharedSubjects.length > 0 && (
                        <div className="mb-3">
                          <div className="flex items-center gap-2 mb-2">
                            <BookOpen className="w-4 h-4 text-blue-400" />
                            <span className="text-sm font-semibold text-white">
                              {isArabic ? 'المواد المشتركة' : 'Shared Subjects'}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {match.sharedSubjects.map((subject, idx) => (
                              <Badge
                                key={idx}
                                className="bg-blue-500/20 text-blue-300 border-blue-400/30"
                              >
                                {subject}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Shared Goals */}
                      {match.sharedGoals && match.sharedGoals.length > 0 && (
                        <div className="mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Target className="w-4 h-4 text-purple-400" />
                            <span className="text-sm font-semibold text-white">
                              {isArabic ? 'الأهداف المشتركة' : 'Shared Goals'}
                            </span>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {match.sharedGoals.map((goal, idx) => (
                              <Badge
                                key={idx}
                                className="bg-purple-500/20 text-purple-300 border-purple-400/30"
                              >
                                {goal}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="flex flex-wrap gap-3">
                        <Button
                          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90"
                          onClick={() => router.push(`/${locale}/study-buddy/workspace?matchId=${match.id}`)}
                        >
                          <Users className="w-4 h-4 mr-2" />
                          {isArabic ? 'مساحة العمل' : 'Workspace'}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => router.push(`/${locale}/messaging?userId=${matchedUser.id}`)}
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          {isArabic ? 'دردشة' : 'Chat'}
                        </Button>
                        <Button variant="outline">
                          <Calendar className="w-4 h-4 mr-2" />
                          {isArabic ? 'جلسة' : 'Session'}
                        </Button>
                        <Button variant="outline">
                          <Video className="w-4 h-4 mr-2" />
                          {isArabic ? 'فيديو' : 'Video'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
