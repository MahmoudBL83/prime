'use client'

import { useState, useEffect } from 'react'
import { SwipeInterface } from '@/components/study-buddy/SwipeInterface'
import { MatchesList } from '@/components/study-buddy/MatchesList'
import { MatchingInsights } from '@/components/study-buddy/MatchingInsights'
import ProfileCompletionGuide from '@/components/study-buddy/ProfileCompletionGuide'
import { toast } from 'react-hot-toast'
import { motion } from 'framer-motion'
import { User, Settings, Bell, Heart, Users, Star, Edit3, Brain, TrendingUp, Zap, CheckCircle, Clock, MessageCircle } from 'lucide-react'
import { useLocale } from 'next-intl'
import { useRouter } from 'next/navigation'
import Image from 'next/image'

interface StudyBuddyProfile {
    id: string
    name: string
    arabicName?: string | null
    profileImage?: string | null
    bio?: string | null
    interests: string[]
    goals: string[]
    skillLevel?: string | null
    learningMode?: string | null
    studyBuddyPreferences?: any
    createdAt: string
}

interface StudyBuddy {
    id: string
    name: string
    arabicName?: string | null
    interests: string[]
    goals: string[]
    skillLevel: string | null
    learningMode?: string | null
    profileImage?: string | null
    compatibilityScore: number
    compatibilityBreakdown?: {
        interestsScore: number
        goalsScore: number
        skillLevelScore: number
        communicationScore: number
        learningStyleScore: number
        scheduleScore: number
        subjectScore: number
        preferencesScore: number
    }
    sharedInterests: string[]
    sharedGoals: string[]
    reasonsForMatch?: string[]
}

interface StudyBuddyMatchWithDetails {
    id: string
    status: string
    sharedSubjects: string[]
    sharedGoals: string[]
    chatRoomId?: string | null
    createdAt: string
    updatedAt: string
    otherUser: {
        id: string
        name: string
        arabicName?: string | null
        profileImage?: string | null
        interests: string[]
        goals: string[]
        skillLevel: string | null
        learningMode?: string | null
    }
}

export default function StudyBuddyPage() {
    const locale = useLocale()
    const router = useRouter()
    const [activeTab, setActiveTab] = useState<'discover' | 'matches' | 'profile' | 'notifications'>('discover')
    const [potentialMatches, setPotentialMatches] = useState<StudyBuddy[]>([])
    const [existingMatches, setExistingMatches] = useState<StudyBuddyMatchWithDetails[]>([])
    const [userProfile, setUserProfile] = useState<StudyBuddyProfile | null>(null)
    const [loading, setLoading] = useState(false)
    const [profileIncomplete, setProfileIncomplete] = useState<{
        missing: string[]
        message: string
        nextSteps: string[]
    } | null>(null)
    const [profileStats, setProfileStats] = useState<any>(null)

    useEffect(() => {
        loadUserProfile()
        if (activeTab === 'discover') {
            fetchPotentialMatches()
        } else if (activeTab === 'matches') {
            fetchExistingMatches()
        }
    }, [activeTab])

    const loadUserProfile = async () => {
        try {
            const response = await fetch('/api/study-buddy/profile')
            if (response.ok) {
                const data = await response.json()
                setUserProfile(data.profile)
                setProfileStats(data.stats)
            }
        } catch (error) {
            console.error('Failed to load profile:', error)
        }
    }

    const updateProfile = async (profileData: Partial<StudyBuddyProfile>) => {
        try {
            const response = await fetch('/api/study-buddy/profile', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(profileData)
            })

            if (response.ok) {
                const data = await response.json()
                setUserProfile(data.profile)
                toast.success('Profile updated successfully!')
            } else {
                const error = await response.json()
                toast.error(error.error || 'Failed to update profile')
            }
        } catch (error) {
            toast.error('Failed to update profile')
        }
    }

    const fetchPotentialMatches = async () => {
        setLoading(true)
        try {
            const response = await fetch('/api/study-buddy/match?limit=20')
            const data = await response.json()
            
            if (response.ok) {
                setPotentialMatches(data.matches || [])
                
                // Clear any previous profile incomplete state
                setProfileIncomplete(null)
                
                // Show helpful message if no matches found
                if (!data.matches || data.matches.length === 0) {
                    if (data.totalAvailable === 0) {
                        toast('No other learners available yet. Invite friends to join!')
                    } else {
                        toast('No compatible matches found. Try updating your preferences.')
                    }
                }
            } else {
                // Handle specific error codes
                if (data.code === 'NOT_AUTHENTICATED') {
                    toast.error('Please log in to find study buddies')
                    window.location.href = '/auth/login'
                    return
                } else if (data.code === 'PROFILE_INCOMPLETE') {
                    // Show profile completion guide instead of error
                    setProfileIncomplete({
                        missing: data.missingFields || [],
                        message: data.message || 'Please complete your profile',
                        nextSteps: data.nextSteps || []
                    })
                    setPotentialMatches([])
                } else if (data.code === 'USER_NOT_FOUND') {
                    toast.error('Please complete your profile to find study buddies')
                    setActiveTab('profile')
                } else {
                    toast.error(data.error || 'Failed to fetch potential matches')
                }
                setPotentialMatches([])
            }
        } catch (error) {
            console.error('Error fetching potential matches:', error)
            toast.error('Network error. Please check your connection.')
            setPotentialMatches([])
        } finally {
            setLoading(false)
        }
    }

    const fetchExistingMatches = async () => {
        setLoading(true)
        try {
            const response = await fetch('/api/study-buddy/matches')
            if (response.ok) {
                const data = await response.json()
                setExistingMatches(data.matches)
            } else {
                toast.error('Failed to fetch existing matches')
            }
        } catch (error) {
            toast.error('Failed to fetch existing matches')
        } finally {
            setLoading(false)
        }
    }

    const handleSwipe = async (userId: string, action: 'like' | 'pass') => {
        try {
            const response = await fetch('/api/study-buddy/swipe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    targetUserId: userId,
                    action: action,
                }),
            })

            if (response.ok) {
                const result = await response.json()

                if (result.isMutual) {
                    toast.success('🎉 Mutual match! Check your matches tab.')
                    // Refresh matches list if we're on that tab
                    if (activeTab === 'matches') {
                        fetchExistingMatches()
                    }
                } else if (action === 'like') {
                    toast.success('Like sent! Waiting for response.')
                }
            } else {
                const error = await response.json()
                toast.error(error.error || 'Failed to process swipe')
            }
        } catch (error) {
            toast.error('Failed to process swipe')
        }
    }

    const handleMatchAction = async (matchId: string, action: string) => {
        // Refresh the matches list after any action
        await fetchExistingMatches()
    }

    const handleChat = (matchId: string) => {
        // Navigate to messaging system with the specific conversation
        router.push(`/${locale}/messaging?matchId=${matchId}`)
    }

    const handleScheduleSession = (match: StudyBuddyMatchWithDetails) => {
        // For now, show a toast message. Later this can open a modal or navigate to a scheduling page
        toast.success(`Schedule session with ${match.otherUser.name} - Feature coming soon!`)
        // TODO: Implement session scheduling modal or navigation
    }

    return (
        <div className="min-h-screen bg-gray-950">
            {/* Header */}
            <div className="bg-gray-900/80 backdrop-blur-sm border-b border-gray-800">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <div>
                            <h1 className="text-2xl font-bold text-white">Study Buddy</h1>
                            <p className="text-sm text-gray-400">Find your perfect learning partner</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Tabs */}
                <div className="mb-8">
                    <div className="border-b border-gray-800">
                        <nav className="-mb-px flex space-x-8">
                            <button
                                onClick={() => setActiveTab('discover')}
                                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === 'discover'
                                    ? 'border-purple-500 text-purple-400'
                                    : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-700'
                                    }`}
                            >
                                Discover Matches
                                {potentialMatches.length > 0 && (
                                    <span className="ml-2 bg-purple-500/20 text-purple-400 py-0.5 px-2 rounded-full text-xs">
                                        {potentialMatches.length}
                                    </span>
                                )}
                            </button>
                            <button
                                onClick={() => setActiveTab('matches')}
                                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === 'matches'
                                    ? 'border-purple-500 text-purple-400'
                                    : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-700'
                                    }`}
                            >
                                My Matches
                                {existingMatches.length > 0 && (
                                    <span className="ml-2 bg-green-500/20 text-green-400 py-0.5 px-2 rounded-full text-xs">
                                        {existingMatches.filter(m => m.status === 'accepted').length}
                                    </span>
                                )}
                            </button>
                        </nav>
                    </div>
                </div>

                {/* Tab Content */}
                {activeTab === 'discover' ? (
                    <div className="space-y-6">
                        {/* Profile Completion Guide - Top Banner */}
                        {profileIncomplete && (
                            <ProfileCompletionGuide
                                missingFields={profileIncomplete.missing}
                                nextSteps={profileIncomplete.nextSteps}
                                completionPercentage={Math.max(0, 100 - (profileIncomplete.missing.length * 12))}
                                onStartEditing={() => {
                                    setActiveTab('profile')
                                    setProfileIncomplete(null)
                                }}
                            />
                        )}

                        {/* Main Content Grid - Two Column Layout */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            {/* Left Column - Swipe Interface (2/3 width) */}
                            <div className="lg:col-span-2">
                                {/* Quick Stats Row */}
                                <div className="grid grid-cols-3 gap-4 mb-6">
                                    <motion.div 
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.1 }}
                                        className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 backdrop-blur-sm border border-purple-400/20 rounded-2xl p-4"
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-purple-500/20 rounded-xl">
                                                <Users className="w-5 h-5 text-purple-400" />
                                            </div>
                                            <div>
                                                <div className="text-2xl font-bold text-white">{potentialMatches.length}</div>
                                                <div className="text-xs text-gray-400">Available</div>
                                            </div>
                                        </div>
                                    </motion.div>

                                    <motion.div 
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.2 }}
                                        className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 backdrop-blur-sm border border-blue-400/20 rounded-2xl p-4"
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-blue-500/20 rounded-xl">
                                                <TrendingUp className="w-5 h-5 text-blue-400" />
                                            </div>
                                            <div>
                                                <div className="text-2xl font-bold text-white">
                                                    {Math.round(
                                                        potentialMatches.length > 0 
                                                            ? potentialMatches.reduce((sum, match) => sum + match.compatibilityScore, 0) / potentialMatches.length
                                                            : 0
                                                    )}%
                                                </div>
                                                <div className="text-xs text-gray-400">Avg Match</div>
                                            </div>
                                        </div>
                                    </motion.div>

                                    <motion.div 
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.3 }}
                                        className="bg-gradient-to-br from-green-500/10 to-green-600/5 backdrop-blur-sm border border-green-400/20 rounded-2xl p-4"
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-green-500/20 rounded-xl">
                                                <Heart className="w-5 h-5 text-green-400" />
                                            </div>
                                            <div>
                                                <div className="text-2xl font-bold text-white">{existingMatches.filter(m => m.status === 'accepted').length}</div>
                                                <div className="text-xs text-gray-400">Matched</div>
                                            </div>
                                        </div>
                                    </motion.div>
                                </div>

                                {/* Swipe Card - Center Focus */}
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.95 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    transition={{ delay: 0.4 }}
                                >
                                    <SwipeInterface
                                        potentialMatches={potentialMatches}
                                        onSwipe={handleSwipe}
                                        isLoading={loading}
                                        onMatch={(match) => {
                                            toast.success('New match found!')
                                            setActiveTab('matches')
                                        }}
                                    />
                                </motion.div>

                                {/* How It Works - Compact Version */}
                                <motion.div 
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.5 }}
                                    className="mt-6 bg-gradient-to-r from-purple-500/5 to-blue-500/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
                                >
                                    <div className="flex items-center gap-2 mb-4">
                                        <Brain className="w-5 h-5 text-purple-400" />
                                        <h3 className="text-sm font-semibold text-white">How It Works</h3>
                                    </div>
                                    <div className="grid grid-cols-3 gap-3 text-xs">
                                        <div className="flex items-start gap-2">
                                            <div className="p-1.5 bg-purple-500/20 rounded-lg flex-shrink-0 mt-0.5">
                                                <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
                                            </div>
                                            <div>
                                                <div className="font-medium text-white mb-1">Smart Discovery</div>
                                                <div className="text-gray-400 leading-relaxed">AI analyzes your preferences</div>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <div className="p-1.5 bg-blue-500/20 rounded-lg flex-shrink-0 mt-0.5">
                                                <Heart className="w-3.5 h-3.5 text-blue-400" />
                                            </div>
                                            <div>
                                                <div className="font-medium text-white mb-1">Swipe to Connect</div>
                                                <div className="text-gray-400 leading-relaxed">Right to like, left to pass</div>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-2">
                                            <div className="p-1.5 bg-green-500/20 rounded-lg flex-shrink-0 mt-0.5">
                                                <Zap className="w-3.5 h-3.5 text-green-400" />
                                            </div>
                                            <div>
                                                <div className="font-medium text-white mb-1">Start Learning</div>
                                                <div className="text-gray-400 leading-relaxed">Chat and schedule sessions</div>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            </div>

                            {/* Right Column - Insights Sidebar (1/3 width) */}
                            <motion.div 
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.4 }}
                                className="lg:col-span-1"
                            >
                                <MatchingInsights
                                    totalMatches={potentialMatches.length}
                                    averageCompatibility={Math.round(
                                        potentialMatches.length > 0 
                                            ? potentialMatches.reduce((sum, match) => sum + match.compatibilityScore, 0) / potentialMatches.length
                                            : 0
                                    )}
                                    topCategories={
                                        [...new Set(
                                            potentialMatches
                                                .flatMap(match => [...match.sharedInterests, ...match.sharedGoals])
                                                .filter(item => item && item.length > 0)
                                        )].slice(0, 8)
                                    }
                                    matchingStats={{
                                        interestsMatches: potentialMatches.filter(match => match.sharedInterests.length > 0).length,
                                        goalsMatches: potentialMatches.filter(match => match.sharedGoals.length > 0).length,
                                        scheduleMatches: potentialMatches.filter(match => match.compatibilityBreakdown?.scheduleScore && match.compatibilityBreakdown.scheduleScore > 60).length,
                                        communicationMatches: potentialMatches.filter(match => match.compatibilityBreakdown?.communicationScore && match.compatibilityBreakdown.communicationScore > 70).length,
                                    }}
                                />
                            </motion.div>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-6">
                        {/* Matches Tab Stats Header */}
                        <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="grid grid-cols-2 lg:grid-cols-4 gap-4"
                        >
                            <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 backdrop-blur-sm border border-purple-400/20 rounded-2xl p-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-purple-500/20 rounded-xl">
                                        <Users className="w-6 h-6 text-purple-400" />
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white">{existingMatches.length}</div>
                                        <div className="text-xs text-gray-400">Total Matches</div>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gradient-to-br from-green-500/10 to-green-600/5 backdrop-blur-sm border border-green-400/20 rounded-2xl p-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-green-500/20 rounded-xl">
                                        <CheckCircle className="w-6 h-6 text-green-400" />
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white">
                                            {existingMatches.filter(m => m.status === 'accepted').length}
                                        </div>
                                        <div className="text-xs text-gray-400">Active</div>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/5 backdrop-blur-sm border border-yellow-400/20 rounded-2xl p-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-yellow-500/20 rounded-xl">
                                        <Clock className="w-6 h-6 text-yellow-400" />
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white">
                                            {existingMatches.filter(m => m.status === 'pending').length}
                                        </div>
                                        <div className="text-xs text-gray-400">Pending</div>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 backdrop-blur-sm border border-blue-400/20 rounded-2xl p-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-blue-500/20 rounded-xl">
                                        <MessageCircle className="w-6 h-6 text-blue-400" />
                                    </div>
                                    <div>
                                        <div className="text-2xl font-bold text-white">
                                            {existingMatches.filter(m => m.chatRoomId).length}
                                        </div>
                                        <div className="text-xs text-gray-400">Chatting</div>
                                    </div>
                                </div>
                            </div>
                        </motion.div>

                        {/* Matches List Component */}
                        <MatchesList
                            initialMatches={existingMatches}
                            onMatchAction={handleMatchAction}
                            onChat={handleChat}
                            onScheduleSession={handleScheduleSession}
                        />
                    </div>
                )}
            </div>
        </div>
    )
}