'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter, useSearchParams } from 'next/navigation'
import {
  FileText,
  Link as LinkIcon,
  Video,
  Image as ImageIcon,
  File,
  Plus,
  Pin,
  Trash2,
  Edit,
  Target,
  PlayCircle,
  ArrowLeft,
  Upload,
  StickyNote,
  Check,
  Calendar,
  TrendingUp
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import toast from 'react-hot-toast'
import Link from 'next/link'

interface Workspace {
  id: string
  name: string
  description?: string
  resources: WorkspaceResource[]
  notes: WorkspaceNote[]
  goals: WorkspaceGoal[]
  coWatchSessions: CoWatchSession[]
}

interface WorkspaceResource {
  id: string
  title: string
  description?: string
  type: string
  url: string
  isPinned: boolean
  uploader: {
    id: string
    name: string
  }
  createdAt: string
}

interface WorkspaceNote {
  id: string
  title: string
  content: string
  color?: string
  isPinned: boolean
  creator: {
    id: string
    name: string
  }
  createdAt: string
  updatedAt: string
}

interface WorkspaceGoal {
  id: string
  title: string
  description?: string
  status: string
  progress: number
  targetDate?: string
  priority?: string
  creator: {
    id: string
    name: string
  }
  createdAt: string
}

interface CoWatchSession {
  id: string
  videoTitle: string
  videoUrl: string
  currentTime: number
  isPlaying: boolean
  status: string
}

export default function WorkspacePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const params = useParams()
  const searchParams = useSearchParams()
  const locale = params.locale as string || 'en'
  const isArabic = locale === 'ar'
  const matchId = searchParams.get('matchId')

  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'resources' | 'notes' | 'goals' | 'cowatch'>('resources')

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push(`/${locale}/auth/login`)
      return
    }

    if (status === 'authenticated' && matchId) {
      fetchWorkspace()
    }
  }, [status, matchId, router, locale])

  const fetchWorkspace = async () => {
    try {
      const response = await fetch(`/api/study-buddy/workspace?matchId=${matchId}`)
      if (response.ok) {
        const data = await response.json()
        setWorkspace(data.workspace)
      } else {
        toast.error(isArabic ? 'فشل تحميل مساحة العمل' : 'Failed to load workspace')
      }
    } catch (error) {
      console.error('Error fetching workspace:', error)
      toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const getResourceIcon = (type: string) => {
    switch (type.toUpperCase()) {
      case 'PDF':
      case 'DOCUMENT':
        return <FileText className="w-5 h-5" />
      case 'LINK':
        return <LinkIcon className="w-5 h-5" />
      case 'VIDEO':
        return <Video className="w-5 h-5" />
      case 'IMAGE':
        return <ImageIcon className="w-5 h-5" />
      default:
        return <File className="w-5 h-5" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-500/20 text-green-300 border-green-400/30'
      case 'IN_PROGRESS':
        return 'bg-blue-500/20 text-blue-300 border-blue-400/30'
      case 'NOT_STARTED':
        return 'bg-gray-500/20 text-gray-300 border-gray-400/30'
      case 'PAUSED':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-400/30'
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-400/30'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto"></div>
          <p className="mt-6 text-xl text-purple-200">
            {isArabic ? 'جار تحميل مساحة العمل...' : 'Loading workspace...'}
          </p>
        </div>
      </div>
    )
  }

  if (!workspace) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center p-4">
        <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-8 text-center max-w-md">
          <h2 className="text-2xl font-bold text-white mb-4">
            {isArabic ? 'مساحة العمل غير موجودة' : 'Workspace Not Found'}
          </h2>
          <p className="text-gray-300 mb-6">
            {isArabic 
              ? 'لم نتمكن من العثور على مساحة العمل المطلوبة'
              : 'We couldn\'t find the requested workspace'}
          </p>
          <Link href={`/${locale}/study-buddy/matches`}>
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {isArabic ? 'العودة إلى التطابقات' : 'Back to Matches'}
            </Button>
          </Link>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4" dir={isArabic ? 'rtl' : 'ltr'}>
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href={`/${locale}/study-buddy/matches`}>
            <Button variant="ghost" className="text-white">
              <ArrowLeft className={`w-5 h-5 ${isArabic ? 'rotate-180' : ''}`} />
            </Button>
          </Link>
          <div className="text-center flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">{workspace.name}</h1>
            {workspace.description && (
              <p className="text-gray-400">{workspace.description}</p>
            )}
          </div>
          <div className="w-20"></div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <Button
            onClick={() => setActiveTab('resources')}
            className={`${
              activeTab === 'resources'
                ? 'bg-purple-600 hover:bg-purple-700'
                : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <Upload className="w-4 h-4 mr-2" />
            {isArabic ? 'الموارد' : 'Resources'}
            <Badge className="ml-2 bg-white/20">{workspace.resources.length}</Badge>
          </Button>

          <Button
            onClick={() => setActiveTab('notes')}
            className={`${
              activeTab === 'notes'
                ? 'bg-yellow-600 hover:bg-yellow-700'
                : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <StickyNote className="w-4 h-4 mr-2" />
            {isArabic ? 'الملاحظات' : 'Notes'}
            <Badge className="ml-2 bg-white/20">{workspace.notes.length}</Badge>
          </Button>

          <Button
            onClick={() => setActiveTab('goals')}
            className={`${
              activeTab === 'goals'
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <Target className="w-4 h-4 mr-2" />
            {isArabic ? 'الأهداف' : 'Goals'}
            <Badge className="ml-2 bg-white/20">{workspace.goals.length}</Badge>
          </Button>

          <Button
            onClick={() => setActiveTab('cowatch')}
            className={`${
              activeTab === 'cowatch'
                ? 'bg-pink-600 hover:bg-pink-700'
                : 'bg-gray-800 hover:bg-gray-700'
            }`}
          >
            <PlayCircle className="w-4 h-4 mr-2" />
            {isArabic ? 'مشاهدة معًا' : 'Co-Watch'}
          </Button>
        </div>

        {/* Tab Content */}
        {activeTab === 'resources' && (
          <ResourcesTab 
            resources={workspace.resources}
            workspaceId={workspace.id}
            onRefresh={fetchWorkspace}
            isArabic={isArabic}
          />
        )}

        {activeTab === 'notes' && (
          <NotesTab 
            notes={workspace.notes}
            workspaceId={workspace.id}
            onRefresh={fetchWorkspace}
            isArabic={isArabic}
          />
        )}

        {activeTab === 'goals' && (
          <GoalsTab 
            goals={workspace.goals}
            workspaceId={workspace.id}
            onRefresh={fetchWorkspace}
            isArabic={isArabic}
          />
        )}

        {activeTab === 'cowatch' && (
          <CoWatchTab 
            sessions={workspace.coWatchSessions}
            workspaceId={workspace.id}
            onRefresh={fetchWorkspace}
            isArabic={isArabic}
          />
        )}
      </div>
    </div>
  )
}

// Resources Tab Component
function ResourcesTab({ resources, workspaceId, onRefresh, isArabic }: any) {
  const [showUpload, setShowUpload] = useState(false)

  return (
    <div className="space-y-6">
      {/* Upload Button */}
      <div className="flex justify-end">
        <Button
          onClick={() => setShowUpload(true)}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:opacity-90"
        >
          <Plus className="w-4 h-4 mr-2" />
          {isArabic ? 'إضافة مورد' : 'Add Resource'}
        </Button>
      </div>

      {/* Resources Grid */}
      {resources.length === 0 ? (
        <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-12 text-center">
          <Upload className="w-16 h-16 text-gray-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-white mb-2">
            {isArabic ? 'لا توجد موارد حتى الآن' : 'No Resources Yet'}
          </h3>
          <p className="text-gray-400 mb-6">
            {isArabic 
              ? 'ابدأ بإضافة موارد لمشاركتها مع شريك الدراسة'
              : 'Start adding resources to share with your study buddy'}
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resources.map((resource: any) => (
            <ResourceCard
              key={resource.id}
              resource={resource}
              onRefresh={onRefresh}
              isArabic={isArabic}
            />
          ))}
        </div>
      )}

      {showUpload && (
        <UploadResourceModal
          workspaceId={workspaceId}
          onClose={() => setShowUpload(false)}
          onSuccess={() => {
            setShowUpload(false)
            onRefresh()
          }}
          isArabic={isArabic}
        />
      )}
    </div>
  )
}

// Resource Card Component
function ResourceCard({ resource, onRefresh, isArabic }: any) {
  const getResourceIcon = (type: string) => {
    switch (type.toUpperCase()) {
      case 'PDF':
      case 'DOCUMENT':
        return <FileText className="w-6 h-6 text-red-400" />
      case 'LINK':
        return <LinkIcon className="w-6 h-6 text-blue-400" />
      case 'VIDEO':
        return <Video className="w-6 h-6 text-purple-400" />
      case 'IMAGE':
        return <ImageIcon className="w-6 h-6 text-green-400" />
      default:
        return <File className="w-6 h-6 text-gray-400" />
    }
  }

  const handleDelete = async () => {
    if (!confirm(isArabic ? 'هل أنت متأكد؟' : 'Are you sure?')) return

    try {
      const response = await fetch(`/api/study-buddy/workspace/resources?id=${resource.id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        toast.success(isArabic ? 'تم الحذف بنجاح' : 'Deleted successfully')
        onRefresh()
      } else {
        toast.error(isArabic ? 'فشل الحذف' : 'Failed to delete')
      }
    } catch (error) {
      toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
    }
  }

  return (
    <Card className="bg-gray-800/80 backdrop-blur-md border-gray-700/50 p-4 hover:border-purple-500/50 transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {getResourceIcon(resource.type)}
          <div>
            <h3 className="font-semibold text-white">{resource.title}</h3>
            <p className="text-sm text-gray-400">{resource.uploader.name}</p>
          </div>
        </div>
        <button
          onClick={handleDelete}
          className="text-gray-400 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {resource.description && (
        <p className="text-sm text-gray-300 mb-3">{resource.description}</p>
      )}

      <a
        href={resource.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm text-purple-400 hover:text-purple-300 flex items-center gap-1"
      >
        {isArabic ? 'فتح' : 'Open'} →
      </a>
    </Card>
  )
}

// Upload Resource Modal (placeholder - you'd implement file upload)
function UploadResourceModal({ workspaceId, onClose, onSuccess, isArabic }: any) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'LINK',
    url: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch('/api/study-buddy/workspace/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workspaceId,
          ...formData
        })
      })

      if (response.ok) {
        toast.success(isArabic ? 'تمت الإضافة بنجاح' : 'Added successfully')
        onSuccess()
      } else {
        toast.error(isArabic ? 'فشلت الإضافة' : 'Failed to add')
      }
    } catch (error) {
      toast.error(isArabic ? 'حدث خطأ' : 'An error occurred')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="bg-gray-800/90 border-purple-500/50 p-6 max-w-md w-full">
        <h2 className="text-2xl font-bold text-white mb-4">
          {isArabic ? 'إضافة مورد' : 'Add Resource'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-white mb-2">{isArabic ? 'العنوان' : 'Title'}</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
              required
            />
          </div>

          <div>
            <label className="block text-white mb-2">{isArabic ? 'الرابط/URL' : 'URL/Link'}</label>
            <input
              type="url"
              value={formData.url}
              onChange={(e) => setFormData({ ...formData, url: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
              required
            />
          </div>

          <div>
            <label className="block text-white mb-2">{isArabic ? 'النوع' : 'Type'}</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
            >
              <option value="LINK">Link</option>
              <option value="PDF">PDF</option>
              <option value="VIDEO">Video</option>
              <option value="IMAGE">Image</option>
              <option value="DOCUMENT">Document</option>
            </select>
          </div>

          <div>
            <label className="block text-white mb-2">{isArabic ? 'الوصف' : 'Description'}</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
              rows={3}
            />
          </div>

          <div className="flex gap-3">
            <Button type="button" onClick={onClose} variant="outline" className="flex-1">
              {isArabic ? 'إلغاء' : 'Cancel'}
            </Button>
            <Button type="submit" className="flex-1 bg-purple-600 hover:bg-purple-700">
              {isArabic ? 'إضافة' : 'Add'}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  )
}

// Placeholder tabs (Notes, Goals, CoWatch)
function NotesTab({ notes, workspaceId, onRefresh, isArabic }: any) {
  return (
    <div className="text-center text-gray-400 py-12">
      <StickyNote className="w-16 h-16 mx-auto mb-4 text-gray-600" />
      <p>{isArabic ? 'قريبًا: الملاحظات التعاونية' : 'Coming Soon: Collaborative Notes'}</p>
    </div>
  )
}

function GoalsTab({ goals, workspaceId, onRefresh, isArabic }: any) {
  return (
    <div className="text-center text-gray-400 py-12">
      <Target className="w-16 h-16 mx-auto mb-4 text-gray-600" />
      <p>{isArabic ? 'قريبًا: تتبع الأهداف المشتركة' : 'Coming Soon: Shared Goals Tracking'}</p>
    </div>
  )
}

function CoWatchTab({ sessions, workspaceId, onRefresh, isArabic }: any) {
  return (
    <div className="text-center text-gray-400 py-12">
      <PlayCircle className="w-16 h-16 mx-auto mb-4 text-gray-600" />
      <p>{isArabic ? 'قريبًا: مشاهدة الفيديوهات معًا' : 'Coming Soon: Watch Videos Together'}</p>
    </div>
  )
}
