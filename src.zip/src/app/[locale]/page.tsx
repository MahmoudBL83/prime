'use client';

import { useState, useEffect } from 'react';
import { Hero } from '@/components/landing/Hero';
import { NetflixCourseShowcase } from '@/components/landing/NetflixCourseShowcase';
import { StreamingShowcase } from '@/components/landing/StreamingShowcase';
import { useStreamingCourses } from '@/components/landing/streamingCourseData';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useHomepageCourses } from '@/hooks/useHomepageCourses';
import { motion } from 'framer-motion';
import { useRouter, useParams } from 'next/navigation';
import { useTranslationsSafe } from '@/hooks/useTranslationsSafe';
import { useNavigationLoading } from '@/hooks/useNavigationLoading';
import { LoadingButton } from '@/components/ui/LoadingButton';
import { Sparkles, BookOpen, Users, Trophy, Globe, Video, Award, MessageCircle } from 'lucide-react';

export default function Home() {
    const { ref, inView, animationProps } = useScrollAnimation();
    const router = useRouter();
    const params = useParams();
    const { navigateWithLoading, isLoading, resetLoading } = useNavigationLoading();
    const { t } = useTranslationsSafe('landing');
    const { t: tCommon } = useTranslationsSafe('common');
    const { t: tCourses } = useTranslationsSafe('courses');
    const { locale } = useTranslationsSafe('landing');
    
    const currentLocale = params?.locale as string || 'en'
    const lang = currentLocale === 'ar' ? 'ar' : 'en'

    // Fetch real course data from database
    const { data: homepageData, loading, error } = useHomepageCourses();

    // Get static streaming course data as fallback
    const { topCourses: staticTopCourses, newReleases: staticNewReleases, featuredEgyptian } = useStreamingCourses();

    return (
        <div className="min-h-screen bg-black relative overflow-hidden">
            {/* Clean Background with Subtle Accents */}
            <div className="absolute inset-0 pointer-events-none">
                {/* Subtle gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-b from-gray-900/30 via-black to-black"></div>
                
                {/* Minimal decorative elements */}
                <div className="absolute top-1/4 left-10 w-32 h-32 bg-purple-600/5 rounded-full blur-3xl"></div>
                <div className="absolute bottom-1/3 right-10 w-40 h-40 bg-blue-600/5 rounded-full blur-3xl"></div>
            </div>
            
            {/* Hero Section */}
            <Hero />

            {/* Streaming-Style Course Showcase */}
            <div className="relative py-8 px-4 sm:px-6 lg:px-8">
                {/* Clean section background */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"></div>
                {loading && (
                    <div className="flex items-center justify-center py-20">
                        <div className="relative">
                            <div className="absolute inset-0 w-16 h-16 border-4 border-purple-500/30 rounded-full animate-ping"></div>
                            <div className="w-16 h-16 border-4 border-purple-500/50 border-t-purple-400 rounded-full animate-spin mx-auto mb-6"></div>
                        </div>
                        <div className="ml-4">
                            <p className="text-purple-200 text-lg font-medium">Loading courses...</p>
                            <p className="text-gray-400 text-sm mt-1">Discovering amazing content for you</p>
                        </div>
                    </div>
                )}

                {error && (
                    <div className="flex items-center justify-center py-20">
                        <div className="bg-red-500/20 backdrop-blur-sm border border-red-500/30 rounded-2xl p-6 text-center max-w-md">
                            <div className="text-red-400 text-xl mb-2">⚠️ Unable to Load Courses</div>
                            <div className="text-red-300">Error: {error}</div>
                            <button 
                                onClick={() => window.location.reload()} 
                                className="mt-4 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                            >
                                Try Again
                            </button>
                        </div>
                    </div>
                )}

                {!loading && !error && homepageData && homepageData.totalCourses > 0 && (
                    <>
                        {/* Top Trending Courses - Netflix Style */}
                        {homepageData.topCourses.length > 0 && (
                            <NetflixCourseShowcase
                                title={lang === 'ar' ? '🔥 الدورات الأكثر رواجاً' : '🔥 Trending Now'}
                                courses={homepageData.topCourses.slice(0, 12)}
                                lang={lang}
                                onCourseClick={(id) => router.push(`/${currentLocale}/courses/${id}`)}
                            />
                        )}

                        {/* Featured Courses - Netflix Style */}
                        {homepageData.featuredCourses.length > 0 && (
                            <NetflixCourseShowcase
                                title={lang === 'ar' ? '⭐ دورات مميزة لك' : '⭐ Popular on Platform'}
                                courses={homepageData.featuredCourses.slice(0, 12)}
                                lang={lang}
                                onCourseClick={(id) => router.push(`/${currentLocale}/courses/${id}`)}
                            />
                        )}
                    </>
                )}

                {/* Fallback to static data if no database courses */}
                {!loading && !error && (!homepageData || homepageData.totalCourses === 0) && (
                    <>
                        <div className="text-center py-12 mb-8">
                            <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border border-yellow-500/30 rounded-2xl p-6 max-w-2xl mx-auto">
                                <div className="text-yellow-400 text-2xl mb-2">🚧 Demo Mode</div>
                                <p className="text-yellow-300 text-lg font-medium mb-2">Using Sample Course Data</p>
                                <p className="text-gray-400">Connect to database for real courses and content!</p>
                            </div>
                        </div>
                        
                        {/* Static Top Courses - Netflix Style */}
                        <NetflixCourseShowcase
                            title={lang === 'ar' ? '🔥 الدورات الأكثر رواجاً' : '🔥 Trending Now'}
                            courses={staticTopCourses as any}
                            lang={lang}
                            onCourseClick={(id) => router.push(`/${currentLocale}/courses/${id}`)}
                        />

                        {/* Static New Releases - Netflix Style */}
                        <NetflixCourseShowcase
                            title={lang === 'ar' ? '🆕 أحدث الإصدارات' : '🆕 New Releases'}
                            courses={staticNewReleases as any}
                            lang={lang}
                            onCourseClick={(id) => router.push(`/${currentLocale}/courses/${id}`)}
                        />
                    </>
                )}
            </div>

            {/* Call to Action Section - Enhanced Learning Ecosystem */}
            <section className="relative py-32 px-4 md:px-8 overflow-hidden" ref={ref}>
                {/* Premium background effects */}
                <div className="absolute inset-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-black via-gray-900 to-black"></div>
                    <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent"></div>
                    
                    {/* Animated orbs */}
                    <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
                    <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-purple-500/5 to-blue-500/5 rounded-full blur-3xl"></div>
                </div>
                
                <div className="relative max-w-7xl mx-auto">
                    {/* Main heading */}
                    <div className="text-center mb-20">
                        <motion.div
                            className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-purple-500/10 backdrop-blur-sm border border-purple-500/20 rounded-full px-8 py-3 mb-8"
                            initial={{ opacity: 0, y: 20 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                            transition={{ duration: 0.6 }}
                        >
                            <Sparkles className="w-5 h-5 text-purple-400" />
                            <span className="text-base font-semibold bg-gradient-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
                                The World's Most Complete Learning Ecosystem
                            </span>
                            <Sparkles className="w-5 h-5 text-blue-400" />
                        </motion.div>
                        
                        <motion.h2 
                            className="text-5xl md:text-6xl lg:text-7xl font-black mb-8 leading-tight"
                            initial={{ opacity: 0, y: 30 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                            transition={{ duration: 0.7, delay: 0.1 }}
                        >
                            <span className="bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
                                Transform Your Future
                            </span>
                            <br />
                            <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                                With Expert-Led Learning
                            </span>
                        </motion.h2>
                        
                        <motion.p 
                            className="text-xl md:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-4"
                            initial={{ opacity: 0, y: 20 }}
                            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                        >
                            Access thousands of courses, connect with study partners, learn from world-class creators,
                            <br />and unlock your potential with our all-in-one learning platform.
                        </motion.p>

                        <motion.p 
                            className="text-lg text-purple-300/80 max-w-3xl mx-auto"
                            initial={{ opacity: 0 }}
                            animate={inView ? { opacity: 1 } : { opacity: 0 }}
                            transition={{ duration: 0.6, delay: 0.3 }}
                        >
                            Join <span className="font-bold text-purple-200">25,000+ active learners</span> already transforming their careers
                        </motion.p>
                    </div>

                    {/* Three-tier value proposition cards */}
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
                        initial={{ opacity: 0, y: 40 }}
                        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                    >
                        {/* Category A - All-Access Library */}
                        <motion.div
                            className="group relative bg-gradient-to-br from-gray-900/90 via-purple-900/20 to-gray-900/90 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 hover:border-purple-400/40 transition-all duration-500 overflow-hidden"
                            whileHover={{ scale: 1.03, y: -5 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            
                            <div className="relative">
                                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-purple-500/50 group-hover:shadow-purple-500/70 transition-shadow duration-500">
                                    <BookOpen className="w-8 h-8 text-white" />
                                </div>
                                
                                <h3 className="text-2xl font-bold text-white mb-3">All-Access Library</h3>
                                <p className="text-gray-300 mb-6 leading-relaxed">
                                    Unlimited access to thousands of expert courses across every topic. Learn at your own pace.
                                </p>
                                
                                <div className="space-y-3">
                                    {['Unlimited course access', 'Download for offline', 'Progress tracking', 'Certificates'].map((feature, idx) => (
                                        <div key={idx} className="flex items-center gap-3 text-sm text-gray-400">
                                            <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                                            <span>{feature}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </motion.div>

                        {/* Category B - Signature Courses */}
                        <motion.div
                            className="group relative bg-gradient-to-br from-gray-900/90 via-blue-900/20 to-gray-900/90 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-8 hover:border-blue-400/40 transition-all duration-500 overflow-hidden"
                            whileHover={{ scale: 1.03, y: -5 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <div className="absolute top-4 right-4">
                                <span className="inline-flex items-center gap-1 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 text-yellow-300 px-3 py-1 rounded-full text-xs font-bold">
                                    <Award className="w-3 h-3" />
                                    PREMIUM
                                </span>
                            </div>
                            
                            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            
                            <div className="relative">
                                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-500/50 group-hover:shadow-blue-500/70 transition-shadow duration-500">
                                    <Video className="w-8 h-8 text-white" />
                                </div>
                                
                                <h3 className="text-2xl font-bold text-white mb-3">Signature Courses</h3>
                                <p className="text-gray-300 mb-6 leading-relaxed">
                                    Premium, cinematic programs from world-renowned experts. High-production quality guaranteed.
                                </p>
                                
                                <div className="space-y-3">
                                    {['Curated expert programs', 'High-quality production', 'Structured pathways', 'Live Q&A sessions'].map((feature, idx) => (
                                        <div key={idx} className="flex items-center gap-3 text-sm text-gray-400">
                                            <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                                            <span>{feature}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </motion.div>

                        {/* Category C - Creator Channels */}
                        <motion.div
                            className="group relative bg-gradient-to-br from-gray-900/90 via-purple-900/20 to-gray-900/90 backdrop-blur-xl border border-purple-500/20 rounded-3xl p-8 hover:border-purple-400/40 transition-all duration-500 overflow-hidden"
                            whileHover={{ scale: 1.03, y: -5 }}
                            transition={{ type: "spring", stiffness: 300 }}
                        >
                            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            
                            <div className="relative">
                                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-purple-500/50 group-hover:shadow-purple-500/70 transition-shadow duration-500">
                                    <Users className="w-8 h-8 text-white" />
                                </div>
                                
                                <h3 className="text-2xl font-bold text-white mb-3">Creator Channels</h3>
                                <p className="text-gray-300 mb-6 leading-relaxed">
                                    Subscribe to your favorite creators for personalized coaching and exclusive community access.
                                </p>
                                
                                <div className="space-y-3">
                                    {['1:1 coaching sessions', 'Private communities', 'Live workshops', 'Direct feedback'].map((feature, idx) => (
                                        <div key={idx} className="flex items-center gap-3 text-sm text-gray-400">
                                            <div className="w-1.5 h-1.5 bg-pink-400 rounded-full"></div>
                                            <span>{feature}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>

                    {/* Bonus Features Section */}
                    <motion.div
                        className="mb-16"
                        initial={{ opacity: 0, y: 30 }}
                        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                        transition={{ duration: 0.8, delay: 0.6 }}
                    >
                        <div className="bg-gradient-to-br from-gray-900/50 via-gray-800/30 to-gray-900/50 backdrop-blur-xl border border-white/10 rounded-3xl p-10">
                            <h3 className="text-2xl font-bold text-center text-white mb-10">
                                <span className="bg-gradient-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
                                    Plus These Amazing Features
                                </span>
                            </h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                                {[
                                    { icon: MessageCircle, title: 'Study Buddy Matching', desc: 'Find perfect study partners' },
                                    { icon: Trophy, title: 'Rewards & Scholarships', desc: 'Earn prizes for excellence' },
                                    { icon: Globe, title: 'Multi-Language Support', desc: 'Learn in your language' },
                                    { icon: Award, title: 'Verified Certificates', desc: 'Showcase your achievements' }
                                ].map((feature, idx) => (
                                    <div key={idx} className="flex flex-col items-center text-center group">
                                        <div className="w-14 h-14 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                                            <feature.icon className="w-7 h-7 text-purple-400" />
                                        </div>
                                        <h4 className="font-semibold text-white mb-2">{feature.title}</h4>
                                        <p className="text-sm text-gray-400">{feature.desc}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </motion.div>

                    {/* Main CTA Buttons */}
                    <motion.div
                        className="text-center"
                        initial={{ opacity: 0, y: 40 }}
                        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
                        transition={{ duration: 0.8, delay: 0.8 }}
                    >
                        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-8">
                            <LoadingButton
                                onClick={() => navigateWithLoading(`/${locale}/auth/register`, 'register-cta')}
                                loading={isLoading('register-cta')}
                                loadingText="Creating your account..."
                                className="group/btn relative bg-gradient-to-r from-purple-600 via-blue-600 to-purple-600 hover:from-purple-700 hover:via-blue-700 hover:to-purple-700 text-white px-12 py-6 rounded-2xl font-bold text-xl shadow-2xl shadow-purple-500/30 hover:shadow-purple-500/60 transition-all duration-500 hover:scale-105 border-0 overflow-hidden min-w-[280px]"
                            >
                                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 opacity-0 group-hover/btn:opacity-30 transition-opacity duration-500"></div>
                                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9IjAuMDUiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
                                
                                <span className="relative flex items-center justify-center gap-3">
                                    {isLoading('register-cta') && (
                                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                    )}
                                    Start Learning Free
                                    <span className="text-2xl group-hover/btn:translate-x-2 transition-transform duration-300">→</span>
                                </span>
                            </LoadingButton>
                            
                            <LoadingButton
                                onClick={() => navigateWithLoading(`/${locale}/courses`, 'courses-cta')}
                                loading={isLoading('courses-cta')}
                                loadingText="Loading courses..."
                                variant="outline"
                                className="relative bg-white/5 backdrop-blur-sm border-2 border-white/20 text-white hover:bg-white/10 hover:border-white/40 px-12 py-6 rounded-2xl font-bold text-xl transition-all duration-500 hover:scale-105 shadow-xl min-w-[280px]"
                            >
                                <span className="flex items-center justify-center gap-3">
                                    {isLoading('courses-cta') && (
                                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                                    )}
                                    Explore Courses
                                </span>
                            </LoadingButton>
                        </div>

                        <motion.p
                            className="text-sm text-gray-400"
                            initial={{ opacity: 0 }}
                            animate={inView ? { opacity: 1 } : { opacity: 0 }}
                            transition={{ duration: 0.6, delay: 1 }}
                        >
                            No credit card required • Cancel anytime • 14-day money-back guarantee
                        </motion.p>
                    </motion.div>
                </div>
            </section>
        </div>
    );
}