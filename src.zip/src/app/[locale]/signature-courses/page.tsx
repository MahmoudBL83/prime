'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { toast } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Award,
  Star,
  Users,
  Clock,
  BookOpen,
  CheckCircle,
  Loader2,
  Filter,
  Search,
  TrendingUp,
  Sparkles,
  Crown,
  Award as CertificateIcon,
  Video,
  Play,
  Grid,
  List,
  X,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  Plus,
  Check,
  Info,
  Trophy,
  Zap,
  Target,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface SignatureCourse {
  id: string;
  title: string;
  description: string;
  thumbnail?: string;
  instructor: {
    name: string;
    profileImage?: string;
  };
  duration: string;
  enrollmentCount: number;
  rating: number;
  ratingCount: number;
  price: number;
  level: string;
  category: string;
  hasWorkbook: boolean;
  hasCohort: boolean;
  hasExpertQA: boolean;
  hasCapstone: boolean;
  trending?: boolean;
  new?: boolean;
  featured?: boolean;
}

export default function SignatureCoursesPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const params = useParams();
  const locale = params?.locale as string || 'en';
  const lang = locale === 'ar' ? 'ar' : 'en';
  const isRTL = lang === 'ar';
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<SignatureCourse[]>([]);
  const [hoveredCourse, setHoveredCourse] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [myList, setMyList] = useState<string[]>([]);
  const [showCategoryNav, setShowCategoryNav] = useState(false);

  // Helper function to get random Netflix image for a course
  const getNetflixImage = (courseId: string) => {
    // Use course ID to generate a consistent but random-looking image number
    const hash = courseId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return `/images/courses/netflix${(hash % 6) + 1}.jpg`;
  };

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    try {
      const res = await fetch('/api/signature-courses');
      if (res.ok) {
        const data = await res.json();
        // Add trending and new flags to demo data
        const coursesWithFlags = data.courses.map((course: SignatureCourse, index: number) => ({
          ...course,
          trending: index % 3 === 0,
          new: index % 4 === 0,
          featured: index === 0,
        }));
        setCourses(coursesWithFlags || []);
      } else {
        toast.error('Failed to load signature courses');
      }
    } catch (error) {
      console.error('Error loading courses:', error);
      toast.error('Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    { id: 'all', name: isRTL ? 'الكل' : 'All Courses' },
    { id: 'Technology', name: isRTL ? 'التكنولوجيا' : 'Technology' },
    { id: 'Business', name: isRTL ? 'الأعمال' : 'Business' },
    { id: 'Design', name: isRTL ? 'التصميم' : 'Design' },
    { id: 'Marketing', name: isRTL ? 'التسويق' : 'Marketing' },
    { id: 'Data Science', name: isRTL ? 'علم البيانات' : 'Data Science' },
  ];

  const featuredCourse = courses.find(c => c.featured) || courses[0];
  const trendingCourses = courses.filter(c => c.trending);
  const newCourses = courses.filter(c => c.new);
  
  const filteredCourses = selectedCategory === 'all' 
    ? courses 
    : courses.filter(c => c.category === selectedCategory);

  const toggleMyList = (courseId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setMyList(prev => 
      prev.includes(courseId) 
        ? prev.filter(id => id !== courseId)
        : [...prev, courseId]
    );
    toast.success(
      myList.includes(courseId)
        ? isRTL ? 'تم الإزالة من قائمتي' : 'Removed from My List'
        : isRTL ? 'تم الإضافة إلى قائمتي' : 'Added to My List'
    );
  };

  const t = {
    en: {
      myList: 'My List',
      trending: 'Trending Now',
      new: 'New Releases',
      allCourses: 'All Courses',
      startNow: 'Start Now',
      moreInfo: 'More Info',
      students: 'students',
      signature: 'Signature',
      loading: 'Loading...',
      readyToStart: 'Ready to Start Your Learning Journey?',
      joinThousands: 'Join thousands of students and earn globally recognized certificates',
      exploreAll: 'Explore All Courses',
    },
    ar: {
      myList: 'قائمتي',
      trending: 'رائج الآن',
      new: 'إصدارات جديدة',
      allCourses: 'جميع الدورات',
      startNow: 'ابدأ الآن',
      moreInfo: 'المزيد',
      students: 'طالب',
      signature: 'مميز',
      loading: 'جاري التحميل...',
      readyToStart: 'جاهز لبدء رحلتك التعليمية؟',
      joinThousands: 'انضم إلى آلاف الطلاب واحصل على شهادات معترف بها عالمياً',
      exploreAll: 'استكشف جميع الدورات',
    },
  };

  const currentT = t[lang];

  // Netflix-style Course Row Component
  const CourseRow = ({ title, courses, categoryId }: { title: string, courses: SignatureCourse[], categoryId?: string }) => {
    const scroll = (direction: 'left' | 'right') => {
      const container = document.getElementById(`row-${categoryId || title}`);
      if (container) {
        const scrollAmount = direction === 'left' ? -1000 : 1000;
        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    };

    const handleCardHover = (courseId: string, event: React.MouseEvent<HTMLDivElement>) => {
      setHoveredCourse(courseId);
      
      // Scroll the card into view when hovering
      const card = event.currentTarget;
      const container = document.getElementById(`row-${categoryId || title}`);
      
      if (container && card) {
        const containerRect = container.getBoundingClientRect();
        const cardRect = card.getBoundingClientRect();
        
        // Calculate if card is partially hidden
        const isPartiallyHiddenLeft = cardRect.left < containerRect.left;
        const isPartiallyHiddenRight = cardRect.right > containerRect.right;
        
        if (isPartiallyHiddenLeft || isPartiallyHiddenRight) {
          // Scroll to center the card
          const scrollLeft = card.offsetLeft - (containerRect.width / 2) + (cardRect.width / 2);
          container.scrollTo({
            left: scrollLeft,
            behavior: 'smooth'
          });
        }
      }
    };

    return (
      <div className="mb-48 group/row" style={{ overflow: 'visible', minHeight: '400px' }}>
        <div className="flex items-center justify-between mb-4 px-4 sm:px-12">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white hover:text-gray-300 transition-colors cursor-pointer">
            {title}
          </h2>
          <button 
            onClick={() => setSelectedCategory(categoryId || 'all')}
            className="text-xs sm:text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1 group/explore"
          >
            <span>{isRTL ? 'استكشف الكل' : 'Explore All'}</span>
            <ChevronRight className="w-4 h-4 group-hover/explore:translate-x-1 transition-transform" />
          </button>
        </div>
        <div className="relative" style={{ overflow: 'visible' }}>
          {/* Scroll Buttons */}
          <button
            onClick={() => scroll('left')}
            className="absolute left-0 top-0 bottom-0 z-[60] bg-black/80 hover:bg-black w-12 flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity"
          >
            <ChevronLeft className="w-8 h-8 text-white" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="absolute right-0 top-0 bottom-0 z-[60] bg-black/80 hover:bg-black w-12 flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity"
          >
            <ChevronRight className="w-8 h-8 text-white" />
          </button>

          {/* Course Cards Scroll */}
          <div
            id={`row-${categoryId || title}`}
            className="flex gap-4 overflow-x-auto scrollbar-hide px-4 sm:px-12 py-12"
            style={{ 
              scrollbarWidth: 'none', 
              msOverflowStyle: 'none',
              overflowY: 'visible',
              paddingBottom: '280px',
              marginBottom: '-280px',
            }}
          >
            {courses.map((course, index) => (
              <div
                key={course.id}
                className="flex-shrink-0 w-[300px] sm:w-[350px]"
                onMouseEnter={(e) => handleCardHover(course.id, e)}
                onMouseLeave={() => setHoveredCourse(null)}
              >
                <div 
                  className={`relative transition-all duration-300 ease-in-out ${
                    hoveredCourse === course.id ? 'z-[9999]' : 'z-10'
                  }`}
                  style={{ 
                    transform: hoveredCourse === course.id 
                      ? 'scale(1.3) translateY(-10px)' 
                      : 'scale(1) translateY(0)',
                    transformOrigin: 'center center',
                    transitionDuration: '0.3s',
                    transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                >
                  <div 
                    className={`relative aspect-video overflow-hidden cursor-pointer transition-all duration-300 ${
                      hoveredCourse === course.id ? 'rounded-lg shadow-2xl' : 'rounded-md shadow-lg'
                    }`}
                    onClick={() => router.push(`/${locale}/courses/${course.id}`)}
                  >
                    {/* Netflix-style Thumbnail with Random Images */}
                    <img 
                      src={getNetflixImage(course.id)} 
                      alt={course.title} 
                      className="w-full h-full object-cover" 
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        const parent = target.parentElement;
                        if (parent) {
                          const fallback = document.createElement('div');
                          fallback.className = 'absolute inset-0 bg-gradient-to-br from-purple-900 via-black to-pink-900';
                          parent.appendChild(fallback);
                        }
                      }}
                    />
                    
                    {/* Platform Logo - Top Left (Netflix Style) */}
                    <div className="absolute top-3 left-3 z-20">
                      <div className="bg-[#E50914] rounded-sm shadow-xl px-2 py-1 flex items-center gap-1.5">
                        <span className="text-white font-black text-2xl leading-none" style={{ fontFamily: 'Arial Black, sans-serif' }}>N</span>
                      </div>
                    </div>

                    {/* Overlay on Hover */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredCourse === course.id ? 1 : 0 }}
                      transition={{ duration: 0.2 }}
                      className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-center justify-center"
                    >
                      <motion.div
                        initial={{ scale: 0.8 }}
                        animate={{ scale: hoveredCourse === course.id ? 1 : 0.8 }}
                        transition={{ duration: 0.3, delay: 0.1 }}
                        className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white/60"
                      >
                        <Play className="w-8 h-8 text-white ml-1" fill="white" />
                      </motion.div>
                    </motion.div>

                    {/* Add to List Button - Top Right */}
                    <button
                      onClick={(e) => toggleMyList(course.id, e)}
                      className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/80 border-2 border-white hover:border-white flex items-center justify-center transition-all z-10 opacity-0 group-hover:opacity-100"
                    >
                      {myList.includes(course.id) ? (
                        <Check className="w-4 h-4 text-white" />
                      ) : (
                        <Plus className="w-4 h-4 text-white" />
                      )}
                    </button>
                  </div>

                  {/* Expanded Info on Hover - Overlay Style */}
                  <AnimatePresence>
                    {hoveredCourse === course.id && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.3, delay: 0.15 }}
                        className="absolute top-full left-0 right-0 bg-[#181818] rounded-b-lg shadow-2xl"
                        style={{ marginTop: '-4px' }}
                      >
                        {/* Action Buttons Row */}
                        <div className="flex items-center gap-2 p-3 pb-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              router.push(`/${locale}/courses/${course.id}`);
                            }}
                            className="w-8 h-8 bg-white hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
                          >
                            <Play className="w-4 h-4 text-black ml-0.5" fill="black" />
                          </button>
                          
                          <button
                            onClick={(e) => toggleMyList(course.id, e)}
                            className="w-8 h-8 bg-transparent hover:bg-gray-700 border-2 border-gray-400 hover:border-white rounded-full flex items-center justify-center transition-colors"
                          >
                            {myList.includes(course.id) ? (
                              <Check className="w-4 h-4 text-white" />
                            ) : (
                              <Plus className="w-4 h-4 text-white" />
                            )}
                          </button>

                          <div className="flex-1"></div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              router.push(`/${locale}/courses/${course.id}`);
                            }}
                            className="w-8 h-8 bg-transparent hover:bg-gray-700 border-2 border-gray-400 hover:border-white rounded-full flex items-center justify-center transition-colors"
                          >
                            <Info className="w-4 h-4 text-white" />
                          </button>
                        </div>

                        {/* Info Section */}
                        <div className="px-3 pb-3">
                          {/* Stats Row */}
                          <div className="flex items-center gap-2 mb-2 text-xs">
                            <span className="text-green-500 font-semibold">{(course.rating * 10).toFixed(0)}% Match</span>
                            <span className="border border-gray-500 px-1 text-gray-400 text-[10px]">
                              {course.level}
                            </span>
                            <span className="text-gray-400">{course.duration}</span>
                          </div>

                          {/* Description */}
                          <p className="text-gray-400 text-xs line-clamp-2 mb-2 leading-relaxed">
                            {course.description}
                          </p>

                          {/* Tags */}
                          <div className="flex flex-wrap gap-1 text-[11px] text-gray-400">
                            <span>{course.category}</span>
                            <span>•</span>
                            <span>{course.instructor.name}</span>
                            {course.hasWorkbook && (
                              <>
                                <span>•</span>
                                <span>{isRTL ? 'كتب عمل' : 'Workbooks'}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-red-600" />
          <span className="text-white text-lg">{currentT.loading}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Hero Section - Netflix Billboard Style */}
      <div className="relative h-[80vh] w-full">
        {/* Background Gradient */}
        <>
          <img 
            src="/images/courses/netflix7.jpg" 
            alt="Featured Course"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50" />
        </>
        
        {/* Vignette */}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-transparent" />

        {/* Content */}
        <div className="relative z-10 h-full flex items-center px-4 sm:px-12">
          <div className="max-w-2xl">
            {/* Category Badge */}
            <Badge className="bg-[#E50914] text-white border-0 mb-4">
              <Crown className="w-3 h-3 mr-1" />
              {currentT.signature}
            </Badge>

            {/* Title */}
            {featuredCourse && (
              <>
                <h1 className="text-4xl sm:text-6xl font-black mb-4">
                  {featuredCourse.title}
                </h1>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-green-500 fill-green-500" />
                    <span className="text-green-500 font-bold">{featuredCourse.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-300">
                    <Users className="w-5 h-5" />
                    <span>{(featuredCourse.enrollmentCount / 1000).toFixed(1)}K {currentT.students}</span>
                  </div>
                  <Badge className="bg-yellow-600 text-white border-0">
                    <Trophy className="w-3 h-3 mr-1" />
                    {isRTL ? 'شهادة' : 'Certificate'}
                  </Badge>
                </div>

                {/* Description */}
                <p className="text-lg text-gray-300 mb-8 max-w-xl line-clamp-3">
                  {featuredCourse.description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-3 mb-8">
                  {[
                    { icon: BookOpen, text: isRTL ? 'كتب عمل' : 'Workbooks' },
                    { icon: Users, text: isRTL ? 'تعلم جماعي' : 'Cohort Learning' },
                    { icon: Target, text: isRTL ? 'مشروع نهائي' : 'Capstone Project' },
                  ].slice(0, 3).map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-1 rounded-full">
                      <Sparkles className="w-4 h-4 text-purple-400" />
                      <span className="text-sm">{feature.text}</span>
                    </div>
                  ))}
                </div>

                {/* CTA Buttons */}
                <div className="flex gap-4">
                  <Button
                    onClick={() => router.push(`/${locale}/courses/${featuredCourse.id}`)}
                    className="bg-white hover:bg-gray-200 text-black font-bold px-8 py-6 text-lg"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    {currentT.startNow}
                  </Button>
                  <Button
                    onClick={() => router.push(`/${locale}/courses/${featuredCourse.id}`)}
                    className="bg-gray-700/80 hover:bg-gray-600 text-white font-semibold px-8 py-6 text-lg backdrop-blur-sm"
                  >
                    <Info className="w-5 h-5 mr-2" />
                    {currentT.moreInfo}
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronRight className="w-8 h-8 text-white/50 rotate-90" />
        </div>
      </div>

      {/* Category Navigation */}
      <div className="sticky top-0 z-30 bg-black/95 backdrop-blur-sm border-b border-gray-800 py-4">
        <div className="flex gap-2 overflow-x-auto px-4 sm:px-12 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full font-semibold whitespace-nowrap transition-all ${
                selectedCategory === category.id
                  ? 'bg-white text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      {/* Course Rows - Netflix Style */}
      <div className="py-12 space-y-32 overflow-visible pb-32">
        {/* Trending Now */}
        {trendingCourses.length > 0 && (
          <CourseRow
            title={currentT.trending}
            courses={trendingCourses}
            categoryId="trending"
          />
        )}

        {/* New Releases */}
        {newCourses.length > 0 && (
          <CourseRow
            title={currentT.new}
            courses={newCourses}
            categoryId="new"
          />
        )}

        {/* My List */}
        {myList.length > 0 && (
          <CourseRow
            title={currentT.myList}
            courses={courses.filter(c => myList.includes(c.id))}
            categoryId="mylist"
          />
        )}

        {/* All Courses / Filtered */}
        <CourseRow
          title={selectedCategory === 'all' 
            ? currentT.allCourses
            : categories.find(c => c.id === selectedCategory)?.name || ''
          }
          courses={filteredCourses}
          categoryId={selectedCategory}
        />
      </div>

      {/* Custom Scrollbar Styles */}
      <style jsx global>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}
