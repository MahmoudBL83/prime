'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { motion } from 'framer-motion'
import {
    Star,
    Users,
    Lock,
    Crown,
    Sparkles,
    Search,
    TrendingUp,
    Heart,
    CheckCircle,
    MessageCircle,
    Share2,
    Play,
    Bookmark,
    Home,
    BookOpen
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import Image from 'next/image'
import toast from 'react-hot-toast'

interface Creator {
    id: string
    channelId?: string // Add channel ID
    user: {
        name: string
        arabicName?: string
        profileImage: string | null
        bio: string
    }
    expertise: string
    basicMonthlyPrice: number
    premiumMonthlyPrice: number
    vipMonthlyPrice: number
    totalSubscribers: number
    stats: {
        averageRating: number
        totalPosts: number
        yearsOfExperience: number
    }
    isOnline?: boolean
    hasNewContent?: boolean
}

export default function OnlyFansStyleMentorsPage() {
    const router = useRouter()
    const params = useParams()
    const { data: session } = useSession()
    const locale = (params.locale as string) || 'en'
    const isArabic = locale === 'ar'

    const [creators, setCreators] = useState<Creator[]>([])
    const [filteredCreators, setFilteredCreators] = useState<Creator[]>([])
    const [loading, setLoading] = useState(true)
    const [searchQuery, setSearchQuery] = useState('')
    const [filterType, setFilterType] = useState<'all' | 'trending' | 'new' | 'top'>('all')
    const [activeView, setActiveView] = useState<'feed' | 'subscriptions' | 'bookmarks' | 'creators'>('feed')
    const [posts, setPosts] = useState<any[]>([])

    useEffect(() => {
        fetchCreators()
        fetchPosts()
    }, [])

    useEffect(() => {
        filterCreators()
    }, [searchQuery, filterType, creators])

    const fetchCreators = async () => {
        try {
            const response = await fetch('/api/instructors')
            if (response.ok) {
                const data = await response.json()
                // Transform data to match our Creator interface
                const transformedCreators = data.instructors.map((instructor: any) => ({
                    id: instructor.id,
                    channelId: instructor.channels?.[0]?.id, // Get first channel ID
                    user: instructor.user,
                    expertise: instructor.expertise,
                    basicMonthlyPrice: instructor.basicMonthlyPrice || 49,
                    premiumMonthlyPrice: instructor.premiumMonthlyPrice || 99,
                    vipMonthlyPrice: instructor.vipMonthlyPrice || 199,
                    totalSubscribers: instructor.totalSubscribers || Math.floor(Math.random() * 5000),
                    stats: {
                        averageRating: instructor.stats?.averageRating || 4.8,
                        totalPosts: Math.floor(Math.random() * 200) + 50,
                        yearsOfExperience: instructor.stats?.yearsOfExperience || 5
                    },
                    isOnline: Math.random() > 0.7,
                    hasNewContent: Math.random() > 0.5
                }))
                setCreators(transformedCreators)
            }
        } catch (error) {
            console.error('Failed to fetch creators:', error)
            toast.error(isArabic ? 'فشل التحميل' : 'Failed to load')
        } finally {
            setLoading(false)
        }
    }

    const fetchPosts = async () => {
        try {
            const response = await fetch('/api/channel-posts/feed')
            if (response.ok) {
                const data = await response.json()
                setPosts(data.posts || [])
            }
        } catch (error) {
            console.error('Failed to fetch posts:', error)
        }
    }

    const filterCreators = () => {
        let filtered = [...creators]

        // Search filter
        if (searchQuery) {
            filtered = filtered.filter(c =>
                c.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                c.expertise.toLowerCase().includes(searchQuery.toLowerCase())
            )
        }

        // Type filter
        switch (filterType) {
            case 'trending':
                filtered.sort((a, b) => b.totalSubscribers - a.totalSubscribers)
                break
            case 'top':
                filtered.sort((a, b) => b.stats.averageRating - a.stats.averageRating)
                break
            case 'new':
                filtered.reverse()
                break
        }

        setFilteredCreators(filtered)
    }

    const handleCreatorClick = (creatorId: string) => {
        // Route to mentor profile page (which includes their channel/posts)
        router.push(`/${locale}/mentors/${creatorId}`)
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-white dark:bg-black flex items-center justify-center">
                <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-background text-foreground transition-colors">
            {/* Top Navigation Bar - OnlyFans Style */}
            <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-xl border-b border-border transition-colors">
                <div className="container mx-auto px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div />
                        
                        <div className="flex items-center gap-4">
                            {session ? (
                                <Button
                                    onClick={() => router.push(`/${locale}/dashboard`)}
                                    className="bg-card hover:bg-card-hover text-foreground font-semibold px-6 py-2 rounded-full border border-border"
                                >
                                    {isArabic ? 'لوحة التحكم' : 'Dashboard'}
                                </Button>
                            ) : (
                                <Button
                                    onClick={() => router.push(`/${locale}/login`)}
                                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-foreground font-bold px-6 py-2 rounded-full"
                                >
                                    {isArabic ? 'تسجيل الدخول' : 'Sign In'}
                                </Button>
                            )}
                        </div>
                    </div>
                </div>
            </div>



            {/* Twitter-Style Feed */}
            <div className="container mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
                    {/* Left Sidebar - Navigation */}
                    <div className="hidden lg:block lg:col-span-3 p-4">
                        <div className="sticky top-20">
                            <nav className="space-y-2">
                                {/* Feed/Home Button */}
                                <button
                                    onClick={() => setActiveView('feed')}
                                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-full transition-all ${
                                        activeView === 'feed'
                                            ? 'bg-purple-500/20 text-foreground'
                                            : 'hover:bg-card-hover text-muted-foreground hover:text-foreground'
                                    }`}
                                >
                                    <Home className="w-6 h-6" />
                                    <span className="text-lg font-bold">{isArabic ? 'الرئيسية' : 'Feed'}</span>
                                </button>

                                {/* Courses Button */}
                                <button
                                    onClick={() => router.push(`/${locale}/courses`)}
                                    className="w-full flex items-center gap-4 px-4 py-3 rounded-full hover:bg-card-hover text-muted-foreground hover:text-foreground transition-all"
                                >
                                    <BookOpen className="w-6 h-6" />
                                    <span className="text-lg font-bold">{isArabic ? 'الدورات' : 'Courses'}</span>
                                </button>

                                {/* Creators List */}
                                <button
                                    onClick={() => setActiveView('creators')}
                                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-full transition-all ${
                                        activeView === 'creators'
                                            ? 'bg-purple-500/20 text-foreground'
                                            : 'hover:bg-card-hover text-muted-foreground hover:text-foreground'
                                    }`}
                                >
                                    <Users className="w-6 h-6" />
                                    <span className="text-lg font-bold">{isArabic ? 'المبدعون' : 'Creators'}</span>
                                </button>

                                {/* Subscriptions */}
                                <button
                                    onClick={() => {
                                        if (session) {
                                            setActiveView('subscriptions')
                                        } else {
                                            toast.error(isArabic ? 'يرجى تسجيل الدخول' : 'Please sign in')
                                        }
                                    }}
                                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-full transition-all ${
                                        activeView === 'subscriptions'
                                            ? 'bg-purple-500/20 text-foreground'
                                            : 'hover:bg-card-hover text-muted-foreground hover:text-foreground'
                                    }`}
                                >
                                    <Crown className="w-6 h-6" />
                                    <span className="text-lg font-bold">{isArabic ? 'اشتراكاتي' : 'Subscriptions'}</span>
                                </button>

                                {/* Bookmarks */}
                                <button
                                    onClick={() => {
                                        if (session) {
                                            setActiveView('bookmarks')
                                        } else {
                                            toast.error(isArabic ? 'يرجى تسجيل الدخول' : 'Please sign in')
                                        }
                                    }}
                                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-full transition-all ${
                                        activeView === 'bookmarks'
                                            ? 'bg-purple-500/20 text-foreground'
                                            : 'hover:bg-card-hover text-muted-foreground hover:text-foreground'
                                    }`}
                                >
                                    <Bookmark className="w-6 h-6" />
                                    <span className="text-lg font-bold">{isArabic ? 'المحفوظات' : 'Bookmarks'}</span>
                                </button>

                                {/* Reposts */}
                                <button
                                    onClick={() => toast.success(isArabic ? 'قريباً' : 'Coming soon!')}
                                    className="w-full flex items-center gap-4 px-4 py-3 rounded-full hover:bg-card-hover text-muted-foreground hover:text-foreground transition-all"
                                >
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                    </svg>
                                    <span className="text-lg font-bold">{isArabic ? 'إعادة النشر' : 'Reposts'}</span>
                                </button>

                                {/* Profile */}
                                <button
                                    onClick={() => {
                                        if (session) {
                                            router.push(`/${locale}/dashboard`)
                                        } else {
                                            router.push(`/${locale}/login`)
                                        }
                                    }}
                                    className="w-full flex items-center gap-4 px-4 py-3 rounded-full hover:bg-card-hover text-muted-foreground hover:text-foreground transition-all"
                                >
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                    <span className="text-lg font-bold">{isArabic ? 'الملف الشخصي' : 'Profile'}</span>
                                </button>

                                {/* Divider */}
                                <div className="border-t border-border my-4" />

                                {/* Post/Create Button */}
                                {session && (
                                    <Button
                                        onClick={() => router.push(`/${locale}/creator/apply`)}
                                        className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-foreground font-bold py-3 rounded-full text-lg shadow-lg"
                                    >
                                        {isArabic ? 'كن منشئاً' : 'Become Creator'}
                                    </Button>
                                )}
                            </nav>

                            {/* User Profile Card (if logged in) */}
                            {session && (
                                <div className="mt-6 p-4 bg-white/[0.02] border border-border rounded-2xl">
                                    <div className="flex items-center gap-3">
                                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                            <span className="text-lg font-bold text-foreground">
                                                {session.user?.name?.[0] || 'U'}
                                            </span>
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="font-bold text-foreground text-sm truncate">
                                                {session.user?.name || 'User'}
                                            </div>
                                            <div className="text-xs text-muted-foreground truncate">
                                                @{session.user?.name?.toLowerCase().replace(/\s+/g, '') || 'user'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Main Feed - Twitter Style */}
                    <div className="lg:col-span-6 border-x border-border min-h-screen">
                        {/* Header */}
                        <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-xl border-b border-border p-4 transition-colors">
                            <h2 className="text-2xl font-black text-foreground">
                                {activeView === 'feed' && (isArabic ? 'الأخبار' : 'Feed')}
                                {activeView === 'subscriptions' && (isArabic ? 'اشتراكاتي' : 'My Subscriptions')}
                                {activeView === 'bookmarks' && (isArabic ? 'المحفوظات' : 'Bookmarks')}
                                {activeView === 'creators' && (isArabic ? 'جميع المبدعين' : 'All Creators')}
                            </h2>

                            {/* Consolidation banner: promote coaching via channels */}
                            <div className="mt-3 p-3 rounded-xl bg-blue-50 dark:bg-card border border-blue-200 dark:border-border text-sm text-foreground transition-colors">
                                {isArabic
                                    ? '💡 احصل على جلسات فردية بالاشتراك في قنوات المنشئ – راجع الفئات لاكتشاف العروض التي تتضمن تدريبًا.'
                                    : '💡 Get 1-on-1 coaching by subscribing to creator channels — check tiers to find coaching-inclusive plans.'}
                            </div>
                        </div>

                        {/* Feed Posts */}
                        <div className="divide-y divide-border">
                            {activeView === 'feed' && posts.length === 0 && creators.slice(0, 20).map((creator, i) => {
                                const postTypes = ['text', 'quote', 'image', 'video']
                                const postType = postTypes[i % 4]
                                const isQuote = postType === 'quote'
                                
                                return (
                                    <motion.div
                                        key={`${creator.id}-${i}`}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: i * 0.05 }}
                                        className="p-4 hover:bg-card-hover transition-colors"
                                    >
                                        <div className="flex gap-3">
                                            {/* Profile Image */}
                                            <div className="flex-shrink-0 cursor-pointer" onClick={() => handleCreatorClick(creator.id)}>
                                                {creator.user.profileImage ? (
                                                    <Image
                                                        src={creator.user.profileImage}
                                                        alt={creator.user.name}
                                                        width={48} height={48} className="rounded-full object-cover w-12 h-12"
                                                    />
                                                ) : (
                                                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                                        <span className="text-xl font-bold text-foreground">
                                                            {creator.user.name[0]}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>

                                            {/* Post Content */}
                                            <div className="flex-1 min-w-0">
                                                {/* Header */}
                                                <div className="flex items-center gap-2 mb-1">
                                                    <span 
                                                        className="font-bold text-foreground hover:underline cursor-pointer"
                                                        onClick={() => handleCreatorClick(creator.id)}
                                                    >
                                                        {creator.user.name}
                                                    </span>
                                                    {creator.stats.averageRating >= 4.5 && (
                                                        <CheckCircle className="w-4 h-4 text-purple-500 fill-purple-500" />
                                                    )}
                                                    <span className="text-muted-foreground text-sm">
                                                        @{creator.user.name.toLowerCase().replace(/\s+/g, '')}
                                                    </span>
                                                    <span className="text-muted-foreground text-sm">·</span>
                                                    <span className="text-muted-foreground text-sm">
                                                        {Math.floor(Math.random() * 24)}h
                                                    </span>
                                                </div>

                                                {/* Post Text */}
                                                <div 
                                                    className="text-foreground mb-3 cursor-pointer hover:bg-card-hover -mx-2 px-2 py-1 rounded transition-colors"
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        toast.error(isArabic ? 'هذا منشور تجريبي. سيقوم المنشئون بنشر محتوى حقيقي قريباً!' : 'This is a demo post. Creators will publish real content soon!')
                                                    }}
                                                >
                                                    {postType === 'text' && (
                                                        <p>
                                                            Just dropped new exclusive content! 🔥 Premium subscribers get access to my latest masterclass on {creator.expertise}. 
                                                            <span className="text-purple-400"> #ExclusiveContent</span>
                                                        </p>
                                                    )}
                                                    {postType === 'quote' && (
                                                        <>
                                                            <p className="mb-3">
                                                                This is exactly what I teach in my VIP sessions! 💎
                                                            </p>
                                                            {/* Quoted Post */}
                                                            <div className="border border-border rounded-2xl p-3 hover:bg-card-hover">
                                                                <div className="flex items-center gap-2 mb-2">
                                                                    <div className="w-5 h-5 rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
                                                                    <span className="text-sm font-bold text-foreground">Education Tips</span>
                                                                    <span className="text-muted-foreground text-sm">@edutips · 2h</span>
                                                                </div>
                                                                <p className="text-sm text-muted-foreground">
                                                                    The best way to learn is by doing. Practice makes perfect! 📚✨
                                                                </p>
                                                            </div>
                                                        </>
                                                    )}
                                                    {postType === 'image' && (
                                                        <>
                                                            <p className="mb-3">
                                                                Behind the scenes of my latest course creation! 🎬 Subscribe for full access 👇
                                                            </p>
                                                            <div className="relative rounded-2xl overflow-hidden border border-border">
                                                                {creator.user.profileImage ? (
                                                                    <Image
                                                                        src={creator.user.profileImage}
                                                                        alt="Post"
                                                                        width={600}
                                                                        height={400}
                                                                        className="w-full object-cover"
                                                                    />
                                                                ) : (
                                                                    <div className="w-full h-80 bg-gradient-to-br from-purple-600/20 to-pink-600/20 flex items-center justify-center">
                                                                        <Sparkles className="w-16 h-16 text-purple-500" />
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </>
                                                    )}
                                                    {postType === 'video' && (
                                                        <>
                                                            <p className="mb-3">
                                                                🎥 New video just dropped! My VIP members are loving this one 🔥
                                                            </p>
                                                            <div className="relative rounded-2xl overflow-hidden border border-border bg-gradient-to-br from-purple-900/30 to-pink-900/30">
                                                                <div className="aspect-video flex items-center justify-center">
                                                                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-xl flex items-center justify-center">
                                                                        <div className="w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-white border-b-8 border-b-transparent ml-1" />
                                                                    </div>
                                                                </div>
                                                                <div className="absolute top-3 right-3 bg-purple-500 px-2 py-1 rounded text-xs font-bold">
                                                                    VIP
                                                                </div>
                                                            </div>
                                                        </>
                                                    )}
                                                </div>

                                                {/* Engagement Stats */}
                                                <div className="flex items-center justify-between text-muted-foreground text-sm">
                                                    <button 
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            toast.success(isArabic ? 'سيتم إضافة التعليقات قريباً' : 'Comments coming soon!')
                                                        }}
                                                        className="flex items-center gap-2 hover:text-purple-400 transition-colors group"
                                                    >
                                                        <div className="p-2 rounded-full group-hover:bg-purple-500/10">
                                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                                            </svg>
                                                        </div>
                                                        <span>{Math.floor(Math.random() * 500)}</span>
                                                    </button>

                                                    <button 
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            toast.success(isArabic ? 'تم إعادة النشر!' : 'Reposted!')
                                                        }}
                                                        className="flex items-center gap-2 hover:text-green-400 transition-colors group"
                                                    >
                                                        <div className="p-2 rounded-full group-hover:bg-green-500/10">
                                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                                            </svg>
                                                        </div>
                                                        <span>{Math.floor(Math.random() * 200)}</span>
                                                    </button>

                                                    <button 
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            const target = e.currentTarget
                                                            target.classList.toggle('text-pink-500')
                                                            const icon = target.querySelector('.heart-icon')
                                                            icon?.classList.toggle('fill-pink-500')
                                                        }}
                                                        className="flex items-center gap-2 hover:text-pink-400 transition-colors group"
                                                    >
                                                        <div className="p-2 rounded-full group-hover:bg-pink-500/10">
                                                            <Heart className="w-4 h-4 heart-icon transition-all" />
                                                        </div>
                                                        <span>{Math.floor(Math.random() * 1000) + 100}</span>
                                                    </button>

                                                    <button 
                                                        onClick={(e) => {
                                                            e.stopPropagation()
                                                            toast.success(isArabic ? 'تم النسخ!' : 'Link copied!')
                                                        }}
                                                        className="flex items-center gap-2 hover:text-purple-400 transition-colors group"
                                                    >
                                                        <div className="p-2 rounded-full group-hover:bg-purple-500/10">
                                                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                                                            </svg>
                                                        </div>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </motion.div>
                                )
                            })}

                            {/* Real Posts from Database */}
                            {activeView === 'feed' && posts.length > 0 && posts.map((post: any, i: number) => (
                                <motion.div
                                    key={post.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 0.05 }}
                                    className="p-4 hover:bg-white/[0.02] transition-colors"
                                >
                                    <div className="flex gap-3">
                                        {/* Profile Image */}
                                        <div className="flex-shrink-0 cursor-pointer" onClick={() => handleCreatorClick(post.channel.creator.id)}>
                                            {post.channel.creator.user.profileImage ? (
                                                <Image
                                                    src={post.channel.creator.user.profileImage}
                                                    alt={post.channel.creator.user.name}
                                                    width={48} height={48} className="rounded-full object-cover w-12 h-12"
                                                />
                                            ) : (
                                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                                    <span className="text-xl font-bold text-foreground">
                                                        {post.channel.creator.user.name[0]}
                                                    </span>
                                                </div>
                                            )}
                                        </div>

                                        {/* Post Content */}
                                        <div className="flex-1 min-w-0">
                                            {/* Header */}
                                            <div className="flex items-center gap-2 mb-1">
                                                <span 
                                                    className="font-bold text-foreground hover:underline cursor-pointer"
                                                    onClick={() => handleCreatorClick(post.channel.creator.id)}
                                                >
                                                    {isArabic && post.channel.creator.user.arabicName
                                                        ? post.channel.creator.user.arabicName
                                                        : post.channel.creator.user.name}
                                                </span>
                                                <CheckCircle className="w-4 h-4 text-purple-500 fill-purple-500" />
                                                <span className="text-muted-foreground text-sm">
                                                    @{post.channel.creator.user.name.toLowerCase().replace(/\s+/g, '')}
                                                </span>
                                                <span className="text-muted-foreground text-sm">·</span>
                                                <span className="text-muted-foreground text-sm">
                                                    {new Date(post.publishedAt).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
                                                        month: 'short',
                                                        day: 'numeric'
                                                    })}
                                                </span>
                                            </div>

                                            {/* Post Text */}
                                            <div 
                                                className="text-foreground mb-3 cursor-pointer hover:bg-card-hover -mx-2 px-2 py-1 rounded transition-colors"
                                                onClick={(e) => {
                                                    e.stopPropagation()
                                                    router.push(`/${locale}/posts/${post.id}`)
                                                }}
                                            >
                                                {post.title && (
                                                    <h3 className="font-bold mb-2">
                                                        {isArabic && post.titleAr ? post.titleAr : post.title}
                                                    </h3>
                                                )}
                                                <p className="whitespace-pre-wrap">
                                                    {isArabic && post.contentAr ? post.contentAr : post.content}
                                                </p>

                                                {/* Media Preview */}
                                                {post.type === 'IMAGE' && post.thumbnailUrl && (
                                                    <div className="relative rounded-2xl overflow-hidden border border-border mt-3">
                                                        <Image
                                                            src={post.thumbnailUrl}
                                                            alt="Post media"
                                                            width={600}
                                                            height={400}
                                                            className="w-full object-cover"
                                                        />
                                                    </div>
                                                )}

                                                {post.type === 'VIDEO' && post.thumbnailUrl && (
                                                    <div className="relative rounded-2xl overflow-hidden border border-border mt-3 bg-gradient-to-br from-purple-900/30 to-pink-900/30">
                                                        <div className="aspect-video relative">
                                                            <Image
                                                                src={post.thumbnailUrl}
                                                                alt="Video thumbnail"
                                                                fill
                                                                className="object-cover"
                                                            />
                                                            <div className="absolute inset-0 flex items-center justify-center">
                                                                <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-xl flex items-center justify-center">
                                                                    <Play className="w-8 h-8 text-foreground ml-1" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                            {/* Engagement Stats */}
                                            <div className="flex items-center justify-between text-muted-foreground text-sm">
                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        router.push(`/${locale}/posts/${post.id}`)
                                                    }}
                                                    className="flex items-center gap-2 hover:text-purple-400 transition-colors group"
                                                >
                                                    <div className="p-2 rounded-full group-hover:bg-purple-500/10">
                                                        <MessageCircle className="w-4 h-4" />
                                                    </div>
                                                    <span>{post._count?.comments || 0}</span>
                                                </button>

                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        toast.success(isArabic ? 'تم إعادة النشر!' : 'Reposted!')
                                                    }}
                                                    className="flex items-center gap-2 hover:text-green-400 transition-colors group"
                                                >
                                                    <div className="p-2 rounded-full group-hover:bg-green-500/10">
                                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                                        </svg>
                                                    </div>
                                                    <span>{Math.floor(Math.random() * 50)}</span>
                                                </button>

                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        const target = e.currentTarget
                                                        target.classList.toggle('text-pink-500')
                                                        const icon = target.querySelector('.heart-icon')
                                                        icon?.classList.toggle('fill-pink-500')
                                                    }}
                                                    className="flex items-center gap-2 hover:text-pink-400 transition-colors group"
                                                >
                                                    <div className="p-2 rounded-full group-hover:bg-pink-500/10">
                                                        <Heart className="w-4 h-4 heart-icon transition-all" />
                                                    </div>
                                                    <span>{post._count?.likes || 0}</span>
                                                </button>

                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        toast.success(isArabic ? 'تم النسخ!' : 'Link copied!')
                                                    }}
                                                    className="flex items-center gap-2 hover:text-purple-400 transition-colors group"
                                                >
                                                    <div className="p-2 rounded-full group-hover:bg-purple-500/10">
                                                        <Share2 className="w-4 h-4" />
                                                    </div>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>
                            ))}

                            {/* Subscriptions Management View */}
                            {activeView === 'subscriptions' && (
                                session ? (
                                    <div className="p-6">
                                        {/* Active Subscriptions Header */}
                                        <div className="mb-6">
                                            <h3 className="text-2xl font-black text-foreground mb-2">
                                                {isArabic ? 'اشتراكاتي النشطة' : 'Active Subscriptions'}
                                            </h3>
                                            <p className="text-muted-foreground">
                                                {isArabic ? 'إدارة اشتراكاتك في المنشئين' : 'Manage your creator memberships'}
                                            </p>
                                        </div>

                                        {/* Active Subscriptions List */}
                                        <div className="space-y-4 mb-8">
                                            {creators.slice(0, 3).map((creator, i) => {
                                                const tiers = ['Basic', 'Premium', 'VIP']
                                                const tier = tiers[i % 3]
                                                const prices = {
                                                    Basic: creator.basicMonthlyPrice,
                                                    Premium: creator.premiumMonthlyPrice,
                                                    VIP: creator.vipMonthlyPrice
                                                }
                                                const benefits = {
                                                    Basic: ['Access to all posts', 'Weekly updates', 'Community access'],
                                                    Premium: ['Everything in Basic', 'Monthly Q&A sessions', 'Priority support', 'Exclusive resources'],
                                                    VIP: ['Everything in Premium', '1-on-1 coaching sessions', 'Direct messaging', 'Custom content requests']
                                                }
                                                
                                                return (
                                                    <motion.div
                                                        key={`sub-${creator.id}`}
                                                        initial={{ opacity: 0, y: 20 }}
                                                        animate={{ opacity: 1, y: 0 }}
                                                        transition={{ delay: i * 0.1 }}
                                                        className="bg-white/[0.02] border border-border rounded-2xl overflow-hidden hover:border-purple-500/50 transition-all"
                                                    >
                                                        {/* Header */}
                                                        <div className="p-6 border-b border-border">
                                                            <div className="flex items-start justify-between">
                                                                <div className="flex items-center gap-4">
                                                                    {creator.user.profileImage ? (
                                                                        <Image
                                                                            src={creator.user.profileImage}
                                                                            alt={creator.user.name}
                                                                            width={64}
                                                                            height={64}
                                                                            className="rounded-full object-cover"
                                                                        />
                                                                    ) : (
                                                                        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                                                            <span className="text-2xl font-bold text-foreground">{creator.user.name[0]}</span>
                                                                        </div>
                                                                    )}
                                                                    <div>
                                                                        <div className="flex items-center gap-2 mb-1">
                                                                            <h4 className="text-xl font-bold text-foreground">{creator.user.name}</h4>
                                                                            <CheckCircle className="w-5 h-5 text-purple-500 fill-purple-500" />
                                                                            <Crown className="w-5 h-5 text-yellow-500" />
                                                                        </div>
                                                                        <p className="text-sm text-muted-foreground">{creator.expertise}</p>
                                                                        <div className="flex items-center gap-2 mt-2">
                                                                            <Badge className={`${
                                                                                tier === 'VIP' ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                                                                                tier === 'Premium' ? 'bg-gradient-to-r from-purple-500 to-pink-500' :
                                                                                'bg-gradient-to-r from-gray-500 to-gray-600'
                                                                            } text-foreground border-0`}>
                                                                                {tier} Member
                                                                            </Badge>
                                                                            <span className="text-xs text-green-400 flex items-center gap-1">
                                                                                <div className="w-2 h-2 bg-green-400 rounded-full" />
                                                                                Active
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        handleCreatorClick(creator.id)
                                                                    }}
                                                                    className="text-purple-400 hover:text-purple-300 text-sm font-semibold transition-colors"
                                                                >
                                                                    {isArabic ? 'عرض القناة' : 'View Channel'} →
                                                                </button>
                                                            </div>
                                                        </div>

                                                        {/* Subscription Details */}
                                                        <div className="p-6">
                                                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                                                                {/* Billing Info */}
                                                                <div>
                                                                    <h5 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                                                                        {isArabic ? 'الفوترة' : 'Billing'}
                                                                    </h5>
                                                                    <p className="text-2xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                                                                        {prices[tier as keyof typeof prices]} EGP
                                                                    </p>
                                                                    <p className="text-sm text-muted-foreground">
                                                                        {isArabic ? 'شهرياً' : 'per month'}
                                                                    </p>
                                                                </div>

                                                                {/* Next Billing */}
                                                                <div>
                                                                    <h5 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                                                                        {isArabic ? 'الفاتورة القادمة' : 'Next Billing'}
                                                                    </h5>
                                                                    <p className="text-lg font-bold text-foreground">
                                                                        {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
                                                                            month: 'short',
                                                                            day: 'numeric',
                                                                            year: 'numeric'
                                                                        })}
                                                                    </p>
                                                                    <p className="text-sm text-muted-foreground">
                                                                        {isArabic ? 'تجديد تلقائي' : 'Auto-renews'}
                                                                    </p>
                                                                </div>

                                                                {/* Member Since */}
                                                                <div>
                                                                    <h5 className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                                                                        {isArabic ? 'عضو منذ' : 'Member Since'}
                                                                    </h5>
                                                                    <p className="text-lg font-bold text-foreground">
                                                                        {new Date(Date.now() - (i + 1) * 90 * 24 * 60 * 60 * 1000).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', {
                                                                            month: 'short',
                                                                            year: 'numeric'
                                                                        })}
                                                                    </p>
                                                                    <p className="text-sm text-muted-foreground">
                                                                        {Math.floor((i + 1) * 3)} {isArabic ? 'أشهر' : 'months'}
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            {/* Benefits */}
                                                            <div className="mb-6">
                                                                <h5 className="text-sm font-bold text-foreground mb-3">
                                                                    {isArabic ? 'المزايا المتضمنة' : 'Your Benefits'}
                                                                </h5>
                                                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                                                    {benefits[tier as keyof typeof benefits].map((benefit, idx) => (
                                                                        <div key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                                                                            <CheckCircle className="w-4 h-4 text-purple-400 flex-shrink-0" />
                                                                            <span>{benefit}</span>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>

                                                            {/* Actions */}
                                                            <div className="flex flex-wrap items-center gap-3">
                                                                {tier !== 'VIP' && (
                                                                    <Button
                                                                        onClick={(e) => {
                                                                            e.stopPropagation()
                                                                            toast.success(isArabic ? 'جاري الترقية...' : 'Upgrading...')
                                                                        }}
                                                                        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-foreground font-bold px-6 py-2 rounded-full"
                                                                    >
                                                                        <Crown className="w-4 h-4 mr-2" />
                                                                        {isArabic ? 'الترقية' : 'Upgrade Tier'}
                                                                    </Button>
                                                                )}
                                                                <Button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        handleCreatorClick(creator.id)
                                                                    }}
                                                                    className="bg-white/10 hover:bg-white/20 text-foreground font-semibold px-6 py-2 rounded-full"
                                                                >
                                                                    {isArabic ? 'عرض القناة' : 'View Channel'}
                                                                </Button>
                                                                <Button
                                                                    onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        toast.error(isArabic ? 'هل أنت متأكد؟' : 'Are you sure?')
                                                                    }}
                                                                    className="bg-transparent hover:bg-red-500/10 text-red-400 hover:text-red-300 border border-red-500/30 font-semibold px-6 py-2 rounded-full"
                                                                >
                                                                    {isArabic ? 'إلغاء الاشتراك' : 'Cancel'}
                                                                </Button>
                                                            </div>
                                                        </div>
                                                    </motion.div>
                                                )
                                            })}
                                        </div>

                                        {/* Subscription Stats */}
                                        <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-6 mb-8">
                                            <h4 className="text-lg font-bold text-foreground mb-4">
                                                {isArabic ? 'إحصائيات الاشتراك' : 'Subscription Overview'}
                                            </h4>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                                <div className="text-center">
                                                    <div className="text-3xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-1">
                                                        3
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">
                                                        {isArabic ? 'اشتراكات نشطة' : 'Active Subs'}
                                                    </div>
                                                </div>
                                                <div className="text-center">
                                                    <div className="text-3xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-1">
                                                        347 EGP
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">
                                                        {isArabic ? 'شهرياً' : 'Monthly Cost'}
                                                    </div>
                                                </div>
                                                <div className="text-center">
                                                    <div className="text-3xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-1">
                                                        6
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">
                                                        {isArabic ? 'متوسط الأشهر' : 'Avg Months'}
                                                    </div>
                                                </div>
                                                <div className="text-center">
                                                    <div className="text-3xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-1">
                                                        156
                                                    </div>
                                                    <div className="text-xs text-muted-foreground">
                                                        {isArabic ? 'منشورات جديدة' : 'New Posts'}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Discover More Creators */}
                                        <div>
                                            <div className="flex items-center justify-between mb-4">
                                                <h4 className="text-lg font-bold text-foreground">
                                                    {isArabic ? 'اكتشف المزيد' : 'Discover More Creators'}
                                                </h4>
                                                <button
                                                    onClick={() => setActiveView('creators')}
                                                    className="text-sm text-purple-400 hover:text-purple-300 font-semibold transition-colors"
                                                >
                                                    {isArabic ? 'عرض الكل' : 'View All'} →
                                                </button>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                                {creators.slice(3, 7).map((creator, idx) => (
                                                    <motion.div
                                                        key={creator.id}
                                                        initial={{ opacity: 0, scale: 0.9 }}
                                                        animate={{ opacity: 1, scale: 1 }}
                                                        transition={{ delay: idx * 0.1 }}
                                                        onClick={() => handleCreatorClick(creator.id)}
                                                        className="bg-white/[0.02] border border-border rounded-2xl p-4 hover:border-purple-500/50 transition-all cursor-pointer group"
                                                    >
                                                        <div className="flex items-center gap-3 mb-3">
                                                            {creator.user.profileImage ? (
                                                                <Image
                                                                    src={creator.user.profileImage}
                                                                    alt={creator.user.name}
                                                                    width={48} height={48} className="rounded-full object-cover w-12 h-12"
                                                                />
                                                            ) : (
                                                                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                                                    <span className="text-lg font-bold text-foreground">{creator.user.name[0]}</span>
                                                                </div>
                                                            )}
                                                            <div className="flex-1">
                                                                <div className="flex items-center gap-1">
                                                                    <h5 className="font-bold text-foreground group-hover:text-purple-400 transition-colors">{creator.user.name}</h5>
                                                                    {creator.stats.averageRating >= 4.5 && (
                                                                        <CheckCircle className="w-4 h-4 text-purple-500 fill-purple-500" />
                                                                    )}
                                                                </div>
                                                                <p className="text-xs text-muted-foreground">{creator.expertise}</p>
                                                            </div>
                                                        </div>
                                                        <div className="flex items-center justify-between">
                                                            <span className="text-sm text-muted-foreground">
                                                                {(creator.totalSubscribers / 1000).toFixed(1)}K subscribers
                                                            </span>
                                                            <span className="text-sm font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                                                                {creator.basicMonthlyPrice} EGP/mo
                                                            </span>
                                                        </div>
                                                    </motion.div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="p-12 text-center">
                                        <Crown className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                                        <h3 className="text-xl font-bold text-foreground mb-2">
                                            {isArabic ? 'لا توجد اشتراكات' : 'No Subscriptions'}
                                        </h3>
                                        <p className="text-muted-foreground mb-6">
                                            {isArabic ? 'سجل الدخول لرؤية اشتراكاتك' : 'Sign in to see your subscriptions'}
                                        </p>
                                        <Button
                                            onClick={() => router.push(`/${locale}/login`)}
                                            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-foreground font-bold px-6 py-3 rounded-full"
                                        >
                                            {isArabic ? 'تسجيل الدخول' : 'Sign In'}
                                        </Button>
                                    </div>
                                )
                            )}

                            {/* Bookmarks View */}
                            {activeView === 'bookmarks' && (
                                <div className="p-12 text-center">
                                    <svg className="w-16 h-16 text-muted-foreground mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                    </svg>
                                    <h3 className="text-xl font-bold text-foreground mb-2">
                                        {isArabic ? 'لا توجد محفوظات' : 'No Bookmarks'}
                                    </h3>
                                    <p className="text-muted-foreground mb-6">
                                        {isArabic ? 'احفظ المنشورات المفضلة لديك لرؤيتها هنا' : 'Save your favorite posts to see them here'}
                                    </p>
                                    <Button
                                        onClick={() => setActiveView('feed')}
                                        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-foreground font-bold px-6 py-3 rounded-full"
                                    >
                                        {isArabic ? 'تصفح المنشورات' : 'Browse Posts'}
                                    </Button>
                                </div>
                            )}

                            {/* Creators Grid View */}
                            {activeView === 'creators' && (
                                <div className="p-4">
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        {creators.map((creator, idx) => (
                                            <motion.div
                                                key={creator.id}
                                                initial={{ opacity: 0, scale: 0.9 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                transition={{ delay: idx * 0.05 }}
                                                onClick={() => handleCreatorClick(creator.id)}
                                                className="bg-card border border-border rounded-2xl p-4 hover:border-purple-500/50 transition-all cursor-pointer group"
                                            >
                                                <div className="flex items-center gap-3 mb-3">
                                                    <div className="relative">
                                                        {creator.user.profileImage ? (
                                                            <Image
                                                                src={creator.user.profileImage}
                                                                alt={creator.user.name}
                                                                width={56} height={56} className="rounded-full object-cover w-14 h-14"
                                                            />
                                                        ) : (
                                                            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                                                                <span className="text-xl font-bold text-foreground">{creator.user.name[0]}</span>
                                                            </div>
                                                        )}
                                                        {creator.isOnline && (
                                                            <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-background" />
                                                        )}
                                                    </div>
                                                    <div className="flex-1">
                                                        <div className="flex items-center gap-1">
                                                            <h3 className="font-bold text-foreground group-hover:text-purple-400 transition-colors">{creator.user.name}</h3>
                                                            {creator.stats.averageRating >= 4.5 && (
                                                                <CheckCircle className="w-4 h-4 text-purple-500 fill-purple-500" />
                                                            )}
                                                        </div>
                                                        <p className="text-sm text-muted-foreground">{creator.expertise}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center justify-between text-sm">
                                                    <span className="text-muted-foreground flex items-center gap-1">
                                                        <Users className="w-4 h-4" />
                                                        {(creator.totalSubscribers / 1000).toFixed(1)}K
                                                    </span>
                                                    <span className="text-muted-foreground flex items-center gap-1">
                                                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                                                        {creator.stats.averageRating.toFixed(1)}
                                                    </span>
                                                    <span className="font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                                                        {creator.basicMonthlyPrice} EGP/mo
                                                    </span>
                                                </div>
                                            </motion.div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Right Sidebar - Who to Follow */}
                    <div className="hidden lg:block lg:col-span-3 p-4">
                        <div className="sticky top-20">
                            {/* Search */}
                            <div className="mb-4">
                                <div className="relative">
                                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                                    <Input
                                        type="text"
                                        placeholder={isArabic ? 'بحث...' : 'Search...'}
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        className="w-full bg-card border-border focus:border-purple-500 text-foreground pl-12 pr-4 py-3 rounded-full"
                                    />
                                </div>
                            </div>

                            {/* Suggested Creators */}
                            <div className="bg-card border border-border rounded-2xl overflow-hidden">
                                <div className="p-4 border-b border-border">
                                    <h3 className="font-bold text-xl text-foreground">
                                        {isArabic ? 'منشئون مقترحون' : 'Suggested Creators'}
                                    </h3>
                                </div>
                                <div className="divide-y divide-border">
                                    {creators.slice(0, 5).map((creator, idx) => (
                                        <motion.div
                                            key={creator.id}
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: idx * 0.05 }}
                                            className="p-3 hover:bg-card-hover transition-all cursor-pointer group"
                                            onClick={() => handleCreatorClick(creator.id)}
                                        >
                                            <div className="flex items-center gap-3">
                                                {/* Profile Image */}
                                                <div className="relative flex-shrink-0">
                                                    <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                                                    {creator.user.profileImage ? (
                                                        <Image
                                                            src={creator.user.profileImage}
                                                            alt={creator.user.name}
                                                            width={48} height={48} className="rounded-full object-cover w-12 h-12 relative"
                                                        />
                                                    ) : (
                                                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center relative">
                                                            <span className="text-lg font-bold text-foreground">
                                                                {creator.user.name[0]}
                                                            </span>
                                                        </div>
                                                    )}
                                                    {/* Online Indicator */}
                                                    {creator.isOnline && (
                                                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                                                    )}
                                                </div>

                                                {/* Creator Info */}
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-1 mb-0.5">
                                                        <h4 className="font-bold text-foreground text-sm truncate group-hover:text-purple-400 transition-colors">
                                                            {creator.user.name}
                                                        </h4>
                                                        {creator.stats.averageRating >= 4.5 && (
                                                            <CheckCircle className="w-3.5 h-3.5 text-purple-500 fill-purple-500 flex-shrink-0" />
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                                        <span className="flex items-center gap-1">
                                                            <Users className="w-3 h-3" />
                                                            {(creator.totalSubscribers / 1000).toFixed(1)}K
                                                        </span>
                                                        <span>·</span>
                                                        <span className="flex items-center gap-1">
                                                            <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                                                            {creator.stats.averageRating.toFixed(1)}
                                                        </span>
                                                    </div>
                                                </div>

                                                {/* Price */}
                                                <div className="flex-shrink-0 text-right">
                                                    <div className="text-sm font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                                                        {creator.basicMonthlyPrice}
                                                    </div>
                                                    <div className="text-[10px] text-muted-foreground">
                                                        {isArabic ? 'ج.م/شهر' : 'EGP/mo'}
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                                <button 
                                    className="w-full p-3 text-purple-400 hover:text-purple-300 hover:bg-white/[0.02] text-sm font-semibold transition-all text-center border-t border-border"
                                    onClick={() => setActiveView('feed')}
                                >
                                    {isArabic ? 'عرض المزيد' : 'Show more'}
                                </button>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}
