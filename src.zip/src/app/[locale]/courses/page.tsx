'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useParams } from 'next/navigation'
import { toast } from 'react-hot-toast'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, ChevronLeft, ChevronRight, BookOpen, Star, Loader2, Play, Plus, Heart, Info, Clock, Users, X } from 'lucide-react'

interface Course {
    id: string
    title: string
    titleAr: string
    description: string
    descriptionAr: string
    thumbnail?: string
    creatorId: string
    category: string
    categoryAr: string
    skillLevel: string
    duration: number
    totalViews: number
    totalEnrollments: number
    rating: number
    creator: {
        user: {
            name: string
            arabicName?: string
        }
    }
    userProgress?: number
    isEnrolled?: boolean
}

interface CategoryCourses {
    category: string
    categoryAr: string
    courses: Course[]
}

interface UserProfile {
    subscriptionStatus: 'NONE' | 'ACTIVE' | 'EXPIRED' | 'CANCELLED'
    enrollments?: Array<{
        courseId: string
        progress: number
        lastAccessed: string
    }>
}

const SKILL_LEVELS = [
    { id: 'Beginner', name: 'Beginner', nameAr: 'مبتدئ', color: 'bg-green-500' },
    { id: 'Intermediate', name: 'Intermediate', nameAr: 'متوسط', color: 'bg-yellow-500' },
    { id: 'Advanced', name: 'Advanced', nameAr: 'متقدم', color: 'bg-red-500' },
]

// Get Netflix-style image based on course ID
function getNetflixCourseImage(courseId: string): string {
    // Hash the course ID to get a consistent image for each course
    const hash = courseId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)
    const imageNumber = (hash % 6) + 1 // We have netflix1.jpg to netflix6.jpg
    return `/images/courses/netflix${imageNumber}.jpg`
}

// Netflix-style Course Card with Joker-style Modal Hover
function CourseCard({ course, lang, onClick, onHover }: {
    course: Course
    lang: string
    onClick: () => void
    onHover: (course: Course | null) => void
}) {
    const [isHovered, setIsHovered] = useState(false)
    const [isLiked, setIsLiked] = useState(false)
    const [isInList, setIsInList] = useState(false)
    const courseImage = getNetflixCourseImage(course.id)

    return (
        <motion.div
            className="relative cursor-pointer"
            onMouseEnter={() => {
                setIsHovered(true)
                onHover(course)
            }}
            onMouseLeave={() => {
                setIsHovered(false)
                onHover(null)
            }}
            animate={{
                width: isHovered ? '400px' : '280px',
                zIndex: isHovered ? 999 : 1,
            }}
            transition={{ duration: 0.3, ease: [0.32, 0.72, 0, 1] }}
        >
            {/* Main Card Container - Joker Style Border */}
            <div className={`relative rounded-lg overflow-hidden transition-all duration-300 ${
                isHovered 
                    ? 'shadow-2xl shadow-purple-500/30 ring-4 ring-purple-500/40' 
                    : 'shadow-xl'
            }`}>
                {/* Poster Image - Fixed height, width scales */}
                <div className="relative overflow-hidden bg-gray-900" style={{ height: '420px' }}>
                    <img
                        src={courseImage}
                        alt={lang === 'ar' ? course.titleAr : course.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                            console.error('Image failed to load:', courseImage)
                            e.currentTarget.src = '/images/courses/netflix1.jpg'
                        }}
                    />
                    
                    {/* Dark Gradient Overlay - Shows on Hover */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: isHovered ? 0.95 : 0 }}
                        transition={{ duration: 0.3 }}
                        className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"
                    />
                </div>

                {/* Hover Content - Joker Modal Style */}
                <AnimatePresence>
                    {isHovered && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="absolute inset-0 flex flex-col justify-between p-6 z-20"
                        >
                            {/* Top Section */}
                            <div className="flex items-start justify-between">
                                {/* Subscription Badge (Top Left) - Joker Style */}
                                <motion.div
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ delay: 0.1, duration: 0.3, type: "spring" }}
                                    className="flex items-center gap-2 bg-purple-600 text-white px-3 py-1.5 rounded-md text-xs font-bold shadow-xl"
                                >
                                    <div className="w-4 h-4 rounded-full bg-white/30 flex items-center justify-center">
                                        <Star className="w-2.5 h-2.5 fill-white text-white" />
                                    </div>
                                    {course.isEnrolled ? (lang === 'ar' ? 'مسجل بالفعل' : 'Already Enrolled') : (lang === 'ar' ? 'متاح الآن' : 'Available Now')}
                                </motion.div>

                                {/* Close Button (Top Right) */}
                                <motion.button
                                    initial={{ scale: 0, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    transition={{ delay: 0.1, duration: 0.3, type: "spring" }}
                                    className="w-9 h-9 rounded-full bg-gray-900/90 hover:bg-black flex items-center justify-center backdrop-blur-md border border-white/30 transition-all hover:border-white/60"
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        setIsHovered(false)
                                    }}
                                >
                                    <X className="w-5 h-5 text-white" strokeWidth={2.5} />
                                </motion.button>
                            </div>

                            {/* Bottom Section - Info & Actions */}
                            <div className="space-y-3">
                                {/* Course Title - Large like Joker */}
                                <motion.h2
                                    initial={{ y: 20, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.15, duration: 0.3 }}
                                    className="text-white font-black text-4xl leading-[1.1] drop-shadow-2xl uppercase tracking-tight"
                                    style={{ 
                                        textShadow: '0 4px 12px rgba(0,0,0,0.8), 0 2px 4px rgba(0,0,0,0.6)'
                                    }}
                                >
                                    {lang === 'ar' ? course.titleAr : course.title}
                                </motion.h2>

                                {/* Metadata Line - Joker Style */}
                                <motion.div
                                    initial={{ y: 10, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.2, duration: 0.3 }}
                                    className="flex items-center gap-2.5 text-sm font-medium text-gray-100"
                                >
                                    {/* Duration */}
                                    {course.duration && (
                                        <span className="font-semibold">
                                            {Math.floor(course.duration / 60)}:{String(course.duration % 60).padStart(2, '0')}:00
                                        </span>
                                    )}
                                    
                                    {/* Separator */}
                                    {course.duration && <span className="text-green-400 text-lg">•</span>}
                                    
                                    {/* Category */}
                                    <span className="font-semibold">{lang === 'ar' ? course.categoryAr : course.category}</span>
                                    
                                    {/* Separator */}
                                    <span className="text-green-400 text-lg">•</span>
                                    
                                    {/* Skill Level */}
                                    {SKILL_LEVELS.find(level => level.id === course.skillLevel) && (
                                        <span className="font-semibold capitalize">
                                            {lang === 'ar'
                                                ? SKILL_LEVELS.find(level => level.id === course.skillLevel)?.nameAr
                                                : SKILL_LEVELS.find(level => level.id === course.skillLevel)?.name
                                            }
                                        </span>
                                    )}
                                </motion.div>

                                {/* Progress Bar if Enrolled */}
                                {course.isEnrolled && course.userProgress !== undefined && course.userProgress > 0 && (
                                    <motion.div
                                        initial={{ scaleX: 0, opacity: 0 }}
                                        animate={{ scaleX: 1, opacity: 1 }}
                                        transition={{ delay: 0.25, duration: 0.4 }}
                                        className="origin-left"
                                    >
                                        <div className="flex justify-between text-xs mb-1.5 text-gray-200 font-medium">
                                            <span>{course.userProgress}% {lang === 'ar' ? 'مكتمل' : 'Complete'}</span>
                                        </div>
                                        <div className="w-full bg-gray-700/60 rounded-full h-1.5 overflow-hidden">
                                            <motion.div
                                                initial={{ width: 0 }}
                                                animate={{ width: `${course.userProgress}%` }}
                                                transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
                                                className="bg-gradient-to-r from-cyan-400 to-blue-500 h-1.5 rounded-full shadow-lg shadow-cyan-500/50"
                                            />
                                        </div>
                                    </motion.div>
                                )}

                                {/* Action Buttons - Joker Style */}
                                <motion.div
                                    initial={{ y: 20, opacity: 0 }}
                                    animate={{ y: 0, opacity: 1 }}
                                    transition={{ delay: 0.3, duration: 0.3 }}
                                    className="flex items-center gap-3 pt-1"
                                >
                                    {/* Primary Play Button - Large & Cyan like Joker */}
                                    <button
                                        className="flex items-center justify-center gap-2.5 bg-cyan-500 hover:bg-cyan-400 active:bg-cyan-600 text-white px-7 py-3.5 rounded-full font-bold text-base transition-all shadow-xl hover:shadow-cyan-500/60 hover:scale-105"
                                        onClick={(e) => {
                                            e.stopPropagation()
                                            onClick()
                                        }}
                                    >
                                        <Play className="w-5 h-5" fill="currentColor" />
                                        <span className="whitespace-nowrap">
                                            {course.isEnrolled ? (lang === 'ar' ? 'استمرار' : 'Continue') : (lang === 'ar' ? 'ابدأ' : 'Start')}
                                        </span>
                                    </button>

                                    {/* Add to List Button */}
                                    <button
                                        className={`w-12 h-12 rounded-full backdrop-blur-md border-2 flex items-center justify-center transition-all hover:scale-110 shadow-lg ${
                                            isInList 
                                                ? 'bg-cyan-500/80 hover:bg-cyan-500 border-cyan-400/80 hover:border-cyan-400' 
                                                : 'bg-gray-900/80 hover:bg-gray-900 border-white/50 hover:border-white/80'
                                        }`}
                                        onClick={(e) => {
                                            e.stopPropagation()
                                            setIsInList(!isInList)
                                        }}
                                        title={lang === 'ar' ? 'قائمتي' : 'My list'}
                                    >
                                        {isInList ? (
                                            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                            </svg>
                                        ) : (
                                            <Plus className="w-5 h-5 text-white" strokeWidth={2.5} />
                                        )}
                                    </button>

                                    {/* Like Button */}
                                    <button
                                        className={`w-12 h-12 rounded-full backdrop-blur-md border-2 flex items-center justify-center transition-all hover:scale-110 shadow-lg ${
                                            isLiked 
                                                ? 'bg-red-500/80 hover:bg-red-500 border-red-400/80 hover:border-red-400' 
                                                : 'bg-gray-900/80 hover:bg-gray-900 border-white/50 hover:border-white/80'
                                        }`}
                                        onClick={(e) => {
                                            e.stopPropagation()
                                            setIsLiked(!isLiked)
                                        }}
                                        title={lang === 'ar' ? 'أعجبني' : 'Like'}
                                    >
                                        <Heart 
                                            className="w-5 h-5 text-white" 
                                            strokeWidth={2.5}
                                            fill={isLiked ? 'currentColor' : 'none'}
                                        />
                                    </button>

                                    {/* Mute/Sound Button (like Joker image) */}
                                    <button
                                        className="w-12 h-12 rounded-full bg-gray-900/80 hover:bg-gray-900 backdrop-blur-md border-2 border-white/50 hover:border-white/80 flex items-center justify-center transition-all hover:scale-110 shadow-lg ml-auto"
                                        onClick={(e) => e.stopPropagation()}
                                        title="Sound"
                                    >
                                        <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                                        </svg>
                                    </button>
                                </motion.div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.div>
    )
}

// Category Row Component with Horizontal Scroll
function CategoryRow({ category, categoryAr, courses, lang, onCourseClick, onCourseHover }: {
    category: string
    categoryAr: string
    courses: Course[]
    lang: string
    onCourseClick: (courseId: string) => void
    onCourseHover: (course: Course | null) => void
}) {
    const scrollRef = useRef<HTMLDivElement>(null)
    const [canScrollLeft, setCanScrollLeft] = useState(false)
    const [canScrollRight, setCanScrollRight] = useState(true)
    const [hoveredCardId, setHoveredCardId] = useState<string | null>(null)

    const checkScroll = () => {
        if (scrollRef.current) {
            const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current
            setCanScrollLeft(scrollLeft > 0)
            setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10)
        }
    }

    useEffect(() => {
        checkScroll()
        const scrollEl = scrollRef.current
        if (scrollEl) {
            scrollEl.addEventListener('scroll', checkScroll)
            return () => scrollEl.removeEventListener('scroll', checkScroll)
        }
    }, [courses])

    const scroll = (direction: 'left' | 'right') => {
        if (scrollRef.current) {
            const scrollAmount = 1000
            scrollRef.current.scrollBy({
                left: direction === 'left' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            })
        }
    }

    if (courses.length === 0) return null

    return (
        <div className="relative group/row mb-16">
            {/* Category Title - Enhanced UI/UX */}
            <div className="px-6 mb-6 flex items-center justify-between group">
                <div className="flex items-center gap-4">
                    {/* Gradient Accent Line */}
                    <motion.div
                        className="h-8 w-1 bg-gradient-to-b from-purple-500 to-pink-600 rounded-full"
                        initial={{ height: 0 }}
                        whileInView={{ height: 32 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5 }}
                    />
                    
                    {/* Category Title */}
                    <div>
                        <h2 className="text-3xl font-black text-white tracking-tight group-hover:text-purple-400 transition-colors">
                            {lang === 'ar' ? categoryAr : category}
                        </h2>
                        <div className="h-0.5 w-0 group-hover:w-full bg-gradient-to-r from-purple-500 to-transparent transition-all duration-500 mt-1" />
                    </div>
                </div>

                {/* Course Count Badge */}
                <div className="flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full">
                    <BookOpen className="w-4 h-4 text-purple-400" />
                    <span className="text-sm font-semibold text-gray-400">
                        {courses.length} {lang === 'ar' ? 'دورة' : 'courses'}
                    </span>
                </div>
            </div>

            {/* Scroll Container */}
            <div className="relative">
                {/* Left Arrow */}
                {canScrollLeft && (
                    <button
                        onClick={() => scroll('left')}
                        className="absolute left-0 top-0 bottom-0 z-40 bg-black/80 hover:bg-black/95 text-white p-2 opacity-0 group-hover/row:opacity-100 transition-opacity duration-300"
                        style={{ width: '40px' }}
                    >
                        <ChevronLeft className="w-6 h-6" />
                    </button>
                )}

                {/* Courses Scroll - Netflix Style with Gap Animation */}
                <div
                    ref={scrollRef}
                    className="flex overflow-x-auto scrollbar-hide px-6 py-2"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                    {courses.map((course, index) => (
                        <div
                            key={course.id}
                            className="flex-shrink-0 transition-all duration-300 ease-out"
                            style={{
                                marginRight: '16px',
                            }}
                            onMouseEnter={() => setHoveredCardId(course.id)}
                            onMouseLeave={() => setHoveredCardId(null)}
                        >
                            <CourseCard
                                course={course}
                                lang={lang}
                                onClick={() => onCourseClick(course.id)}
                                onHover={onCourseHover}
                            />
                        </div>
                    ))}
                </div>

                {/* Right Arrow */}
                {canScrollRight && (
                    <button
                        onClick={() => scroll('right')}
                        className="absolute right-0 top-0 bottom-0 z-40 bg-black/80 hover:bg-black/95 text-white p-2 opacity-0 group-hover/row:opacity-100 transition-opacity duration-300"
                        style={{ width: '40px' }}
                    >
                        <ChevronRight className="w-6 h-6" />
                    </button>
                )}
            </div>
        </div>
    )
}

export default function CoursesPage() {
    const { data: session } = useSession()
    const router = useRouter()
    const params = useParams()
    const [categorizedCourses, setCategorizedCourses] = useState<CategoryCourses[]>([])
    const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
    const [loading, setLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState('')
    const [hoveredCourse, setHoveredCourse] = useState<Course | null>(null)
    const [loadingCourseId, setLoadingCourseId] = useState<string | null>(null)
    const [activeSlide, setActiveSlide] = useState(0)

    const locale = params?.locale as string || 'en'
    const lang = locale === 'ar' ? 'ar' : 'en'

    useEffect(() => {
        if (session) {
            fetchUserProfile()
        }
        fetchCourses()
    }, [session])

    // Auto-play slider effect
    useEffect(() => {
        if (categorizedCourses.length === 0) return
        
        const popularCourses = categorizedCourses[0]?.courses || []
        const maxSlides = Math.min(popularCourses.length, 8)
        
        if (maxSlides <= 1) return

        const interval = setInterval(() => {
            setActiveSlide((prev) => (prev + 1) % maxSlides)
        }, 4000) // Change slide every 4 seconds

        return () => clearInterval(interval)
    }, [categorizedCourses])

    const fetchUserProfile = async () => {
        try {
            const response = await fetch('/api/user/profile')
            if (response.ok) {
                const profile = await response.json()
                setUserProfile(profile)
            }
        } catch (error) {
            console.error('Failed to fetch user profile:', error)
        }
    }

    const fetchCourses = async () => {
        setLoading(true)
        try {
            const response = await fetch(`/api/courses?page=1&limit=500&sort=popular`)
            if (response.ok) {
                const data = await response.json()

                // Enhance courses with user enrollment data
                const enhancedCourses = data.courses.map((course: Course) => {
                    const enrollment = userProfile?.enrollments?.find(e => e.courseId === course.id)
                    return {
                        ...course,
                        userProgress: enrollment?.progress || 0,
                        isEnrolled: !!enrollment,
                        lastAccessed: enrollment?.lastAccessed
                    }
                })

                // Group courses by category
                const grouped: { [key: string]: CategoryCourses } = {}
                enhancedCourses.forEach((course: Course) => {
                    const key = course.category
                    if (!grouped[key]) {
                        grouped[key] = {
                            category: course.category,
                            categoryAr: course.categoryAr || course.category,
                            courses: []
                        }
                    }
                    grouped[key].courses.push(course)
                })

                // Convert to array
                const categorized = Object.values(grouped)

                // Add "Trending Now" category - show all trending courses
                const trending = {
                    category: 'Trending Now',
                    categoryAr: 'الأكثر رواجًا',
                    courses: [...enhancedCourses].sort((a: Course, b: Course) =>
                        b.totalViews - a.totalViews
                    )
                }
                if (trending.courses.length > 0) {
                    categorized.unshift(trending)
                }

                setCategorizedCourses(categorized)
            } else {
                toast.error('Failed to fetch courses')
            }
        } catch (error) {
            toast.error('Failed to fetch courses')
        } finally {
            setLoading(false)
        }
    }

    const handleCourseClick = (courseId: string) => {
        if (loadingCourseId) return
        setLoadingCourseId(courseId)
        setTimeout(() => {
            router.push(`/${locale}/courses/${courseId}`)
        }, 150)
    }

    const t = {
        en: {
            title: 'Courses',
            subtitle: 'Unlimited learning, endless possibilities',
            search: 'Search courses...',
        },
        ar: {
            title: 'الدورات',
            subtitle: 'تعلم غير محدود، إمكانيات لا نهائية',
            search: 'ابحث في الدورات...',
        },
    }

    const currentT = t[lang]

    // Get the featured course (currently active in slider)
    const featuredCourse = categorizedCourses.length > 0 && categorizedCourses[0]?.courses[activeSlide]

    return (
        <div className="min-h-screen bg-black">
            {/* Hero Section - Dynamic with Course Background */}
            <div className="relative h-[85vh] overflow-hidden">
                {/* Dynamic Background Image from Selected Course */}
                <AnimatePresence mode="wait">
                    {featuredCourse && (
                        <motion.div
                            key={featuredCourse.id}
                            initial={{ opacity: 0, scale: 1.1 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                            className="absolute inset-0"
                        >
                            <img
                                src={getNetflixCourseImage(featuredCourse.id)}
                                alt={lang === 'ar' ? featuredCourse.titleAr : featuredCourse.title}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                    console.error('Hero image failed to load')
                                    e.currentTarget.src = '/images/courses/netflix1.jpg'
                                }}
                            />
                            {/* Netflix-style Gradient Overlays */}
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/40" />
                            <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent" />
                            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black" />
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Hero Content - Featured Course Info */}
                <div className="relative h-full flex flex-col justify-center pb-48 px-6 lg:px-16 max-w-7xl mx-auto z-10">
                    <AnimatePresence mode="wait">
                        {featuredCourse && (
                            <motion.div
                                key={featuredCourse.id}
                                initial={{ opacity: 0, y: 40 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -20 }}
                                transition={{ duration: 0.6 }}
                                className="max-w-3xl"
                            >
                                {/* Course Title */}
                                <motion.h1
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.3 }}
                                    className="text-4xl lg:text-6xl font-black text-white mb-4 leading-tight"
                                    style={{ textShadow: '0 4px 20px rgba(0,0,0,0.8)' }}
                                >
                                    {lang === 'ar' ? featuredCourse.titleAr : featuredCourse.title}
                                </motion.h1>

                                {/* Course Description */}
                                <motion.p
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.4 }}
                                    className="text-base lg:text-lg text-gray-200 mb-6 leading-relaxed line-clamp-2 max-w-2xl"
                                    style={{ textShadow: '0 2px 10px rgba(0,0,0,0.8)' }}
                                >
                                    {lang === 'ar' ? featuredCourse.descriptionAr : featuredCourse.description}
                                </motion.p>

                                {/* Course Metadata */}
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.5 }}
                                    className="flex items-center gap-4 text-gray-300 text-sm mb-6"
                                >
                                    {featuredCourse.duration && (
                                        <div className="flex items-center gap-2">
                                            <Clock className="w-4 h-4" />
                                            <span>{Math.floor(featuredCourse.duration / 60)}h {featuredCourse.duration % 60}m</span>
                                        </div>
                                    )}
                                    {featuredCourse.skillLevel && (
                                        <>
                                            <span>•</span>
                                            <span className="capitalize">
                                                {lang === 'ar'
                                                    ? SKILL_LEVELS.find(level => level.id === featuredCourse.skillLevel)?.nameAr
                                                    : SKILL_LEVELS.find(level => level.id === featuredCourse.skillLevel)?.name
                                                }
                                            </span>
                                        </>
                                    )}
                                    {featuredCourse.totalEnrollments && (
                                        <>
                                            <span>•</span>
                                            <div className="flex items-center gap-2">
                                                <Users className="w-4 h-4" />
                                                <span>{featuredCourse.totalEnrollments.toLocaleString()} {lang === 'ar' ? 'طالب' : 'students'}</span>
                                            </div>
                                        </>
                                    )}
                                </motion.div>

                                {/* Action Buttons */}
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.6 }}
                                    className="flex items-center gap-4"
                                >
                                    <button
                                        onClick={() => handleCourseClick(featuredCourse.id)}
                                        className="flex items-center gap-3 px-8 py-4 bg-white hover:bg-gray-200 text-black font-bold rounded-lg transition-all hover:scale-105 shadow-xl"
                                    >
                                        <Play className="w-5 h-5" fill="currentColor" />
                                        <span>{featuredCourse.isEnrolled ? (lang === 'ar' ? 'استمرار' : 'Continue') : (lang === 'ar' ? 'ابدأ الآن' : 'Start Now')}</span>
                                    </button>
                                    <button
                                        onClick={() => handleCourseClick(featuredCourse.id)}
                                        className="flex items-center gap-3 px-8 py-4 bg-gray-800/60 hover:bg-gray-700/60 backdrop-blur-sm text-white font-bold rounded-lg transition-all border border-white/20 hover:border-white/40"
                                    >
                                        <Info className="w-5 h-5" />
                                        <span>{lang === 'ar' ? 'المزيد' : 'More Info'}</span>
                                    </button>
                                </motion.div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* Popular Courses Slider Pagination - Bottom of Hero */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1, duration: 0.8 }}
                    className="absolute bottom-4 left-0 right-0 z-20 px-6 lg:px-16 overflow-visible"
                >
                    <div className="max-w-7xl mx-auto overflow-visible">
                        {/* Section Title */}
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-white text-base font-bold tracking-wider uppercase">
                                {lang === 'ar' ? 'الدورات الأكثر شعبية' : 'Popular Courses'}
                            </h3>
                            {/* Interactive Pagination Dots */}
                            <div className="flex items-center gap-2.5">
                                {categorizedCourses.length > 0 && categorizedCourses[0]?.courses.slice(0, 8).map((_, index) => (
                                    <motion.button
                                        key={index}
                                        onClick={() => setActiveSlide(index)}
                                        className={`h-1 rounded-full transition-all cursor-pointer ${
                                            index === activeSlide ? 'w-10 bg-white' : 'w-7 bg-white/30 hover:bg-white/50'
                                        }`}
                                        whileHover={{ scale: 1.2 }}
                                        whileTap={{ scale: 0.9 }}
                                    />
                                ))}
                            </div>
                        </div>
                        
                        {/* Slider with Course Posters */}
                        <div className="flex gap-5 overflow-x-auto scrollbar-hide pb-4 overflow-visible">
                            {categorizedCourses.length > 0 && categorizedCourses[0]?.courses.slice(0, 8).map((course, index) => (
                                <motion.button
                                    key={course.id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ 
                                        opacity: 1, 
                                        y: 0,
                                        scale: index === activeSlide ? 1.1 : 1,
                                        boxShadow: index === activeSlide 
                                            ? '0 0 30px rgba(168, 85, 247, 0.6)' 
                                            : '0 0 0px rgba(0, 0, 0, 0)'
                                    }}
                                    transition={{ 
                                        delay: 1 + index * 0.1,
                                        scale: { duration: 0.3 },
                                        boxShadow: { duration: 0.3 }
                                    }}
                                    whileHover={{ scale: 1.15, y: -6 }}
                                    onClick={() => setActiveSlide(index)}
                                    onMouseEnter={() => setActiveSlide(index)}
                                    className={`relative flex-shrink-0 w-28 h-40 rounded-xl overflow-hidden transition-all shadow-2xl group ${
                                        index === activeSlide 
                                            ? 'border-2 border-purple-500 ring-2 ring-purple-500/50' 
                                            : 'border-2 border-white/20 hover:border-purple-400'
                                    }`}
                                >
                                    {/* Course Poster Image */}
                                    <img
                                        src={getNetflixCourseImage(course.id)}
                                        alt={lang === 'ar' ? course.titleAr : course.title}
                                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                        onError={(e) => {
                                            console.error('Slider image failed to load')
                                            e.currentTarget.src = '/images/courses/netflix1.jpg'
                                        }}
                                    />
                                    
                                    {/* Gradient Overlay */}
                                    <div className={`absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent transition-opacity ${
                                        index === activeSlide ? 'opacity-50' : 'opacity-0 group-hover:opacity-100'
                                    }`} />
                                    
                                    {/* Active Indicator */}
                                    {index === activeSlide && (
                                        <motion.div
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            className="absolute top-2 left-2 w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center"
                                        >
                                            <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                                        </motion.div>
                                    )}
                                    
                                    {/* Course Title on Hover or Active */}
                                    <div className={`absolute bottom-0 left-0 right-0 p-2 transition-transform ${
                                        index === activeSlide ? 'translate-y-0' : 'translate-y-full group-hover:translate-y-0'
                                    }`}>
                                        <p className="text-white text-xs font-semibold line-clamp-2 text-center">
                                            {lang === 'ar' ? course.titleAr : course.title}
                                        </p>
                                    </div>
                                    
                                    {/* Play Icon Overlay */}
                                    <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${
                                        index === activeSlide ? 'opacity-70' : 'opacity-0 group-hover:opacity-100'
                                    }`}>
                                        <div className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center">
                                            <Play className="w-5 h-5 text-black ml-0.5" fill="currentColor" />
                                        </div>
                                    </div>
                                </motion.button>
                            ))}
                        </div>
                    </div>
                </motion.div>
            </div>

            {/* Categories Section */}
            <div className="relative pt-20 z-10 pb-20" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                {loading ? (
                    <div className="flex items-center justify-center py-20">
                        <Loader2 className="w-12 h-12 animate-spin text-white" />
                    </div>
                ) : categorizedCourses.length === 0 ? (
                    <div className="text-center py-20">
                        <p className="text-xl text-gray-400">
                            {lang === 'ar' ? 'لا توجد دورات متاحة' : 'No courses available'}
                        </p>
                    </div>
                ) : (
                    <>
                        {categorizedCourses.map((category, index) => (
                            <CategoryRow
                                key={category.category}
                                category={category.category}
                                categoryAr={category.categoryAr}
                                courses={category.courses}
                                lang={lang}
                                onCourseClick={handleCourseClick}
                                onCourseHover={setHoveredCourse}
                            />
                        ))}
                    </>
                )}
            </div>

            {/* Loading Overlay */}
            {loadingCourseId && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
                    <div className="flex flex-col items-center gap-4">
                        <Loader2 className="w-16 h-16 animate-spin text-white" />
                        <p className="text-white text-lg">
                            {lang === 'ar' ? 'جاري التحميل...' : 'Loading...'}
                        </p>
                    </div>
                </div>
            )}

            {/* Custom Scrollbar Styles */}
            <style jsx global>{`
                .scrollbar-hide {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
                .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                }
                .line-clamp-2 {
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }
            `}</style>
        </div>
    )
}
