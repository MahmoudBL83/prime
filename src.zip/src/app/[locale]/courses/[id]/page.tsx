'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import {
    Play,
    Pause,
    Plus,
    ThumbsUp,
    ThumbsDown,
    Volume2,
    VolumeX,
    Maximize,
    ChevronDown,
    ChevronUp,
    Star,
    Clock,
    Calendar,
    Film,
    Tv,
    Mic,
    CheckCircle,
    Info,
    Share2,
    Download,
    MoreVertical,
    ArrowLeft,
    SkipForward,
    SkipBack,
    Check,
    Users,
    Award,
    Lock,
    Bookmark,
    Eye,
    X,
    Shield,
    BookOpen,
    ArrowRight,
    Sparkles
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useTranslationsSafe, useLocaleSafe } from '@/hooks/useTranslationsSafe'
import Image from 'next/image'

interface Lesson {
    id: string
    title: string
    titleAr?: string
    titleDe?: string
    description?: string
    descriptionAr?: string
    descriptionDe?: string
    order: number
    duration: number
    videoUrl?: string
    seasonNumber?: number
    episodeNumber?: number
}

interface Course {
    id: string
    title: string
    titleAr?: string
    titleDe?: string
    description: string
    descriptionAr?: string
    descriptionDe?: string
    thumbnail?: string
    contentType?: 'MOVIE' | 'SERIES' | 'PODCAST'
    runtime?: number // minutes for movies
    totalSeasons?: number
    totalEpisodes?: number
    episodeDuration?: number // average episode length
    frequency?: string // for podcasts
    hostName?: string
    releaseYear?: number
    maturityRating?: string
    genres?: string
    cast?: string
    trailer?: string
    rating?: number
    totalEnrollments?: number
    creator?: {
        user: {
            id: string
            name: string
            arabicName?: string
            profileImage?: string
        }
    }
    lessons?: Lesson[]
}

export default function NetflixCoursePage() {
    const { data: session } = useSession()
    const params = useParams()
    const router = useRouter()
    const locale = useLocaleSafe()
    const { t } = useTranslationsSafe('coursePage')
    
    const [course, setCourse] = useState<Course | null>(null)
    const [loading, setLoading] = useState(true)
    const [isPlaying, setIsPlaying] = useState(false)
    const [isMuted, setIsMuted] = useState(true)
    const [showMoreInfo, setShowMoreInfo] = useState(false)
    const [selectedSeason, setSelectedSeason] = useState(1)
    const [isInMyList, setIsInMyList] = useState(false)
    const [netflixLiked, setNetflixLiked] = useState<boolean | null>(null)
    const [hasSubscription, setHasSubscription] = useState(false)
    const [subscriptionLoading, setSubscriptionLoading] = useState(true)
    const [showSubscribeModal, setShowSubscribeModal] = useState(false)
    const [showNotification, setShowNotification] = useState(false)
    const [notificationMessage, setNotificationMessage] = useState('')
    const [showSidebar, setShowSidebar] = useState(false)
    const videoRef = useRef<HTMLVideoElement>(null)
    const courseContentRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
        const fetchCourse = async () => {
            try {
                const response = await fetch(`/api/courses/${params.id}`)
                if (response.ok) {
                    const data = await response.json()
                    setCourse(data)
                }
            } catch (error) {
                console.error('Error fetching course:', error)
            } finally {
                setLoading(false)
            }
        }

        if (params.id) {
            fetchCourse()
        }
    }, [params.id])

    // Fetch subscription status
    useEffect(() => {
        const fetchSubscription = async () => {
            if (!session) {
                setSubscriptionLoading(false)
                return
            }
            
            try {
                const response = await fetch('/api/user/subscription/check')
                const data = await response.json()
                setHasSubscription(data.hasAccess)
            } catch (error) {
                console.error('Error fetching subscription:', error)
            } finally {
                setSubscriptionLoading(false)
            }
        }

        fetchSubscription()
    }, [session])

    // Fetch user's interaction
    useEffect(() => {
        const fetchInteraction = async () => {
            if (!session || !params.id) return
            
            try {
                const response = await fetch(`/api/courses/${params.id}/interaction`)
                const data = await response.json()
                setNetflixLiked(data.liked)
                setIsInMyList(data.inMyList)
            } catch (error) {
                console.error('Error fetching interaction:', error)
            }
        }

        fetchInteraction()
    }, [session, params.id])

    // Auto-play video after 2 seconds
    useEffect(() => {
        const timer = setTimeout(() => {
            if (videoRef.current && !isPlaying) {
                videoRef.current.play()
                setIsPlaying(true)
            }
        }, 2000)

        return () => clearTimeout(timer)
    }, [course])

    const togglePlay = () => {
        if (videoRef.current) {
            if (isPlaying) {
                videoRef.current.pause()
            } else {
                videoRef.current.play()
            }
            setIsPlaying(!isPlaying)
        }
    }

    const toggleMute = () => {
        if (videoRef.current) {
            videoRef.current.muted = !isMuted
            setIsMuted(!isMuted)
        }
    }

    // Show notification
    const showToast = (message: string) => {
        setNotificationMessage(message)
        setShowNotification(true)
        setTimeout(() => setShowNotification(false), 3000)
    }

    // Handle like button
    const handleLike = async () => {
        if (!session) {
            router.push(`/${locale}/auth/signin`)
            return
        }

        const newState = netflixLiked === true ? null : true
        setNetflixLiked(newState)

        try {
            await fetch(`/api/courses/${params.id}/interaction`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: newState === null ? 'clearRating' : 'like' })
            })
            
            if (newState === true) {
                showToast('Added to your Liked Courses ❤️')
            } else {
                showToast('Removed from Liked Courses')
            }
        } catch (error) {
            console.error('Error updating like:', error)
            setNetflixLiked(netflixLiked) // Revert on error
            showToast('Failed to update. Please try again.')
        }
    }

    // Handle dislike button
    const handleDislike = async () => {
        if (!session) {
            router.push(`/${locale}/auth/signin`)
            return
        }

        const newState = netflixLiked === false ? null : false
        setNetflixLiked(newState)

        try {
            await fetch(`/api/courses/${params.id}/interaction`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: newState === null ? 'clearRating' : 'dislike' })
            })
            
            if (newState === false) {
                showToast('Thanks for your feedback')
            } else {
                showToast('Rating cleared')
            }
        } catch (error) {
            console.error('Error updating dislike:', error)
            setNetflixLiked(netflixLiked) // Revert on error
            showToast('Failed to update. Please try again.')
        }
    }

    // Handle My List button
    const handleMyList = async () => {
        if (!session) {
            router.push(`/${locale}/auth/signin`)
            return
        }

        const newState = !isInMyList
        setIsInMyList(newState)

        try {
            await fetch(`/api/courses/${params.id}/interaction`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: newState ? 'addToList' : 'removeFromList' })
            })
            
            if (newState) {
                showToast('Added to My List ✓')
            } else {
                showToast('Removed from My List')
            }
        } catch (error) {
            console.error('Error updating My List:', error)
            setIsInMyList(!newState) // Revert on error
            showToast('Failed to update. Please try again.')
        }
    }

    // Handle play button
    const handlePlay = () => {
        if (!hasSubscription && !subscriptionLoading) {
            setShowSubscribeModal(true)
        } else {
            router.push(`/${locale}/learn/${params.id}`)
        }
    }

    // Toggle sidebar
    const toggleSidebar = () => {
        setShowSidebar(!showSidebar)
    }

    const getLocalizedText = (text: string, textAr?: string, textDe?: string) => {
        if (locale === 'ar' && textAr) return textAr
        if (locale === 'de' && textDe) return textDe
        return text
    }

    // Group lessons by season for series
    const getEpisodesBySeason = (seasonNum: number) => {
        if (!course?.lessons) return []
        return course.lessons
            .filter(lesson => lesson.seasonNumber === seasonNum)
            .sort((a, b) => (a.episodeNumber || 0) - (b.episodeNumber || 0))
    }

    const getSeasons = () => {
        if (!course?.lessons) return []
        const seasons = new Set(course.lessons.map(l => l.seasonNumber).filter(Boolean))
        return Array.from(seasons).sort((a, b) => (a || 0) - (b || 0))
    }

    const getContentTypeIcon = () => {
        switch (course?.contentType) {
            case 'MOVIE': return <Film className="w-5 h-5" />
            case 'SERIES': return <Tv className="w-5 h-5" />
            case 'PODCAST': return <Mic className="w-5 h-5" />
            default: return <Film className="w-5 h-5" />
        }
    }

    const getContentTypeLabel = () => {
        const type = course?.contentType || 'SERIES'
        const labels: Record<string, string> = {
            'MOVIE': 'Course',
            'SERIES': 'Course',
            'PODCAST': 'Podcast'
        }
        return labels[type] || 'Course'
    }

    const getMetadataLabel = () => {
        if (!course) return ''
        
        switch (course.contentType) {
            case 'MOVIE':
                return course.runtime ? `${course.runtime} min` : ''
            case 'SERIES':
                return course.totalSeasons 
                    ? `${course.totalSeasons} Modules • ${course.totalEpisodes || 0} Lessons`
                    : ''
            case 'PODCAST':
                return course.frequency || 'Podcast'
            default:
                return course.lessons?.length ? `${course.lessons.length} Lessons` : ''
        }
    }

    if (loading) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <div className="text-white text-2xl">Loading...</div>
            </div>
        )
    }

    if (!course) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center">
                <div className="text-white text-2xl">Course not found</div>
            </div>
        )
    }

    const contentType = course.contentType || 'SERIES'

    return (
        <div className="min-h-screen bg-black text-white">
            {/* Toast Notification */}
            <AnimatePresence>
                {showNotification && (
                    <motion.div
                        initial={{ opacity: 0, y: -50 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -50 }}
                        className="fixed top-8 left-1/2 -translate-x-1/2 z-[200] bg-white text-black px-6 py-3 rounded-full shadow-2xl flex items-center gap-3"
                    >
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <span className="font-semibold">{notificationMessage}</span>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Course Content Sidebar */}
            <AnimatePresence>
                {showSidebar && (
                    <>
                        {/* Backdrop */}
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[150]"
                            onClick={toggleSidebar}
                        />
                        
                        {/* Sidebar */}
                        <motion.div
                            initial={{ x: '100%' }}
                            animate={{ x: 0 }}
                            exit={{ x: '100%' }}
                            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
                            className="fixed right-0 top-0 bottom-0 w-full md:w-[600px] lg:w-[700px] bg-gradient-to-br from-gray-900 via-gray-900 to-black z-[160] overflow-y-auto border-l border-gray-700/50 shadow-2xl"
                        >
                            {/* Sidebar Header */}
                            <div className="sticky top-0 z-10 bg-gradient-to-r from-gray-900 to-black border-b border-gray-700/50 backdrop-blur-xl">
                                <div className="flex items-center justify-between p-6">
                                    <div>
                                        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                            <BookOpen className="w-6 h-6 text-purple-400" />
                                            Course Content
                                        </h2>
                                        {course.lessons && (
                                            <p className="text-gray-400 text-sm mt-1">
                                                {course.lessons.length} lessons • {Math.floor(course.lessons.reduce((acc, l) => acc + l.duration, 0) / 60)} hours
                                            </p>
                                        )}
                                    </div>
                                    <button
                                        onClick={toggleSidebar}
                                        className="w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
                                    >
                                        <X className="w-6 h-6" />
                                    </button>
                                </div>

                                {/* Module Selector */}
                                {contentType === 'SERIES' && course.totalSeasons && course.totalSeasons > 1 && (
                                    <div className="flex gap-3 px-6 pb-4 overflow-x-auto">
                                        {Array.from({ length: course.totalSeasons }, (_, i) => i + 1).map((season) => {
                                            const seasonLessons = course.lessons?.filter(l => l.seasonNumber === season) || []
                                            const seasonDuration = seasonLessons.reduce((acc, l) => acc + l.duration, 0)
                                            
                                            return (
                                                <button
                                                    key={season}
                                                    onClick={() => setSelectedSeason(season)}
                                                    className={`flex-shrink-0 px-5 py-3 rounded-lg font-semibold transition-all text-sm ${
                                                        selectedSeason === season
                                                            ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                                                            : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                                                    }`}
                                                >
                                                    <div>Module {season}</div>
                                                    <div className="text-xs text-gray-400 mt-1">
                                                        {seasonLessons.length} lessons
                                                    </div>
                                                </button>
                                            )
                                        })}
                                    </div>
                                )}
                            </div>

                            {/* Lessons List */}
                            <div className="p-6">
                                {contentType === 'SERIES' && course.lessons && course.lessons.length > 0 && (
                                    <div className="space-y-3">
                                        {course.lessons
                                            .filter(lesson => !course.totalSeasons || course.totalSeasons <= 1 || lesson.seasonNumber === selectedSeason)
                                            .map((lesson, index) => {
                                                const isLocked = !hasSubscription
                                                const lessonNumber = lesson.episodeNumber || (index + 1)
                                                
                                                return (
                                                    <motion.div
                                                        key={lesson.id}
                                                        initial={{ opacity: 0, x: 50 }}
                                                        animate={{ opacity: 1, x: 0 }}
                                                        transition={{ delay: index * 0.05 }}
                                                        className={`bg-gray-800/50 border border-gray-700 rounded-xl p-4 hover:border-purple-500/50 transition-all group ${
                                                            !isLocked ? 'cursor-pointer hover:bg-gray-800' : 'cursor-not-allowed opacity-75'
                                                        }`}
                                                        onClick={() => {
                                                            if (!isLocked) {
                                                                router.push(`/${locale}/courses/${course.id}/learn?lesson=${lesson.id}`)
                                                            } else {
                                                                setShowSubscribeModal(true)
                                                                setShowSidebar(false)
                                                            }
                                                        }}
                                                    >
                                                        <div className="flex gap-4">
                                                            {/* Lesson Number/Play Button */}
                                                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                                                isLocked 
                                                                    ? 'bg-gray-700' 
                                                                    : 'bg-gradient-to-br from-purple-600 to-blue-600 group-hover:from-purple-500 group-hover:to-blue-500'
                                                            }`}>
                                                                {isLocked ? (
                                                                    <Lock className="w-5 h-5 text-gray-400" />
                                                                ) : (
                                                                    <Play className="w-5 h-5 text-white" fill="white" />
                                                                )}
                                                            </div>

                                                            {/* Lesson Info */}
                                                            <div className="flex-1 min-w-0">
                                                                <div className="flex items-start justify-between gap-2 mb-1">
                                                                    <div className="flex-1 min-w-0">
                                                                        <div className="text-xs text-gray-400 mb-1">
                                                                            Lesson {lessonNumber}
                                                                        </div>
                                                                        <h3 className="font-semibold text-white group-hover:text-purple-400 transition-colors line-clamp-2">
                                                                            {getLocalizedText(lesson.title, lesson.titleAr)}
                                                                        </h3>
                                                                    </div>
                                                                    {lessonNumber === 1 && !isLocked && (
                                                                        <Badge className="bg-green-600/20 text-green-400 border-green-600/30 text-xs flex-shrink-0">
                                                                            FREE
                                                                        </Badge>
                                                                    )}
                                                                </div>
                                                                
                                                                {lesson.description && (
                                                                    <p className="text-sm text-gray-400 line-clamp-2 mb-2">
                                                                        {getLocalizedText(lesson.description, lesson.descriptionAr)}
                                                                    </p>
                                                                )}

                                                                <div className="flex items-center gap-3 text-xs text-gray-500">
                                                                    <div className="flex items-center gap-1">
                                                                        <Clock className="w-3 h-3" />
                                                                        <span>{lesson.duration} min</span>
                                                                    </div>
                                                                    {lesson.videoUrl && (
                                                                        <div className="flex items-center gap-1">
                                                                            <Film className="w-3 h-3" />
                                                                            <span>HD</span>
                                                                        </div>
                                                                    )}
                                                                    {!isLocked && (
                                                                        <div className="flex items-center gap-1 text-green-500">
                                                                            <CheckCircle className="w-3 h-3" />
                                                                            <span>Unlocked</span>
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </motion.div>
                                                )
                                            })}
                                    </div>
                                )}

                                {/* Podcast Lessons */}
                                {contentType === 'PODCAST' && !course.lessons?.some(l => l.seasonNumber) && course.lessons && course.lessons.length > 0 && (
                                    <div className="space-y-3">
                                        {course.lessons
                                            .sort((a, b) => (a.order || 0) - (b.order || 0))
                                            .map((lesson, index) => {
                                                const isLocked = !hasSubscription
                                                
                                                return (
                                                    <motion.div
                                                        key={lesson.id}
                                                        initial={{ opacity: 0, x: 50 }}
                                                        animate={{ opacity: 1, x: 0 }}
                                                        transition={{ delay: index * 0.05 }}
                                                        className={`bg-gray-800/50 border border-gray-700 rounded-xl p-4 hover:border-green-500/50 transition-all group ${
                                                            !isLocked ? 'cursor-pointer hover:bg-gray-800' : 'cursor-not-allowed opacity-75'
                                                        }`}
                                                        onClick={() => {
                                                            if (!isLocked) {
                                                                router.push(`/${locale}/learn/${params.id}?lesson=${lesson.id}`)
                                                            } else {
                                                                setShowSubscribeModal(true)
                                                                setShowSidebar(false)
                                                            }
                                                        }}
                                                    >
                                                        <div className="flex gap-4">
                                                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                                                isLocked 
                                                                    ? 'bg-gray-700' 
                                                                    : 'bg-gradient-to-br from-green-600 to-emerald-600 group-hover:from-green-500 group-hover:to-emerald-500'
                                                            }`}>
                                                                {isLocked ? (
                                                                    <Lock className="w-5 h-5 text-gray-400" />
                                                                ) : (
                                                                    <Play className="w-5 h-5 text-white" fill="white" />
                                                                )}
                                                            </div>

                                                            <div className="flex-1 min-w-0">
                                                                <h3 className="font-semibold text-white group-hover:text-green-400 transition-colors line-clamp-2 mb-1">
                                                                    {getLocalizedText(lesson.title, lesson.titleAr, lesson.titleDe)}
                                                                </h3>
                                                                {lesson.description && (
                                                                    <p className="text-sm text-gray-400 line-clamp-2 mb-2">
                                                                        {getLocalizedText(lesson.description || '', lesson.descriptionAr, lesson.descriptionDe)}
                                                                    </p>
                                                                )}
                                                                <div className="flex items-center gap-3 text-xs text-gray-500">
                                                                    <div className="flex items-center gap-1">
                                                                        <Clock className="w-3 h-3" />
                                                                        <span>{lesson.duration} min</span>
                                                                    </div>
                                                                    {!isLocked && (
                                                                        <div className="flex items-center gap-1 text-green-500">
                                                                            <CheckCircle className="w-3 h-3" />
                                                                            <span>Unlocked</span>
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </motion.div>
                                                )
                                            })}
                                    </div>
                                )}

                                {/* Locked Message */}
                                {!hasSubscription && course.lessons && course.lessons.length > 0 && (
                                    <div className="mt-6 bg-gradient-to-r from-yellow-600/10 to-orange-600/5 border border-yellow-600/30 rounded-xl p-6 text-center">
                                        <Lock className="w-10 h-10 mx-auto mb-3 text-yellow-500" />
                                        <h3 className="text-lg font-bold mb-2">Unlock All {course.lessons.length} Lessons</h3>
                                        <p className="text-gray-400 text-sm mb-4">
                                            Subscribe to access this course and thousands more
                                        </p>
                                        <Button 
                                            className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white"
                                            onClick={() => {
                                                setShowSubscribeModal(true)
                                                setShowSidebar(false)
                                            }}
                                        >
                                            <Play className="w-4 h-4 mr-2" />
                                            Subscribe Now
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            {/* Hero Section with Video Player */}
            <div className="relative h-screen">
                {/* Background Video/Image */}
                <div className="absolute inset-0">
                    {/* Video Player */}
                    <video
                        ref={videoRef}
                        src="/videos/demo/course-promo.mp4"
                        className="absolute inset-0 w-full h-full object-cover"
                        autoPlay
                        muted
                        loop
                        playsInline
                    />
                    
                    {/* Fallback Image */}
                    {course.thumbnail && !isPlaying && (
                        <Image
                            src={course.thumbnail}
                            alt={getLocalizedText(course.title, course.titleAr, course.titleDe)}
                            fill
                            className="object-cover"
                            priority
                        />
                    )}
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />
                </div>

                {/* Back Button */}
                <button
                    onClick={() => router.back()}
                    className="absolute top-8 left-8 z-50 w-12 h-12 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center backdrop-blur-sm transition-colors"
                >
                    <ArrowLeft className="w-6 h-6" />
                </button>

                {/* Mute/Unmute Button */}
                <button
                    onClick={toggleMute}
                    className="absolute top-8 right-8 z-50 w-12 h-12 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center backdrop-blur-sm transition-colors"
                >
                    {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                </button>

                {/* Content */}
                <div className="relative z-10 h-full flex items-center px-16 max-w-7xl">
                    <div className="max-w-2xl space-y-6">
                        {/* Content Type Badge */}
                        <div className="flex items-center gap-3">
                            <Badge className={`
                                px-4 py-2 text-sm font-semibold flex items-center gap-2
                                ${contentType === 'MOVIE' ? 'bg-blue-600' : ''}
                                ${contentType === 'SERIES' ? 'bg-purple-600' : ''}
                                ${contentType === 'PODCAST' ? 'bg-green-600' : ''}
                            `}>
                                {getContentTypeIcon()}
                                {getContentTypeLabel()}
                            </Badge>
                            {course.releaseYear && (
                                <span className="text-gray-300 text-lg">{course.releaseYear}</span>
                            )}
                            {course.maturityRating && (
                                <Badge variant="outline" className="text-white border-gray-500">
                                    {course.maturityRating}
                                </Badge>
                            )}
                        </div>

                        {/* Title */}
                        <h1 className="text-5xl md:text-7xl font-black leading-tight">
                            {getLocalizedText(course.title, course.titleAr, course.titleDe)}
                        </h1>

                        {/* Metadata */}
                        <div className="flex items-center gap-4 text-lg">
                            {course.rating && (
                                <div className="flex items-center gap-2">
                                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                                    <span className="font-bold">{course.rating.toFixed(1)}</span>
                                </div>
                            )}
                            <span className="text-gray-300">{getMetadataLabel()}</span>
                            {contentType === 'SERIES' && course.episodeDuration && (
                                <span className="text-gray-300">
                                    {course.episodeDuration} min/lesson
                                </span>
                            )}
                        </div>

                        {/* Description */}
                        <p className="text-xl text-gray-300 line-clamp-3 leading-relaxed">
                            {getLocalizedText(course.description, course.descriptionAr, course.descriptionDe)}
                        </p>

                        {/* Genres */}
                        {course.genres && (() => {
                            try {
                                const genres = JSON.parse(course.genres)
                                return (
                                    <div className="flex flex-wrap gap-2">
                                        {genres.map((genre: string, index: number) => (
                                            <Badge key={index} variant="outline" className="text-gray-300 border-gray-600">
                                                {genre}
                                            </Badge>
                                        ))}
                                    </div>
                                )
                            } catch {
                                return null
                            }
                        })()}

                        {/* Action Buttons */}
                        <div className="flex items-center gap-4 pt-4">
                            <Button
                                size="lg"
                                className="bg-white hover:bg-white/90 text-black text-lg px-8 py-6 rounded-md"
                                onClick={handlePlay}
                                disabled={subscriptionLoading}
                            >
                                {subscriptionLoading ? (
                                    <>Loading...</>
                                ) : !hasSubscription ? (
                                    <>
                                        <Lock className="w-6 h-6 mr-2" />
                                        Subscribe to Watch
                                    </>
                                ) : (
                                    <>
                                        <Play className="w-6 h-6 mr-2" fill="currentColor" />
                                        {contentType === 'MOVIE' && 'Watch Now'}
                                        {contentType === 'SERIES' && 'Play'}
                                        {contentType === 'PODCAST' && 'Listen Now'}
                                    </>
                                )}
                            </Button>

                            <Button
                                size="lg"
                                variant="outline"
                                className="bg-gray-600/50 hover:bg-gray-600/70 text-white border-gray-500 hover:border-gray-400 text-lg px-8 py-6 rounded-md backdrop-blur-sm"
                                onClick={toggleSidebar}
                            >
                                <Info className="w-6 h-6 mr-2" />
                                Course Content
                            </Button>

                            {/* Icon Buttons */}
                            <button
                                onClick={handleMyList}
                                className="w-12 h-12 rounded-full border-2 border-gray-400 hover:border-white flex items-center justify-center transition-colors group relative"
                                title={isInMyList ? 'Remove from My List' : 'Add to My List'}
                            >
                                {isInMyList ? <Check className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
                                {isInMyList && (
                                    <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                                        In My List
                                    </span>
                                )}
                            </button>

                            <button
                                onClick={handleLike}
                                className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-colors group relative ${
                                    netflixLiked === true ? 'border-white bg-white/20' : 'border-gray-400 hover:border-white'
                                }`}
                                title="Like"
                            >
                                <ThumbsUp className={`w-6 h-6 ${netflixLiked === true ? 'fill-white' : ''}`} />
                                {netflixLiked === true && (
                                    <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                                        Liked ❤️
                                    </span>
                                )}
                            </button>

                            <button
                                onClick={handleDislike}
                                className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-colors ${
                                    netflixLiked === false ? 'border-white bg-white/20' : 'border-gray-400 hover:border-white'
                                }`}
                                title="Dislike"
                            >
                                <ThumbsDown className={`w-6 h-6 ${netflixLiked === false ? 'fill-white' : ''}`} />
                            </button>
                        </div>

                        {/* Quick Access to My List */}
                        {session && (isInMyList || netflixLiked === true) && (
                            <div className="flex items-center gap-3 pt-2">
                                {isInMyList && (
                                    <button
                                        onClick={() => router.push(`/${locale}/dashboard?tab=my-list`)}
                                        className="text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                                    >
                                        <Bookmark className="w-4 h-4" />
                                        View My List
                                    </button>
                                )}
                                {netflixLiked === true && (
                                    <button
                                        onClick={() => router.push(`/${locale}/dashboard?tab=liked`)}
                                        className="text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-2"
                                    >
                                        <ThumbsUp className="w-4 h-4" />
                                        View Liked Courses
                                    </button>
                                )}
                            </div>
                        )}

                        {/* Creator Info */}
                        {course.creator?.user && (
                            <div className="flex items-center gap-4 pt-4">
                                {course.creator.user.profileImage && (
                                    <div className="w-12 h-12 rounded-full overflow-hidden">
                                        <Image
                                            src={course.creator.user.profileImage}
                                            alt={course.creator.user.name}
                                            width={48}
                                            height={48}
                                            className="object-cover"
                                        />
                                    </div>
                                )}
                                <div>
                                    <div className="text-sm text-gray-400">
                                        {contentType === 'PODCAST' ? 'Hosted by' : 'Created by'}
                                    </div>
                                    <div className="text-lg font-semibold">
                                        {getLocalizedText(course.creator.user.name, course.creator.user.arabicName)}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Podcast Lessons List */}
            {contentType === 'PODCAST' && !course.lessons?.some(l => l.seasonNumber) && course.lessons && course.lessons.length > 0 && (
                <div className="px-16 py-12 max-w-7xl">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-3xl font-bold">Podcast Lessons</h2>
                        {course.frequency && (
                            <Badge className="bg-green-600 text-white px-4 py-2">
                                {course.frequency}
                            </Badge>
                        )}
                    </div>

                    <div className="space-y-3">
                        {course.lessons
                            .sort((a, b) => (a.order || 0) - (b.order || 0))
                            .map((lesson, index) => (
                                <motion.div
                                    key={lesson.id}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: index * 0.03 }}
                                    className="group bg-gray-900/50 hover:bg-gray-800/80 rounded-lg p-4 flex gap-4 items-center cursor-pointer border border-gray-800 hover:border-green-600 transition-all"
                                    onClick={() => hasSubscription && router.push(`/${locale}/learn/${params.id}?lesson=${lesson.id}`)}
                                >
                                    {/* Play/Lock Button */}
                                    <button className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
                                        hasSubscription ? 'bg-green-600 hover:bg-green-500' : 'bg-gray-600'
                                    }`}>
                                        {hasSubscription ? (
                                            <Play className="w-5 h-5 ml-0.5" fill="white" />
                                        ) : (
                                            <Lock className="w-5 h-5" />
                                        )}
                                    </button>

                                    {/* Lesson Info */}
                                    <div className="flex-1">
                                        <h3 className="text-lg font-semibold mb-1">
                                            {getLocalizedText(lesson.title, lesson.titleAr, lesson.titleDe)}
                                        </h3>
                                        {lesson.description && (
                                            <p className="text-gray-400 text-sm line-clamp-1">
                                                {getLocalizedText(lesson.description || '', lesson.descriptionAr, lesson.descriptionDe)}
                                            </p>
                                        )}
                                    </div>

                                    {/* Duration */}
                                    <div className="flex items-center gap-4 text-gray-400">
                                        <span className="text-sm">{lesson.duration} min</span>
                                        {hasSubscription && (
                                            <>
                                                <button className="hover:text-white">
                                                    <Download className="w-5 h-5" />
                                                </button>
                                                <button className="hover:text-white">
                                                    <MoreVertical className="w-5 h-5" />
                                                </button>
                                            </>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                    </div>
                </div>
            )}

            {/* Course Stats Bar - Netflix Style */}
            <div className="px-16 py-8 border-y border-gray-800">
                <div className="max-w-7xl grid grid-cols-2 md:grid-cols-4 gap-8">
                    {course.totalEnrollments && (
                        <div className="text-center">
                            <div className="text-4xl font-black text-yellow-500 mb-2">
                                {course.totalEnrollments.toLocaleString()}+
                            </div>
                            <div className="text-gray-400 text-sm">Students Enrolled</div>
                        </div>
                    )}
                    
                    {course.rating && (
                        <div className="text-center">
                            <div className="flex items-center justify-center gap-2 mb-2">
                                <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                                <span className="text-4xl font-black text-yellow-400">{course.rating.toFixed(1)}</span>
                            </div>
                            <div className="text-gray-400 text-sm">Course Rating</div>
                        </div>
                    )}

                    {course.lessons && (
                        <div className="text-center">
                            <div className="text-4xl font-black text-purple-500 mb-2">
                                {course.lessons.length}
                            </div>
                            <div className="text-gray-400 text-sm">Total Lessons</div>
                        </div>
                    )}

                    {course.lessons && (
                        <div className="text-center">
                            <div className="text-4xl font-black text-blue-500 mb-2">
                                {Math.floor(course.lessons.reduce((acc, l) => acc + l.duration, 0) / 60)}h
                            </div>
                            <div className="text-gray-400 text-sm">Total Duration</div>
                        </div>
                    )}
                </div>
            </div>

            {/* Course Details Section - Always Visible */}
            <div className="px-16 py-12 max-w-7xl">
                <h2 className="text-3xl font-bold mb-8">About This Course</h2>
                <div className="grid md:grid-cols-3 gap-12">
                    {/* Left Column - Full Width Description */}
                    <div className="md:col-span-2 space-y-8">
                        <div>
                            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                                <Film className="w-6 h-6 text-purple-500" />
                                Course Overview
                            </h3>
                            <div className="bg-gradient-to-br from-purple-500/5 to-blue-500/5 rounded-2xl p-6 border border-purple-500/20">
                                <p className="text-gray-300 leading-relaxed text-lg">
                                    {getLocalizedText(course.description, course.descriptionAr, course.descriptionDe)}
                                </p>
                            </div>
                        </div>

                        {/* What You'll Learn */}
                        <div>
                            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                                <CheckCircle className="w-6 h-6 text-green-500" />
                                What You'll Learn
                            </h3>
                            <div className="bg-gradient-to-br from-green-500/5 to-emerald-500/5 rounded-2xl p-6 border border-green-500/20">
                                <div className="grid md:grid-cols-2 gap-4">
                                    {[
                                        'Build responsive websites from scratch using HTML5, CSS3, and modern frameworks',
                                        'Master modern JavaScript and ES6+ features including async/await and modules',
                                        'Create dynamic React applications with hooks, context, and state management',
                                        'Deploy real-world projects to production using CI/CD pipelines',
                                        'Work with RESTful APIs and integrate third-party services',
                                        'Build full-stack applications with Node.js, Express, and databases',
                                        'Implement authentication and authorization systems',
                                        'Write clean, maintainable code following industry best practices'
                                    ].map((skill, index) => (
                                        <motion.div 
                                            key={index}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: index * 0.05 }}
                                            className="flex items-start gap-3 bg-gray-900/50 rounded-lg p-4 hover:bg-gray-800/50 transition-colors"
                                        >
                                            <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                                <Check className="w-4 h-4 text-green-500" />
                                            </div>
                                            <span className="text-gray-300 leading-relaxed">{skill}</span>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Instructor Section */}
                        {course.creator?.user && (
                            <div>
                                <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                                    <Users className="w-6 h-6 text-blue-500" />
                                    Your Instructor
                                </h3>
                                <motion.div 
                                    className="bg-gradient-to-br from-gray-900 via-gray-900 to-gray-800 rounded-xl p-6 border border-gray-700/50 cursor-pointer group hover:border-blue-500/50 transition-all hover:shadow-lg hover:shadow-blue-500/10"
                                    whileHover={{ scale: 1.01, y: -2 }}
                                    transition={{ type: "spring", stiffness: 300 }}
                                    onClick={() => router.push(`/${locale}/creators/${course.creator?.user.id}`)}
                                >
                                    <div className="flex items-center gap-4">
                                        {course.creator.user.profileImage ? (
                                            <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0 ring-2 ring-blue-500/20 group-hover:ring-blue-500/50 transition-all">
                                                <Image
                                                    src={course.creator.user.profileImage}
                                                    alt={course.creator.user.name}
                                                    width={64}
                                                    height={64}
                                                    className="object-cover"
                                                />
                                            </div>
                                        ) : (
                                            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-xl font-black text-white ring-2 ring-blue-500/20 group-hover:ring-blue-500/50 transition-all">
                                                {course.creator.user.name.charAt(0).toUpperCase()}
                                            </div>
                                        )}
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="text-xl font-bold text-white truncate">
                                                    {getLocalizedText(course.creator.user.name, course.creator.user.arabicName)}
                                                </h4>
                                                <ArrowRight className="w-4 h-4 text-blue-500 opacity-0 group-hover:opacity-100 transform group-hover:translate-x-1 transition-all flex-shrink-0" />
                                            </div>
                                            <p className="text-sm text-blue-400 mb-3">Senior Full-Stack Developer & Educator</p>
                                            <div className="flex items-center gap-6 text-sm">
                                                <div className="flex items-center gap-1.5">
                                                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                                    <span className="font-semibold text-yellow-400">4.9</span>
                                                    <span className="text-gray-400">Rating</span>
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <Users className="w-4 h-4 text-purple-400" />
                                                    <span className="font-semibold text-purple-400">50K+</span>
                                                    <span className="text-gray-400">Students</span>
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <Award className="w-4 h-4 text-blue-400" />
                                                    <span className="font-semibold text-blue-400">15</span>
                                                    <span className="text-gray-400">Courses</span>
                                                </div>
                                            </div>
                                        </div>
                                        <ChevronDown className="w-5 h-5 text-gray-400 group-hover:text-blue-400 transform group-hover:rotate-[-90deg] transition-all flex-shrink-0" />
                                    </div>
                                </motion.div>
                            </div>
                        )}

                        {course.cast && (() => {
                            try {
                                const cast = JSON.parse(course.cast)
                                return (
                                    <div>
                                        <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                                            <Award className="w-5 h-5 text-yellow-500" />
                                            Teaching Assistants
                                        </h3>
                                        <p className="text-gray-300">
                                            {cast.join(', ')}
                                        </p>
                                    </div>
                                )
                            } catch {
                                return null
                            }
                        })()}
                    </div>

                    {/* Right Column - Quick Info */}
                    <div className="space-y-6">
                        <div className="bg-gray-900/50 rounded-lg p-6 border border-gray-800 sticky top-8">
                            <h3 className="text-xl font-bold mb-4">Course Information</h3>
                            <div className="space-y-4">
                                {contentType === 'SERIES' && (
                                    <>
                                        <div className="flex items-center gap-3 pb-4 border-b border-gray-800">
                                            <Award className="w-5 h-5 text-purple-400 flex-shrink-0" />
                                            <div className="flex-1">
                                                <div className="text-sm text-gray-400">Modules</div>
                                                <div className="font-semibold">{course.totalSeasons} Modules</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-3 pb-4 border-b border-gray-800">
                                            <CheckCircle className="w-5 h-5 text-purple-400 flex-shrink-0" />
                                            <div className="flex-1">
                                                <div className="text-sm text-gray-400">Lessons</div>
                                                <div className="font-semibold">{course.totalEpisodes} Lessons</div>
                                            </div>
                                        </div>
                                    </>
                                )}

                                {course.lessons && (
                                    <div className="flex items-center gap-3 pb-4 border-b border-gray-800">
                                        <Clock className="w-5 h-5 text-blue-400 flex-shrink-0" />
                                        <div className="flex-1">
                                            <div className="text-sm text-gray-400">Duration</div>
                                            <div className="font-semibold">
                                                {Math.floor(course.lessons.reduce((acc, l) => acc + l.duration, 0) / 60)} hours
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {course.releaseYear && (
                                    <div className="flex items-center gap-3 pb-4 border-b border-gray-800">
                                        <Calendar className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                        <div className="flex-1">
                                            <div className="text-sm text-gray-400">Published</div>
                                            <div className="font-semibold">{course.releaseYear}</div>
                                        </div>
                                    </div>
                                )}

                                {course.maturityRating && (
                                    <div className="flex items-center gap-3">
                                        <Eye className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                        <div className="flex-1">
                                            <div className="text-sm text-gray-400">Suitable For</div>
                                            <div className="font-semibold">{course.maturityRating}</div>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {course.genres && (() => {
                                try {
                                    const genres = JSON.parse(course.genres)
                                    return (
                                        <div className="mt-6 pt-6 border-t border-gray-800">
                                            <h4 className="text-sm text-gray-400 mb-3">Topics</h4>
                                            <div className="flex flex-wrap gap-2">
                                                {genres.map((genre: string, index: number) => (
                                                    <Badge key={index} variant="outline" className="text-gray-300 border-gray-600 px-3 py-1">
                                                        {genre}
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )
                                } catch {
                                    return null
                                }
                            })()}
                        </div>
                    </div>
                </div>
            </div>

            {/* Enhanced Subscription Modal */}
            <AnimatePresence>
                {showSubscribeModal && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4"
                        onClick={() => setShowSubscribeModal(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.95, opacity: 0, y: 20 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.95, opacity: 0, y: 20 }}
                            transition={{ type: "spring", duration: 0.5 }}
                            className="bg-gradient-to-br from-gray-900 via-gray-900 to-black rounded-3xl max-w-7xl w-full max-h-[90vh] overflow-y-auto border border-gray-700/50 shadow-2xl"
                            onClick={(e) => e.stopPropagation()}
                        >
                            {/* Close Button */}
                            <button
                                onClick={() => setShowSubscribeModal(false)}
                                className="absolute top-6 right-6 w-10 h-10 rounded-full bg-gray-800/80 hover:bg-gray-700 flex items-center justify-center transition-colors z-10"
                            >
                                <X className="w-6 h-6" />
                            </button>

                            {/* Hero Section */}
                            <div className="relative overflow-hidden pt-16 pb-12 px-8 text-center border-b border-gray-800">
                                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 via-transparent to-blue-600/10"></div>
                                <Lock className="w-20 h-20 mx-auto mb-6 text-yellow-500 relative" />
                                <h2 className="text-5xl font-black mb-4 bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent relative">
                                    Unlock Unlimited Learning
                                </h2>
                                <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-6 relative">
                                    Choose a plan to access this course and thousands more. Cancel anytime.
                                </p>
                                <div className="flex items-center justify-center gap-6 text-sm text-gray-400 relative">
                                    <div className="flex items-center gap-2">
                                        <Shield className="w-4 h-4 text-green-500" />
                                        <span>7-Day Money Back</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <CheckCircle className="w-4 h-4 text-green-500" />
                                        <span>No Commitment</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Users className="w-4 h-4 text-green-500" />
                                        <span>10K+ Active Learners</span>
                                    </div>
                                </div>
                            </div>

                            {/* Pricing Cards */}
                            <div className="p-8">
                                <div className="grid lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
                                    {/* Category A - All-Access Library */}
                                    <motion.div
                                        whileHover={{ scale: 1.03, y: -5 }}
                                        className="relative bg-gradient-to-br from-yellow-600/10 to-orange-600/5 border-2 border-yellow-600/50 rounded-2xl p-8 hover:border-yellow-500 transition-all cursor-pointer group"
                                        onClick={() => router.push(`/${locale}/subscribe?plan=CATEGORY_A`)}
                                    >
                                        <div className="absolute top-6 right-6">
                                            <BookOpen className="w-8 h-8 text-yellow-500 opacity-20 group-hover:opacity-40 transition-opacity" />
                                        </div>

                                        <div className="mb-6">
                                            <h3 className="text-2xl font-bold mb-2 text-yellow-400">All-Access Library</h3>
                                            <p className="text-gray-400 text-sm">Category A - Amazon of Learning</p>
                                        </div>

                                        <div className="mb-6">
                                            <div className="flex items-baseline gap-2">
                                                <span className="text-5xl font-black text-white">$29</span>
                                                <span className="text-gray-400">/month</span>
                                            </div>
                                            <p className="text-sm text-gray-500 mt-1">or $279/year (save $69)</p>
                                        </div>

                                        <div className="space-y-3 mb-8">
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Access to 500+ courses across all topics</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">HD streaming quality (1080p)</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Download for offline viewing</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Basic certificates of completion</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Community forum access</span>
                                            </div>
                                        </div>

                                        <Button className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white font-bold py-6 text-lg">
                                            Get Started
                                            <ArrowRight className="w-5 h-5 ml-2" />
                                        </Button>
                                    </motion.div>

                                    {/* Bundle AB - Pro (Most Popular) */}
                                    <motion.div
                                        whileHover={{ scale: 1.03, y: -5 }}
                                        className="relative bg-gradient-to-br from-purple-600/20 to-blue-600/10 border-2 border-purple-500 rounded-2xl p-8 hover:border-purple-400 transition-all cursor-pointer group shadow-xl shadow-purple-900/20"
                                        onClick={() => router.push(`/${locale}/subscribe?plan=BUNDLE_AB`)}
                                    >
                                        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                                            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs font-black px-6 py-2 rounded-full uppercase tracking-wider shadow-lg">
                                                ⭐ Most Popular
                                            </div>
                                        </div>

                                        <div className="absolute top-6 right-6">
                                            <Sparkles className="w-8 h-8 text-purple-500 opacity-20 group-hover:opacity-40 transition-opacity" />
                                        </div>

                                        <div className="mb-6 mt-4">
                                            <h3 className="text-2xl font-bold mb-2 text-purple-400">Pro Bundle</h3>
                                            <p className="text-gray-400 text-sm">Categories A + B Signature</p>
                                        </div>

                                        <div className="mb-6">
                                            <div className="flex items-baseline gap-2">
                                                <span className="text-5xl font-black text-white">$49</span>
                                                <span className="text-gray-400">/month</span>
                                            </div>
                                            <p className="text-sm text-gray-500 mt-1">or $469/year (save $119)</p>
                                        </div>

                                        <div className="space-y-3 mb-8">
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm font-semibold">Everything in All-Access, plus:</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">50+ premium signature courses</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">4K Ultra HD streaming quality</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Expert-curated learning paths</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Priority email support</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Professional certificates</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Structured workbooks & projects</span>
                                            </div>
                                        </div>

                                        <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-6 text-lg">
                                            Choose Pro
                                            <ArrowRight className="w-5 h-5 ml-2" />
                                        </Button>
                                    </motion.div>

                                    {/* Bundle ABC - Ultimate */}
                                    <motion.div
                                        whileHover={{ scale: 1.03, y: -5 }}
                                        className="relative bg-gradient-to-br from-blue-600/10 to-cyan-600/5 border-2 border-blue-600/50 rounded-2xl p-8 hover:border-blue-500 transition-all cursor-pointer group"
                                        onClick={() => router.push(`/${locale}/subscribe?plan=BUNDLE_ABC`)}
                                    >
                                        <div className="absolute top-6 right-6">
                                            <Star className="w-8 h-8 text-blue-500 opacity-20 group-hover:opacity-40 transition-opacity" />
                                        </div>

                                        <div className="mb-6">
                                            <h3 className="text-2xl font-bold mb-2 text-blue-400">Ultimate</h3>
                                            <p className="text-gray-400 text-sm">Categories A + B + C Creators</p>
                                        </div>

                                        <div className="mb-6">
                                            <div className="flex items-baseline gap-2">
                                                <span className="text-5xl font-black text-white">$79</span>
                                                <span className="text-gray-400">/month</span>
                                            </div>
                                            <p className="text-sm text-gray-500 mt-1">or $759/year (save $189)</p>
                                        </div>

                                        <div className="space-y-3 mb-8">
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm font-semibold">Everything in Pro, plus:</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Access to creator membership channels</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Live Q&A sessions with experts</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">1:1 coaching opportunities</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Private community access</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">Creator tools & resources</span>
                                            </div>
                                            <div className="flex items-start gap-3">
                                                <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                                <span className="text-gray-300 text-sm">VIP support (24/7)</span>
                                            </div>
                                        </div>

                                        <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold py-6 text-lg">
                                            Get Ultimate
                                            <ArrowRight className="w-5 h-5 ml-2" />
                                        </Button>
                                    </motion.div>
                                </div>

                                {/* Category Explanations */}
                                <div className="mt-12 pt-8 border-t border-gray-800 max-w-6xl mx-auto">
                                    <h3 className="text-2xl font-bold mb-6 text-center">What's Included in Each Category?</h3>
                                    <div className="grid md:grid-cols-3 gap-6 text-sm">
                                        <div className="bg-gray-800/30 rounded-lg p-6">
                                            <h4 className="font-bold text-yellow-400 mb-3 flex items-center gap-2">
                                                <BookOpen className="w-5 h-5" />
                                                Category A: All-Access Library
                                            </h4>
                                            <p className="text-gray-400 leading-relaxed">
                                                The "Amazon of Learning" - a vast library of pre-recorded courses across every topic. 
                                                Perfect for self-paced learners who want variety and flexibility.
                                            </p>
                                        </div>
                                        <div className="bg-gray-800/30 rounded-lg p-6">
                                            <h4 className="font-bold text-purple-400 mb-3 flex items-center gap-2">
                                                <Sparkles className="w-5 h-5" />
                                                Category B: Signature Courses
                                            </h4>
                                            <p className="text-gray-400 leading-relaxed">
                                                Premium, expertly-curated programs from industry leaders. 
                                                Cinematic production, structured workbooks, and professional-grade content.
                                            </p>
                                        </div>
                                        <div className="bg-gray-800/30 rounded-lg p-6">
                                            <h4 className="font-bold text-blue-400 mb-3 flex items-center gap-2">
                                                <Users className="w-5 h-5" />
                                                Category C: Creator Channels
                                            </h4>
                                            <p className="text-gray-400 leading-relaxed">
                                                Subscribe directly to creators for exclusive content, live sessions, 
                                                community access, and personalized coaching. Interactive learning at its best.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Trust Badges */}
                                <div className="mt-12 flex flex-wrap justify-center gap-8 text-center text-sm text-gray-400">
                                    <div className="flex items-center gap-2">
                                        <Shield className="w-5 h-5 text-green-500" />
                                        <span>SSL Secured</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <CheckCircle className="w-5 h-5 text-green-500" />
                                        <span>Cancel Anytime</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Star className="w-5 h-5 text-yellow-500" />
                                        <span>4.8/5 Rating</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Users className="w-5 h-5 text-blue-500" />
                                        <span>10,000+ Active Learners</span>
                                    </div>
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}
