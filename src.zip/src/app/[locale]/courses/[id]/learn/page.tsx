'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle, 
  Circle,
  Lock,
  Download,
  MessageSquare,
  BookOpen,
  Clock,
  Award,
  Menu,
  X
} from 'lucide-react';
import { useTranslationsSafe } from '@/hooks/useTranslationsSafe';
import toast from 'react-hot-toast';

interface Lesson {
  id: string;
  title: string;
  titleAr?: string;
  description: string;
  descriptionAr?: string;
  videoUrl: string;
  duration: number;
  order: number;
  isCompleted: boolean;
  isCurrent: boolean;
}

interface Course {
  id: string;
  title: string;
  titleAr?: string;
  description: string;
  descriptionAr?: string;
  thumbnail: string;
  instructor: {
    name: string;
    arabicName?: string;
    image?: string;
  };
  lessons: Lesson[];
  progress: number;
  totalDuration: number;
}

export default function CourseLearnPage() {
  const params = useParams();
  const router = useRouter();
  const { data: session } = useSession();
  const { t, locale } = useTranslationsSafe('courses');
  const isRtl = locale === 'ar';
  
  const [course, setCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session) {
      router.push(`/${locale}/auth/login?redirect=/courses/${params.id}/learn`);
      return;
    }
    
    fetchCourse();
  }, [params.id, session]);

  const fetchCourse = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/courses/${params.id}/learn`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch course');
      }
      
      const data = await response.json();
      
      // Transform API response to match our component state
      const transformedCourse = {
        id: data.course.id,
        title: data.course.title,
        titleAr: data.course.titleAr,
        description: data.course.description,
        descriptionAr: data.course.descriptionAr,
        thumbnail: data.course.thumbnail,
        instructor: {
          name: 'Instructor', // Will be populated from API
          arabicName: 'المدرب',
          image: undefined,
        },
        lessons: data.course.modules[0]?.lessons || [],
        progress: data.course.progress || 0,
        totalDuration: data.course.totalDuration || 0,
      };
      
      setCourse(transformedCourse);
      
      // Set first incomplete lesson or first lesson as current
      const firstIncomplete = transformedCourse.lessons.find((l: Lesson) => !l.isCompleted);
      setCurrentLesson(firstIncomplete || transformedCourse.lessons[0]);
    } catch (error) {
      console.error('Error fetching course:', error);
      toast.error('Failed to load course');
      router.push(`/${locale}/courses/${params.id}`);
    } finally {
      setLoading(false);
    }
  };

  const markLessonComplete = async (lessonId: string) => {
    try {
      await fetch(`/api/courses/${params.id}/lessons/${lessonId}/complete`, {
        method: 'POST',
      });
      
      // Update local state
      if (course) {
        const updatedLessons = course.lessons.map(lesson =>
          lesson.id === lessonId ? { ...lesson, isCompleted: true } : lesson
        );
        setCourse({ ...course, lessons: updatedLessons });
      }
      
      toast.success(isRtl ? 'تم إكمال الدرس!' : 'Lesson completed!');
    } catch (error) {
      console.error('Error marking lesson complete:', error);
      toast.error('Failed to mark lesson as complete');
    }
  };

  const goToNextLesson = () => {
    if (!course || !currentLesson) return;
    
    const currentIndex = course.lessons.findIndex(l => l.id === currentLesson.id);
    if (currentIndex < course.lessons.length - 1) {
      setCurrentLesson(course.lessons[currentIndex + 1]);
      window.scrollTo(0, 0);
    }
  };

  const goToPreviousLesson = () => {
    if (!course || !currentLesson) return;
    
    const currentIndex = course.lessons.findIndex(l => l.id === currentLesson.id);
    if (currentIndex > 0) {
      setCurrentLesson(course.lessons[currentIndex - 1]);
      window.scrollTo(0, 0);
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}${isRtl ? 'س' : 'h'} ${mins}${isRtl ? 'د' : 'm'}`;
    }
    return `${mins}${isRtl ? 'د' : 'm'}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">{isRtl ? 'جاري التحميل...' : 'Loading...'}</p>
        </div>
      </div>
    );
  }

  if (!course || !currentLesson) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-400">{isRtl ? 'الدورة غير موجودة' : 'Course not found'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      {/* Top Navigation Bar */}
      <nav className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => router.push(`/${locale}/courses/${params.id}`)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <ChevronLeft className={`w-5 h-5 text-gray-400 ${isRtl ? 'rotate-180' : ''}`} />
          </button>
          
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors lg:hidden"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          
          <div>
            <h1 className="text-white font-semibold text-sm md:text-base line-clamp-1">
              {isRtl ? course.titleAr || course.title : course.title}
            </h1>
            <p className="text-gray-400 text-xs">
              {course.instructor.arabicName || course.instructor.name}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-sm">
            <div className="w-32 bg-gray-800 rounded-full h-2">
              <div 
                className="bg-purple-500 h-2 rounded-full transition-all"
                style={{ width: `${course.progress}%` }}
              ></div>
            </div>
            <span className="text-gray-400 text-xs">{Math.round(course.progress)}%</span>
          </div>
        </div>
      </nav>

      <div className="flex flex-1 overflow-hidden">
        {/* Main Content Area */}
        <div className={`flex-1 overflow-y-auto ${sidebarOpen ? 'hidden lg:block' : ''}`}>
          {/* Video Player */}
          <div className="bg-black aspect-video relative">
            {currentLesson.videoUrl ? (
              <iframe
                src={currentLesson.videoUrl.replace('watch?v=', 'embed/')}
                className="w-full h-full"
                allowFullScreen
                title={currentLesson.title}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-900">
                <div className="text-center">
                  <Play className="w-20 h-20 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-500">{isRtl ? 'لا يوجد فيديو متاح' : 'No video available'}</p>
                </div>
              </div>
            )}
          </div>

          {/* Lesson Info */}
          <div className="p-6 bg-gray-900">
            <div className="max-w-4xl">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-white mb-2">
                    {isRtl ? currentLesson.titleAr || currentLesson.title : currentLesson.title}
                  </h2>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatDuration(currentLesson.duration)}
                    </span>
                    <span>
                      {isRtl ? 'الدرس' : 'Lesson'} {currentLesson.order} {isRtl ? 'من' : 'of'} {course.lessons.length}
                    </span>
                  </div>
                </div>

                {!currentLesson.isCompleted && (
                  <button
                    onClick={() => markLessonComplete(currentLesson.id)}
                    className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg flex items-center gap-2 transition-colors"
                  >
                    <CheckCircle className="w-4 h-4" />
                    {isRtl ? 'وضع علامة كمكتمل' : 'Mark Complete'}
                  </button>
                )}
              </div>

              <p className="text-gray-300 mb-6">
                {isRtl ? currentLesson.descriptionAr || currentLesson.description : currentLesson.description}
              </p>

              {/* Navigation Buttons */}
              <div className="flex gap-4">
                <button
                  onClick={goToPreviousLesson}
                  disabled={course.lessons[0].id === currentLesson.id}
                  className="flex-1 px-4 py-3 bg-gray-800 hover:bg-gray-700 disabled:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                  <ChevronLeft className={`w-5 h-5 ${isRtl ? 'rotate-180' : ''}`} />
                  {isRtl ? 'الدرس السابق' : 'Previous Lesson'}
                </button>
                
                <button
                  onClick={goToNextLesson}
                  disabled={course.lessons[course.lessons.length - 1].id === currentLesson.id}
                  className="flex-1 px-4 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                  {isRtl ? 'الدرس التالي' : 'Next Lesson'}
                  <ChevronRight className={`w-5 h-5 ${isRtl ? 'rotate-180' : ''}`} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar - Lessons List */}
        <div className={`w-full lg:w-96 bg-gray-900 border-l border-gray-800 overflow-y-auto ${!sidebarOpen ? 'hidden' : ''}`}>
          <div className="p-4 border-b border-gray-800">
            <h3 className="text-white font-semibold mb-2">
              {isRtl ? 'محتوى الدورة' : 'Course Content'}
            </h3>
            <p className="text-sm text-gray-400">
              {course.lessons.filter(l => l.isCompleted).length} / {course.lessons.length} {isRtl ? 'مكتمل' : 'completed'}
            </p>
          </div>

          <div className="divide-y divide-gray-800">
            {course.lessons.map((lesson, index) => (
              <button
                key={lesson.id}
                onClick={() => setCurrentLesson(lesson)}
                className={`w-full p-4 text-left hover:bg-gray-800 transition-colors ${
                  currentLesson.id === lesson.id ? 'bg-gray-800 border-l-4 border-purple-500' : ''
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-1">
                    {lesson.isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : currentLesson.id === lesson.id ? (
                      <Play className="w-5 h-5 text-purple-500" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-600" />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-gray-500">
                        {index + 1}
                      </span>
                    </div>
                    <h4 className={`text-sm font-medium mb-1 line-clamp-2 ${
                      currentLesson.id === lesson.id ? 'text-purple-400' : 'text-white'
                    }`}>
                      {isRtl ? lesson.titleAr || lesson.title : lesson.title}
                    </h4>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Clock className="w-3 h-3" />
                      <span>{formatDuration(lesson.duration)}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
