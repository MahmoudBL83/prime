/**
 * Modern Creator Dashboard - Complete Rebuild
 * Advanced analytics, course management, earnings tracking, and live session controls
 */

'use client';

import React, { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { toast } from 'react-hot-toast';
import {
  Plus,
  BookOpen,
  Users,
  TrendingUp,
  Video,
  Eye,
  DollarSign,
  Star,
  Calendar,
  Clock,
  Play,
  Edit,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Zap,
  Award,
  MessageSquare,
  Radio,
  BarChart3,
  Sparkles,
  Wallet,
  CreditCard,
  Download,
  Target,
  Flame,
  TrendingDown,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

// Types
interface DashboardStats {
  totalRevenue: number;
  revenueChange: number;
  totalStudents: number;
  studentsChange: number;
  totalCourses: number;
  publishedCourses: number;
  avgRating: number;
  ratingChange: number;
  totalViews: number;
  viewsChange: number;
  watchHours: number;
  watchHoursChange: number;
  activeLiveSessions: number;
  upcomingLiveSessions: number;
}

interface RevenueData {
  total: number;
  categoryA: number;
  categoryB: number;
  categoryC: number;
  pending: number;
  nextPayoutDate: string;
  monthlyTrend: Array<{
    month: string;
    amount: number;
  }>;
}

interface CoursePerformance {
  id: string;
  title: string;
  thumbnail: string;
  enrollments: number;
  revenue: number;
  avgRating: number;
  completionRate: number;
  totalViews: number;
  category: string;
  status: string;
  trend: 'up' | 'down' | 'stable';
}

interface RecentActivity {
  id: string;
  type: 'enrollment' | 'review' | 'question' | 'completion' | 'live_join';
  message: string;
  timestamp: string;
  courseTitle?: string;
  user?: {
    name: string;
    avatar?: string;
  };
}

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  color: string;
}

export default function ModernCreatorDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueData | null>(null);
  const [topCourses, setTopCourses] = useState<CoursePerformance[]>([]);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) {
      router.push('/auth/login');
      return;
    }
    if (session.user.role !== 'CREATOR') {
      toast.error('Access denied. Creator account required.');
      router.push('/dashboard');
      return;
    }
    loadDashboardData();
  }, [session, status, router]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch all dashboard data
      const [statsRes, revenueRes, coursesRes, activityRes] = await Promise.all([
        fetch('/api/creator/dashboard/stats'),
        fetch('/api/creator/dashboard/revenue'),
        fetch('/api/creator/dashboard/top-courses'),
        fetch('/api/creator/dashboard/activity?limit=10'),
      ]);

      if (statsRes.ok) {
        const data = await statsRes.json();
        setStats(data.stats);
      }

      if (revenueRes.ok) {
        const data = await revenueRes.json();
        setRevenueData(data.revenue);
      }

      if (coursesRes.ok) {
        const data = await coursesRes.json();
        setTopCourses(data.courses);
      }

      if (activityRes.ok) {
        const data = await activityRes.json();
        setRecentActivity(data.activities);
      }

    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const quickActions: QuickAction[] = [
    {
      id: 'create-course',
      title: 'Create Course',
      description: 'Start a new course',
      icon: <Plus className="w-5 h-5" />,
      href: '/creator/courses/new',
      color: 'purple',
    },
    {
      id: 'go-live',
      title: 'Go Live',
      description: 'Start streaming',
      icon: <Radio className="w-5 h-5" />,
      href: '/creator/live-studio',
      color: 'red',
    },
    {
      id: 'analytics',
      title: 'Analytics',
      description: 'View detailed insights',
      icon: <BarChart3 className="w-5 h-5" />,
      href: '/creator/analytics',
      color: 'blue',
    },
    {
      id: 'earnings',
      title: 'Earnings',
      description: 'Manage payouts',
      icon: <Wallet className="w-5 h-5" />,
      href: '/creator/earnings',
      color: 'green',
    },
  ];

  if (loading || !stats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400 font-medium">Loading Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                Creator Studio
              </h1>
              <p className="text-gray-400">
                Welcome back, {session?.user?.name}! 👋
              </p>
            </div>
            <button 
              onClick={() => router.push('/creator/courses/new')}
              className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Course
            </button>
          </div>
        </div>

        {/* Key Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Revenue */}
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/5 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-8 h-8 text-purple-400" />
              {stats.revenueChange >= 0 ? (
                <TrendingUp className="w-5 h-5 text-green-400" />
              ) : (
                <TrendingDown className="w-5 h-5 text-red-400" />
              )}
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Total Revenue</h3>
            <p className="text-3xl font-bold text-white mb-2">
              ${stats.totalRevenue.toLocaleString()}
            </p>
            <p className="text-sm">
              {stats.revenueChange >= 0 ? (
                <span className="text-green-400">+{stats.revenueChange.toFixed(1)}%</span>
              ) : (
                <span className="text-red-400">{stats.revenueChange.toFixed(1)}%</span>
              )}
              <span className="text-gray-400 ml-1">vs last month</span>
            </p>
          </div>

          {/* Total Students */}
          <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/5 backdrop-blur-xl border border-blue-500/20 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Users className="w-8 h-8 text-blue-400" />
              {stats.studentsChange >= 0 && <TrendingUp className="w-5 h-5 text-green-400" />}
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Total Students</h3>
            <p className="text-3xl font-bold text-white mb-2">
              {stats.totalStudents.toLocaleString()}
            </p>
            <p className="text-sm">
              {stats.studentsChange >= 0 ? (
                <span className="text-green-400">+{stats.studentsChange.toFixed(1)}%</span>
              ) : (
                <span className="text-red-400">{stats.studentsChange.toFixed(1)}%</span>
              )}
              <span className="text-gray-400 ml-1">new this month</span>
            </p>
          </div>

          {/* Average Rating */}
          <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/5 backdrop-blur-xl border border-yellow-500/20 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Star className="w-8 h-8 text-yellow-400" />
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Average Rating</h3>
            <p className="text-3xl font-bold text-white mb-2">
              {stats.avgRating.toFixed(1)} <span className="text-xl text-gray-400">/ 5.0</span>
            </p>
            <p className="text-sm">
              {stats.ratingChange >= 0 ? (
                <span className="text-green-400">+{stats.ratingChange.toFixed(2)}</span>
              ) : (
                <span className="text-red-400">{stats.ratingChange.toFixed(2)}</span>
              )}
              <span className="text-gray-400 ml-1">from last period</span>
            </p>
          </div>

          {/* Watch Hours */}
          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/5 backdrop-blur-xl border border-green-500/20 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Clock className="w-8 h-8 text-green-400" />
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Watch Hours</h3>
            <p className="text-3xl font-bold text-white mb-2">
              {stats.watchHours.toLocaleString()}h
            </p>
            <p className="text-sm">
              {stats.watchHoursChange >= 0 ? (
                <span className="text-green-400">+{stats.watchHoursChange.toFixed(1)}%</span>
              ) : (
                <span className="text-red-400">{stats.watchHoursChange.toFixed(1)}%</span>
              )}
              <span className="text-gray-400 ml-1">this month</span>
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {quickActions.map((action) => {
            const colorClasses = {
              purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20 hover:border-purple-500/40',
              red: 'from-red-500/10 to-red-500/5 border-red-500/20 hover:border-red-500/40',
              blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20 hover:border-blue-500/40',
              green: 'from-green-500/10 to-green-500/5 border-green-500/20 hover:border-green-500/40',
            };
            const iconColors = {
              purple: 'text-purple-400',
              red: 'text-red-400',
              blue: 'text-blue-400',
              green: 'text-green-400',
            };
            return (
              <button
                key={action.id}
                onClick={() => router.push(action.href)}
                className={`p-6 rounded-2xl bg-gradient-to-br ${colorClasses[action.color as keyof typeof colorClasses]} backdrop-blur-xl border transition-all group text-left`}
              >
                <div className={`${iconColors[action.color as keyof typeof iconColors]} mb-4 group-hover:scale-110 transition-transform`}>
                  {action.icon}
                </div>
                <h3 className="font-semibold text-white mb-1">{action.title}</h3>
                <p className="text-sm text-gray-400">{action.description}</p>
              </button>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Revenue Breakdown (2 columns) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Revenue by Category */}
            {revenueData && (
              <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-purple-400" />
                  Revenue Breakdown
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Category A */}
                  <div className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center gap-2 mb-2">
                      <BookOpen className="w-4 h-4 text-blue-400" />
                      <h3 className="text-gray-400 text-sm">Category A - Library</h3>
                    </div>
                    <p className="text-2xl font-bold text-white mb-2">
                      ${revenueData.categoryA.toLocaleString()}
                    </p>
                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
                        style={{ width: `${(revenueData.categoryA / revenueData.total) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Ad-supported content
                    </p>
                  </div>

                  {/* Category B */}
                  <div className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Star className="w-4 h-4 text-purple-400" />
                      <h3 className="text-gray-400 text-sm">Category B - Signature</h3>
                    </div>
                    <p className="text-2xl font-bold text-white mb-2">
                      ${revenueData.categoryB.toLocaleString()}
                    </p>
                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                        style={{ width: `${(revenueData.categoryB / revenueData.total) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Premium programs
                    </p>
                  </div>

                  {/* Category C */}
                  <div className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/30">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="w-4 h-4 text-green-400" />
                      <h3 className="text-gray-400 text-sm">Category C - Channels</h3>
                    </div>
                    <p className="text-2xl font-bold text-white mb-2">
                      ${revenueData.categoryC.toLocaleString()}
                    </p>
                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                        style={{ width: `${(revenueData.categoryC / revenueData.total) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Membership revenue (85%)
                    </p>
                  </div>
                </div>

                {/* Pending Payout */}
                <div className="mt-6 flex items-center justify-between p-4 bg-gradient-to-br from-yellow-500/10 to-orange-500/5 backdrop-blur-xl border border-yellow-500/20 rounded-xl">
                  <div>
                    <p className="text-sm text-gray-400 mb-1">Pending Payout</p>
                    <p className="text-2xl font-bold text-white">
                      ${revenueData.pending.toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Next payout: {new Date(revenueData.nextPayoutDate).toLocaleDateString()}
                    </p>
                  </div>
                  <button className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white px-6 py-2 rounded-xl font-medium transition-all duration-300 flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Withdraw
                  </button>
                </div>
              </div>
            )}

            {/* Top Performing Courses */}
            <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-400" />
                Top Performing Courses
              </h2>
              <div className="space-y-4">
                {topCourses.map((course, index) => (
                  <div 
                    key={course.id}
                    className="flex items-center gap-4 p-4 rounded-xl bg-gray-800/40 border border-gray-700/30 hover:bg-gray-700/50 transition-colors cursor-pointer"
                    onClick={() => router.push(`/creator/courses/${course.id}`)}
                  >
                    <div className="flex-shrink-0">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-white ${
                        index === 0 ? 'bg-gradient-to-br from-yellow-400 to-orange-500' :
                        index === 1 ? 'bg-gradient-to-br from-gray-400 to-gray-600' :
                        index === 2 ? 'bg-gradient-to-br from-orange-400 to-orange-600' :
                        'bg-gradient-to-br from-blue-400 to-blue-600'
                      }`}>
                        #{index + 1}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-white truncate">{course.title}</h4>
                      <div className="flex items-center gap-3 text-sm text-gray-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {course.enrollments}
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          {course.totalViews}
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-400" />
                          {course.avgRating.toFixed(1)}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-lg font-bold text-green-400">
                        ${course.revenue.toLocaleString()}
                      </span>
                      {course.trend === 'up' && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-400 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          Trending
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar (1 column) */}
          <div className="space-y-6">
            {/* Course Overview */}
            <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-400" />
                Course Overview
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Total Courses</span>
                  <span className="text-2xl font-bold text-white">{stats.totalCourses}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Published</span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-500/10 text-green-400">
                    {stats.publishedCourses}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Draft</span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-gray-500/10 text-gray-400">
                    {stats.totalCourses - stats.publishedCourses}
                  </span>
                </div>
                <button 
                  onClick={() => router.push('/creator/courses')}
                  className="w-full bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-xl font-medium transition-all duration-300"
                >
                  Manage Courses
                </button>
              </div>
            </div>

            {/* Live Sessions */}
            <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Radio className="w-5 h-5 text-red-400" />
                Live Sessions
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Active Now</span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-red-500/10 text-red-400 flex items-center gap-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    {stats.activeLiveSessions}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Upcoming</span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-500/10 text-blue-400">
                    {stats.upcomingLiveSessions}
                  </span>
                </div>
                <button 
                  className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white px-4 py-2 rounded-xl font-medium transition-all duration-300 flex items-center justify-center gap-2"
                  onClick={() => router.push('/creator/live-studio')}
                >
                  <Radio className="w-4 h-4" />
                  Go Live
                </button>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-400" />
                Recent Activity
              </h3>
              <div className="space-y-3">
                {recentActivity.slice(0, 5).map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3 pb-3 border-b border-gray-700/30 last:border-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      activity.type === 'enrollment' ? 'bg-blue-500/10' :
                      activity.type === 'review' ? 'bg-yellow-500/10' :
                      activity.type === 'question' ? 'bg-purple-500/10' :
                      activity.type === 'completion' ? 'bg-green-500/10' :
                      'bg-red-500/10'
                    }`}>
                      {activity.type === 'enrollment' && <Users className="w-4 h-4 text-blue-400" />}
                      {activity.type === 'review' && <Star className="w-4 h-4 text-yellow-400" />}
                      {activity.type === 'question' && <MessageSquare className="w-4 h-4 text-purple-400" />}
                      {activity.type === 'completion' && <CheckCircle className="w-4 h-4 text-green-400" />}
                      {activity.type === 'live_join' && <Radio className="w-4 h-4 text-red-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white">{activity.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(activity.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section - Engagement Metrics */}
        <div className="bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-400" />
            Student Engagement Metrics
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-gray-800/40 rounded-xl border border-gray-700/30">
              <div className="text-3xl font-bold text-blue-400 mb-1">
                {stats.totalViews.toLocaleString()}
              </div>
              <p className="text-sm text-gray-400">Total Views</p>
              <p className="text-xs text-green-400 mt-1">
                +{stats.viewsChange.toFixed(1)}% this month
              </p>
            </div>

            <div className="text-center p-4 bg-gray-800/40 rounded-xl border border-gray-700/30">
              <div className="text-3xl font-bold text-purple-400 mb-1">
                {((stats.watchHours / stats.totalStudents) || 0).toFixed(1)}h
              </div>
              <p className="text-sm text-gray-400">Avg Watch Time</p>
              <p className="text-xs text-gray-500 mt-1">per student</p>
            </div>

            <div className="text-center p-4 bg-gray-800/40 rounded-xl border border-gray-700/30">
              <div className="text-3xl font-bold text-green-400 mb-1">
                {stats.avgRating.toFixed(1)}
              </div>
              <p className="text-sm text-gray-400">Course Rating</p>
              <div className="flex items-center justify-center gap-1 mt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star}
                    className={`w-3 h-3 ${star <= Math.round(stats.avgRating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'}`}
                  />
                ))}
              </div>
            </div>

            <div className="text-center p-4 bg-gray-800/40 rounded-xl border border-gray-700/30">
                <div className="text-3xl font-bold text-orange-400 mb-1">
                  {((stats.publishedCourses / stats.totalCourses) * 100).toFixed(0)}%
                </div>
                <p className="text-sm text-gray-400">Published Rate</p>
                <p className="text-xs text-gray-500 mt-1">
                  {stats.publishedCourses}/{stats.totalCourses} courses
                </p>
              </div>
            </div>
        </div>
      </div>
    </div>
  );
}
