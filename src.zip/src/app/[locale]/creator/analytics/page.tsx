/**
 * Creator Analytics Dashboard
 * Comprehensive analytics based on Business Blueprint Section 3.3
 * 
 * Metrics:
 * - Views, completion, retention charts
 * - Revenue by plan breakdown
 * - Cohort progress tracking
 * - Top posts/content analysis
 * - Churn drivers identification
 * - Engagement metrics
 * - Geographic distribution
 * - Time-series graphs
 */

'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useParams } from 'next/navigation'
import { toast } from 'react-hot-toast'
import {
    BarChart3,
    TrendingUp,
    TrendingDown,
    Users,
    Eye,
    Clock,
    DollarSign,
    Target,
    Award,
    Globe,
    Calendar,
    Download,
    Filter,
    RefreshCw,
    Zap,
    Star,
    PlayCircle,
    CheckCircle,
    XCircle,
    Activity,
    PieChart,
    LineChart
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

type TimeRange = '7d' | '30d' | '90d' | '1y' | 'all'
type MetricType = 'views' | 'revenue' | 'engagement' | 'retention'

interface AnalyticsOverview {
    totalViews: number
    viewsChange: number
    totalRevenue: number
    revenueChange: number
    avgWatchTime: number
    watchTimeChange: number
    completionRate: number
    completionChange: number
    totalStudents: number
    studentsChange: number
    activeStudents: number
    churnRate: number
}

interface RevenueBreakdown {
    categoryA: { amount: number; percentage: number }
    categoryB: { amount: number; percentage: number }
    categoryC: { amount: number; percentage: number }
    totalRevenue: number
    monthlyTrend: Array<{
        month: string
        categoryA: number
        categoryB: number
        categoryC: number
    }>
}

interface CoursePerformance {
    id: string
    title: string
    views: number
    completionRate: number
    avgRating: number
    revenue: number
    enrollments: number
    watchTime: number
    category: string
}

interface GeographicData {
    country: string
    students: number
    revenue: number
    percentage: number
}

interface EngagementMetric {
    date: string
    views: number
    uniqueViewers: number
    avgWatchTime: number
    likes: number
    comments: number
}

export default function AnalyticsPage() {
    const { data: session, status } = useSession()
    const router = useRouter()
    const params = useParams()
    const locale = params.locale as string || 'en'
    const isArabic = locale === 'ar'

    const [loading, setLoading] = useState(true)
    const [timeRange, setTimeRange] = useState<TimeRange>('30d')
    const [selectedMetric, setSelectedMetric] = useState<MetricType>('views')

    const [overview, setOverview] = useState<AnalyticsOverview | null>(null)
    const [revenue, setRevenue] = useState<RevenueBreakdown | null>(null)
    const [topCourses, setTopCourses] = useState<CoursePerformance[]>([])
    const [geoData, setGeoData] = useState<GeographicData[]>([])
    const [engagement, setEngagement] = useState<EngagementMetric[]>([])

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push(`/${locale}/auth/login?callbackUrl=/${locale}/creator/analytics`)
        }
        if (session?.user?.role !== 'CREATOR') {
            toast.error('Access denied. Creator account required.')
            router.push(`/${locale}/dashboard`)
        }
        
        loadAnalytics()
    }, [session, status, router, locale, timeRange])

    const loadAnalytics = async () => {
        try {
            setLoading(true)
            
            const response = await fetch(`/api/creator/analytics?range=${timeRange}`)
            
            if (response.ok) {
                const data = await response.json()
                setOverview(data.overview)
                setRevenue(data.revenue)
                setTopCourses(data.topCourses)
                setGeoData(data.geographic)
                setEngagement(data.engagement)
            } else {
                throw new Error('Failed to load analytics')
            }
        } catch (error) {
            console.error('Analytics error:', error)
            toast.error('Failed to load analytics')
        } finally {
            setLoading(false)
        }
    }

    const exportData = async () => {
        try {
            toast.loading('Preparing export...', { id: 'export' })
            
            const response = await fetch(`/api/creator/analytics/export?range=${timeRange}`)
            
            if (response.ok) {
                const blob = await response.blob()
                const url = window.URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.href = url
                a.download = `analytics-${timeRange}-${Date.now()}.csv`
                document.body.appendChild(a)
                a.click()
                window.URL.revokeObjectURL(url)
                document.body.removeChild(a)
                
                toast.success('Export complete!', { id: 'export' })
            } else {
                throw new Error('Export failed')
            }
        } catch (error) {
            console.error('Export error:', error)
            toast.error('Failed to export data', { id: 'export' })
        }
    }

    const formatNumber = (num: number): string => {
        if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
        if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
        return num.toString()
    }

    const formatCurrency = (amount: number): string => {
        return `$${amount.toLocaleString()}`
    }

    const formatPercentage = (value: number): string => {
        return `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`
    }

    if (status === 'loading' || loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
                <div className="text-center">
                    <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-gray-400 font-medium">Loading Analytics...</p>
                </div>
            </div>
        )
    }

    if (!overview) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
                <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400">No analytics data available</p>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 py-8 px-4" dir={isArabic ? 'rtl' : 'ltr'}>
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                        <div>
                            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 flex items-center gap-2">
                                <BarChart3 className="w-8 h-8 text-purple-400" />
                                {isArabic ? 'تحليلات المنشئ' : 'Creator Analytics'}
                            </h1>
                            <p className="text-gray-400">
                                {isArabic ? 'تتبع أدائك وإيراداتك' : 'Track your performance and revenue'}
                            </p>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex items-center gap-2 bg-gray-800/40 backdrop-blur-xl border border-gray-700/50 rounded-xl p-1">
                                {['7d', '30d', '90d', '1y', 'all'].map((range) => (
                                    <button
                                        key={range}
                                        onClick={() => setTimeRange(range as TimeRange)}
                                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                                            timeRange === range
                                                ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white'
                                                : 'text-gray-400 hover:text-white'
                                        }`}
                                    >
                                        {range === '7d' && 'Last 7 Days'}
                                        {range === '30d' && 'Last 30 Days'}
                                        {range === '90d' && 'Last 90 Days'}
                                        {range === '1y' && 'Last Year'}
                                        {range === 'all' && 'All Time'}
                                    </button>
                                ))}
                            </div>
                            <Button onClick={exportData} variant="outline">
                                <Download className="w-4 h-4 mr-2" />
                                {isArabic ? 'تصدير' : 'Export'}
                            </Button>
                            <Button onClick={loadAnalytics} variant="outline">
                                <RefreshCw className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Key Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    {/* Total Views */}
                    <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/5 backdrop-blur-xl border border-blue-500/20 rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <Eye className="w-8 h-8 text-blue-400" />
                            {overview.viewsChange >= 0 ? (
                                <TrendingUp className="w-5 h-5 text-green-400" />
                            ) : (
                                <TrendingDown className="w-5 h-5 text-red-400" />
                            )}
                        </div>
                        <h3 className="text-gray-400 text-sm font-medium mb-1">
                            {isArabic ? 'إجمالي المشاهدات' : 'Total Views'}
                        </h3>
                        <p className="text-3xl font-bold text-white mb-2">
                            {formatNumber(overview.totalViews)}
                        </p>
                        <p className={`text-sm ${overview.viewsChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {formatPercentage(overview.viewsChange)} {isArabic ? 'من الفترة السابقة' : 'from last period'}
                        </p>
                    </div>

                    {/* Total Revenue */}
                    <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/5 backdrop-blur-xl border border-green-500/20 rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <DollarSign className="w-8 h-8 text-green-400" />
                            {overview.revenueChange >= 0 ? (
                                <TrendingUp className="w-5 h-5 text-green-400" />
                            ) : (
                                <TrendingDown className="w-5 h-5 text-red-400" />
                            )}
                        </div>
                        <h3 className="text-gray-400 text-sm font-medium mb-1">
                            {isArabic ? 'إجمالي الإيرادات' : 'Total Revenue'}
                        </h3>
                        <p className="text-3xl font-bold text-white mb-2">
                            {formatCurrency(overview.totalRevenue)}
                        </p>
                        <p className={`text-sm ${overview.revenueChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {formatPercentage(overview.revenueChange)} {isArabic ? 'من الفترة السابقة' : 'from last period'}
                        </p>
                    </div>

                    {/* Avg Watch Time */}
                    <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/5 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <Clock className="w-8 h-8 text-purple-400" />
                            {overview.watchTimeChange >= 0 && <TrendingUp className="w-5 h-5 text-green-400" />}
                        </div>
                        <h3 className="text-gray-400 text-sm font-medium mb-1">
                            {isArabic ? 'متوسط وقت المشاهدة' : 'Avg Watch Time'}
                        </h3>
                        <p className="text-3xl font-bold text-white mb-2">
                            {Math.floor(overview.avgWatchTime / 60)}:{(overview.avgWatchTime % 60).toString().padStart(2, '0')}
                        </p>
                        <p className={`text-sm ${overview.watchTimeChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {formatPercentage(overview.watchTimeChange)} {isArabic ? 'من الفترة السابقة' : 'from last period'}
                        </p>
                    </div>

                    {/* Completion Rate */}
                    <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/5 backdrop-blur-xl border border-yellow-500/20 rounded-2xl p-6">
                        <div className="flex items-center justify-between mb-4">
                            <CheckCircle className="w-8 h-8 text-yellow-400" />
                            {overview.completionChange >= 0 && <TrendingUp className="w-5 h-5 text-green-400" />}
                        </div>
                        <h3 className="text-gray-400 text-sm font-medium mb-1">
                            {isArabic ? 'معدل الإكمال' : 'Completion Rate'}
                        </h3>
                        <p className="text-3xl font-bold text-white mb-2">
                            {overview.completionRate.toFixed(1)}%
                        </p>
                        <p className={`text-sm ${overview.completionChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {formatPercentage(overview.completionChange)} {isArabic ? 'من الفترة السابقة' : 'from last period'}
                        </p>
                    </div>
                </div>

                {/* Revenue Breakdown & Top Courses Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    {/* Revenue Breakdown */}
                    {revenue && (
                        <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                                <PieChart className="w-5 h-5 text-green-400" />
                                {isArabic ? 'توزيع الإيرادات' : 'Revenue Breakdown'}
                            </h2>
                            
                            <div className="space-y-4 mb-6">
                                {/* Category A */}
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                                            <span className="text-sm text-gray-300">Category A - Library</span>
                                        </div>
                                        <span className="text-sm font-semibold text-white">
                                            {formatCurrency(revenue.categoryA.amount)}
                                        </span>
                                    </div>
                                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                                        <div 
                                            className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
                                            style={{ width: `${revenue.categoryA.percentage}%` }}
                                        />
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {revenue.categoryA.percentage.toFixed(1)}% of total revenue
                                    </p>
                                </div>

                                {/* Category B */}
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                            <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                                            <span className="text-sm text-gray-300">Category B - Signature</span>
                                        </div>
                                        <span className="text-sm font-semibold text-white">
                                            {formatCurrency(revenue.categoryB.amount)}
                                        </span>
                                    </div>
                                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                                        <div 
                                            className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                                            style={{ width: `${revenue.categoryB.percentage}%` }}
                                        />
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {revenue.categoryB.percentage.toFixed(1)}% of total revenue
                                    </p>
                                </div>

                                {/* Category C */}
                                <div>
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                            <span className="text-sm text-gray-300">Category C - Channels</span>
                                        </div>
                                        <span className="text-sm font-semibold text-white">
                                            {formatCurrency(revenue.categoryC.amount)}
                                        </span>
                                    </div>
                                    <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
                                        <div 
                                            className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
                                            style={{ width: `${revenue.categoryC.percentage}%` }}
                                        />
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">
                                        {revenue.categoryC.percentage.toFixed(1)}% of total revenue • 80% after fees
                                    </p>
                                </div>
                            </div>

                            <div className="pt-4 border-t border-gray-700">
                                <div className="flex items-center justify-between">
                                    <span className="text-sm font-semibold text-gray-300">Total Revenue</span>
                                    <span className="text-2xl font-bold text-white">
                                        {formatCurrency(revenue.totalRevenue)}
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Top Performing Courses */}
                    <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <Award className="w-5 h-5 text-yellow-400" />
                            {isArabic ? 'أفضل الدورات أداءً' : 'Top Performing Courses'}
                        </h2>
                        
                        <div className="space-y-3">
                            {topCourses.slice(0, 5).map((course, index) => (
                                <div 
                                    key={course.id}
                                    className="flex items-center gap-4 p-3 rounded-xl bg-gray-700/30 hover:bg-gray-700/50 transition-colors cursor-pointer"
                                    onClick={() => router.push(`/${locale}/creator/courses/${course.id}`)}
                                >
                                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white ${
                                        index === 0 ? 'bg-gradient-to-br from-yellow-400 to-orange-500' :
                                        index === 1 ? 'bg-gradient-to-br from-gray-400 to-gray-600' :
                                        index === 2 ? 'bg-gradient-to-br from-orange-400 to-orange-600' :
                                        'bg-gradient-to-br from-blue-400 to-blue-600'
                                    }`}>
                                        {index + 1}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h4 className="font-medium text-white text-sm truncate">{course.title}</h4>
                                        <div className="flex items-center gap-3 text-xs text-gray-400 mt-1">
                                            <span className="flex items-center gap-1">
                                                <Eye className="w-3 h-3" />
                                                {formatNumber(course.views)}
                                            </span>
                                            <span className="flex items-center gap-1">
                                                <Users className="w-3 h-3" />
                                                {formatNumber(course.enrollments)}
                                            </span>
                                            <span className="flex items-center gap-1">
                                                <Star className="w-3 h-3 text-yellow-400" />
                                                {course.avgRating.toFixed(1)}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-sm font-bold text-green-400">
                                            {formatCurrency(course.revenue)}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            {course.completionRate.toFixed(0)}% complete
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Student Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center">
                                <Users className="w-6 h-6 text-blue-400" />
                            </div>
                            <div>
                                <h3 className="text-sm text-gray-400">Total Students</h3>
                                <p className="text-2xl font-bold text-white">{formatNumber(overview.totalStudents)}</p>
                            </div>
                        </div>
                        <p className={`text-sm ${overview.studentsChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {formatPercentage(overview.studentsChange)} {isArabic ? 'جديد' : 'new students'}
                        </p>
                    </div>

                    <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                                <Activity className="w-6 h-6 text-green-400" />
                            </div>
                            <div>
                                <h3 className="text-sm text-gray-400">Active Students</h3>
                                <p className="text-2xl font-bold text-white">{formatNumber(overview.activeStudents)}</p>
                            </div>
                        </div>
                        <p className="text-sm text-gray-500">
                            {((overview.activeStudents / overview.totalStudents) * 100).toFixed(1)}% of total
                        </p>
                    </div>

                    <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-red-500/10 rounded-xl flex items-center justify-center">
                                <XCircle className="w-6 h-6 text-red-400" />
                            </div>
                            <div>
                                <h3 className="text-sm text-gray-400">Churn Rate</h3>
                                <p className="text-2xl font-bold text-white">{overview.churnRate.toFixed(1)}%</p>
                            </div>
                        </div>
                        <p className="text-sm text-gray-500">
                            {overview.churnRate < 5 ? 'Excellent retention' : overview.churnRate < 10 ? 'Good retention' : 'Needs improvement'}
                        </p>
                    </div>
                </div>

                {/* Geographic Distribution */}
                {geoData && geoData.length > 0 && (
                    <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700/50 rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                            <Globe className="w-5 h-5 text-blue-400" />
                            {isArabic ? 'التوزيع الجغرافي' : 'Geographic Distribution'}
                        </h2>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {geoData.slice(0, 6).map((country) => (
                                <div key={country.country} className="bg-gray-700/30 rounded-xl p-4">
                                    <div className="flex items-center justify-between mb-2">
                                        <h4 className="font-semibold text-white">{country.country}</h4>
                                        <Badge variant="outline" className="text-xs">
                                            {country.percentage.toFixed(1)}%
                                        </Badge>
                                    </div>
                                    <div className="flex items-center justify-between text-sm mb-2">
                                        <span className="text-gray-400">Students</span>
                                        <span className="text-white font-medium">{formatNumber(country.students)}</span>
                                    </div>
                                    <div className="flex items-center justify-between text-sm">
                                        <span className="text-gray-400">Revenue</span>
                                        <span className="text-green-400 font-medium">{formatCurrency(country.revenue)}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}
