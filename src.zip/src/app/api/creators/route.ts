import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url)
        const page = parseInt(searchParams.get('page') || '1')
        const limit = parseInt(searchParams.get('limit') || '12')
        const search = searchParams.get('search')

        const skip = (page - 1) * limit

        // Build where clause for filtering
        const where: any = {}

        if (search) {
            where.OR = [
                { user: { name: { contains: search, mode: 'insensitive' } } },
                { user: { arabicName: { contains: search, mode: 'insensitive' } } },
            ]
        }

        // Fetch creators with user information and stats
        const [creators, total] = await Promise.all([
            prisma.creator.findMany({
                where,
                include: {
                    user: {
                        select: {
                            id: true,
                            name: true,
                            arabicName: true,
                            email: true,
                        },
                    },
                    _count: {
                        select: {
                            courses: true,
                        },
                    },
                },
                orderBy: [
                    { totalSubscribers: 'desc' },
                    { createdAt: 'desc' },
                ],
                skip,
                take: limit,
            }),
            prisma.creator.count({ where }),
        ])

        // Calculate average rating and total students for each creator
        const creatorsWithStats = await Promise.all(
            creators.map(async (creator) => {
                const courses = await prisma.course.findMany({
                    where: { creatorId: creator.id },
                    select: { rating: true, totalEnrollments: true },
                })

                const totalRatings = courses.reduce((sum, course) => sum + course.rating, 0)
                const averageRating = courses.length > 0 ? totalRatings / courses.length : 0
                const totalEnrollments = courses.reduce((sum, course) => sum + course.totalEnrollments, 0)

                return {
                    id: creator.id,
                    user: creator.user,
                    totalCourses: creator._count.courses,
                    totalStudents: totalEnrollments,
                    averageRating,
                    verified: creator.kycStatus === 'APPROVED' as any,
                    createdAt: creator.createdAt,
                }
            })
        )

        return NextResponse.json({
            creators: creatorsWithStats,
            pagination: {
                page,
                limit,
                total: creatorsWithStats.length,
                pages: Math.ceil(creatorsWithStats.length / limit),
            },
        })
    } catch (error) {
        console.error('Creators fetch error:', error)
        return NextResponse.json(
            { error: 'Failed to fetch creators' },
            { status: 500 }
        )
    }
}
