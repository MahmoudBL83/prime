/**
 * GET /api/certificates/[id]
 * Get certificate details by ID
 */

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getCertificate } from '@/services/certificateService';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const certificate = await getCertificate(params.id);

    if (!certificate) {
      return NextResponse.json(
        { error: 'Certificate not found' },
        { status: 404 }
      );
    }

    // Check if user owns the certificate or if it's public
    if (certificate.userId !== session.user.id && !certificate.isPublic) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    return NextResponse.json({
      success: true,
      certificate
    });

  } catch (error: any) {
    console.error('Certificate retrieval error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to retrieve certificate' },
      { status: 500 }
    );
  }
}
