import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    // Fetch all courses with contentCategory 'CATEGORY_B' (Signature/Premium courses)
    const courses = await prisma.course.findMany({
      where: {
        contentCategory: 'CATEGORY_B',
        status: 'PUBLISHED',
      },
      include: {
        creator: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                arabicName: true,
                profileImage: true,
              },
            },
          },
        },
        signatureWorkbook: true,
        signatureCohorts: {
          where: {
            status: 'UPCOMING',
          },
          take: 1,
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    // Transform courses to match the SignatureCourse interface
    const transformedCourses = courses.map((course) => {
      return {
        id: course.id,
        title: course.title,
        titleAr: course.titleAr,
        description: course.description,
        descriptionAr: course.descriptionAr,
        thumbnail: course.thumbnail,
        instructor: {
          name: course.creator.user.name,
          arabicName: course.creator.user.arabicName,
          profileImage: course.creator.user.profileImage,
        },
        duration: `${course.duration}h`,
        enrollmentCount: course.totalEnrollments,
        rating: course.rating,
        ratingCount: Math.floor(course.totalEnrollments * 0.6), // Assume 60% leave ratings
        price: course.price || 0,
        level: course.skillLevel,
        category: course.category,
        categoryAr: course.categoryAr,
        hasWorkbook: !!course.signatureWorkbook,
        hasCohort: course.signatureCohorts.length > 0,
        hasExpertQA: true, // All signature courses have expert Q&A
        hasCapstone: true, // All signature courses have capstone projects
      };
    });

    return NextResponse.json({
      courses: transformedCourses,
      total: transformedCourses.length,
    });
  } catch (error) {
    console.error('Error fetching signature courses:', error);
    return NextResponse.json(
      { error: 'Failed to fetch signature courses' },
      { status: 500 }
    );
  }
}
