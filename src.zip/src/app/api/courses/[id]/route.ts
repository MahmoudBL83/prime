import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(
    req: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const course = await prisma.course.findUnique({
            where: {
                id: id,
                status: 'PUBLISHED',
            },
            include: {
                lessons: {
                    orderBy: {
                        order: 'asc',
                    },
                    select: {
                        id: true,
                        title: true,
                        titleAr: true,
                        description: true,
                        descriptionAr: true,
                        order: true,
                        duration: true,
                        seasonNumber: true,
                        episodeNumber: true,
                        videoUrl: true,
                    },
                },
                creator: {
                    include: {
                        user: {
                            select: {
                                id: true,
                                name: true,
                                arabicName: true,
                                email: true,
                                bio: true,
                                profileImage: true,
                            },
                        },
                    },
                },
            },
        })

        if (!course) {
            return NextResponse.json({ error: 'Course not found' }, { status: 404 })
        }

        // Transform course data for the frontend
        const transformedCourse = {
            ...course,
            currency: 'EGP',
        }

        return NextResponse.json(transformedCourse)
    } catch (error) {
        console.error('Course fetch error:', error)
        return NextResponse.json(
            { error: 'Failed to fetch course' },
            { status: 500 }
        )
    }
}
