import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; lessonId: string }> }
) {
    try {
        const session = await getServerSession(authOptions)

        if (!session) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const courseId = params.id
        const lessonId = params.lessonId

        // Check if user is enrolled in the course
        const enrollment = await prisma.enrollment.findUnique({
            where: {
                userId_courseId: {
                    userId: session.user.id,
                    courseId: courseId
                }
            }
        })

        if (!enrollment) {
            return NextResponse.json({ error: 'Not enrolled in this course' }, { status: 403 })
        }

        // Get current completed lessons or initialize empty array
        const completedLessons = enrollment.completedLessons
            ? JSON.parse(enrollment.completedLessons)
            : []

        // Add lesson to completed lessons if not already there
        if (!completedLessons.includes(lessonId)) {
            completedLessons.push(lessonId)
        }

        // Calculate new progress
        const course = await prisma.course.findUnique({
            where: { id: courseId },
            include: {
                lessons: {
                    select: { id: true }
                }
            }
        })

        if (!course) {
            return NextResponse.json({ error: 'Course not found' }, { status: 404 })
        }

        const totalLessons = course.lessons.length
        const newProgress = Math.round((completedLessons.length / totalLessons) * 100)

        // Update enrollment with completed lessons and progress
        const updatedEnrollment = await prisma.enrollment.update({
            where: {
                id: enrollment.id
            },
            data: {
                completedLessons: JSON.stringify(completedLessons),
                progress: newProgress,
                lastAccessedAt: new Date(),
                // Mark course as completed if all lessons are done
                completedAt: newProgress === 100 ? new Date() : null
            }
        })

        return NextResponse.json({
            success: true,
            isCompleted: true,
            progress: updatedEnrollment.progress,
            message: 'Lesson marked as completed'
        })
    } catch (error) {
        console.error('Error marking lesson as completed:', error)
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
    }
}

export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; lessonId: string }> }
) {
    try {
        const session = await getServerSession(authOptions)

        if (!session) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const courseId = params.id
        const lessonId = params.lessonId

        // Check if user is enrolled in the course
        const enrollment = await prisma.enrollment.findUnique({
            where: {
                userId_courseId: {
                    userId: session.user.id,
                    courseId: courseId
                }
            }
        })

        if (!enrollment) {
            return NextResponse.json({ error: 'Not enrolled in this course' }, { status: 403 })
        }

        // Get current completed lessons
        const completedLessons = enrollment.completedLessons
            ? JSON.parse(enrollment.completedLessons)
            : []

        // Remove lesson from completed lessons
        const updatedCompletedLessons = completedLessons.filter((id: string) => id !== lessonId)

        // Calculate new progress
        const course = await prisma.course.findUnique({
            where: { id: courseId },
            include: {
                lessons: {
                    select: { id: true }
                }
            }
        })

        if (!course) {
            return NextResponse.json({ error: 'Course not found' }, { status: 404 })
        }

        const totalLessons = course.lessons.length
        const newProgress = totalLessons > 0 ? Math.round((updatedCompletedLessons.length / totalLessons) * 100) : 0

        // Update enrollment
        const updatedEnrollment = await prisma.enrollment.update({
            where: {
                id: enrollment.id
            },
            data: {
                completedLessons: JSON.stringify(updatedCompletedLessons),
                progress: newProgress,
                lastAccessedAt: new Date(),
                completedAt: newProgress === 100 ? enrollment.completedAt : null
            }
        })

        return NextResponse.json({
            success: true,
            isCompleted: false,
            progress: updatedEnrollment.progress,
            message: 'Lesson marked as incomplete'
        })
    } catch (error) {
        console.error('Error marking lesson as incomplete:', error)
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
    }
}
