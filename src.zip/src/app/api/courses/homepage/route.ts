import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
    try {
        // Get current date for new releases calculation
        const thirtyDaysAgo = new Date()
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

        // Fetch all published courses with comprehensive data
        const allCourses = await prisma.course.findMany({
            where: {
                status: 'PUBLISHED'
            },
            include: {
                creator: {
                    include: {
                        user: {
                            select: {
                                id: true,
                                name: true,
                                arabicName: true,
                                profileImage: true,
                            },
                        },
                    },
                },
                _count: {
                    select: {
                        enrollments: true,
                        lessons: true,
                        reviews: true
                    }
                },
                lessons: {
                    select: {
                        duration: true
                    }
                }
            },
            orderBy: [
                { totalEnrollments: 'desc' },
                { rating: 'desc' },
                { publishedAt: 'desc' },
            ]
        })

        // Enhanced course processing
        const processedCourses = allCourses.map((course, index) => {
            // Calculate total duration from lessons
            const totalMinutes = course.lessons.reduce((sum, lesson) => sum + (lesson.duration || 0), 0)
            
            const formatDuration = (minutes: number): string => {
                if (minutes < 60) return `${minutes}m`
                const hours = Math.floor(minutes / 60)
                const remainingMinutes = minutes % 60
                if (remainingMinutes === 0) return `${hours}h`
                return `${hours}h ${remainingMinutes}m`
            }

            // Enhanced thumbnail logic with category-specific images
            const getThumbnail = () => {
                if (course.thumbnail) return course.thumbnail
                
                const categoryThumbnails: { [key: string]: string } = {
                    'programming': 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=450&fit=crop&q=80',
                    'design': 'https://images.unsplash.com/photo-1558655146-364adcfd5b5c?w=800&h=450&fit=crop&q=80',
                    'business': 'https://images.unsplash.com/photo-1557838923-2985c318be48?w=800&h=450&fit=crop&q=80',
                    'marketing': 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=450&fit=crop&q=80',
                    'data-science': 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=450&fit=crop&q=80',
                    'ai': 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=450&fit=crop&q=80'
                }
                
                return categoryThumbnails[course.category] || categoryThumbnails['programming']
            }

            // Calculate if course is new (published within last 30 days)
            const isNew = course.publishedAt && course.publishedAt > thirtyDaysAgo

            // Enhanced category display names
            const getCategoryDisplay = (category: string): { name: string, nameAr: string, key: string } => {
                const categories: { [key: string]: { name: string, nameAr: string, key: string } } = {
                    'programming': { name: 'Programming', nameAr: 'البرمجة', key: 'programming' },
                    'design': { name: 'Design', nameAr: 'التصميم', key: 'design' },
                    'business': { name: 'Business', nameAr: 'الأعمال', key: 'business' },
                    'marketing': { name: 'Marketing', nameAr: 'التسويق', key: 'marketing' },
                    'data-science': { name: 'Data Science', nameAr: 'علوم البيانات', key: 'data-science' },
                    'ai': { name: 'Artificial Intelligence', nameAr: 'الذكاء الاصطناعي', key: 'ai' }
                }
                return categories[category] || categories['programming']
            }

            const categoryInfo = getCategoryDisplay(course.category)

            return {
                id: course.id,
                title: course.title,
                titleAr: course.titleAr || course.title,
                type: 'course' as const,
                thumbnail: getThumbnail(),
                duration: formatDuration(totalMinutes),
                rating: Number(course.rating) || 4.5,
                category: categoryInfo.name,
                categoryAr: categoryInfo.nameAr,
                categoryKey: categoryInfo.key,
                isNew: Boolean(isNew),
                isTopRated: Number(course.rating) >= 4.7,
                topPosition: index < 10 ? index + 1 : undefined,
                instructor: course.creator.user.arabicName || course.creator.user.name,
                instructorEn: course.creator.user.name,
                instructorKey: undefined,
                instructorImage: course.creator.user.profileImage,
                description: course.description,
                descriptionAr: course.descriptionAr || course.description,
                price: Number(course.price) || 0,
                studentCount: course._count?.enrollments || 0,
                reviewCount: course._count?.reviews || 0,
                lessonCount: course._count?.lessons || 0,
                difficulty: course.skillLevel as 'beginner' | 'intermediate' | 'advanced' || 'beginner',
                publishedAt: course.publishedAt,
                totalEnrollments: course.totalEnrollments || 0
            }
        })

        // Enhanced course organization
        // Top courses: Best rated with most enrollments
        const topCourses = processedCourses
            .filter(course => course.totalEnrollments > 0 || course.rating >= 4.0)
            .sort((a, b) => {
                // First by rating, then by enrollments
                const ratingDiff = b.rating - a.rating
                if (Math.abs(ratingDiff) > 0.1) return ratingDiff
                return b.totalEnrollments - a.totalEnrollments
            })
            .slice(0, 10)
            .map((course, index) => ({ ...course, topPosition: index + 1 }))

        // New releases: Recently published courses
        const newReleases = processedCourses
            .filter(course => course.isNew || course.publishedAt)
            .sort((a, b) => {
                const dateA = new Date(a.publishedAt || 0).getTime()
                const dateB = new Date(b.publishedAt || 0).getTime()
                return dateB - dateA
            })
            .slice(0, 8)

        // Featured courses: Mix of top-rated and diverse categories
        const featuredCourses = processedCourses
            .sort((a, b) => {
                // Prioritize top-rated courses with good enrollment
                const scoreA = a.rating * 2 + (a.totalEnrollments / 100)
                const scoreB = b.rating * 2 + (b.totalEnrollments / 100)
                return scoreB - scoreA
            })
            .slice(0, 12)

        // Add comprehensive statistics
        const stats = {
            totalCourses: allCourses.length,
            totalEnrollments: processedCourses.reduce((sum, c) => sum + c.totalEnrollments, 0),
            averageRating: processedCourses.reduce((sum, c) => sum + c.rating, 0) / processedCourses.length,
            newCoursesCount: newReleases.length,
            categoriesCount: new Set(processedCourses.map(c => c.categoryKey)).size
        }

        return NextResponse.json({
            topCourses,
            newReleases,
            featuredCourses,
            stats,
            totalCourses: allCourses.length
        });
    } catch (error) {
        console.error('Homepage courses fetch error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch homepage courses' },
            { status: 500 }
        );
    }
}