import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

/**
 * GET /api/creator/earnings
 * Fetch creator earnings dashboard data
 */
export async function GET(request: NextRequest) {
    try {
        const session = await getServerSession(authOptions);

        if (!session || session.user.role !== 'CREATOR') {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const creator = await prisma.creator.findUnique({
            where: { userId: session.user.id },
            include: {
                earnings: {
                    orderBy: { createdAt: 'desc' },
                    take: 100
                },
                creatorPayouts: {
                    orderBy: { requestedAt: 'desc' },
                    take: 20
                },
                courses: {
                    select: {
                        id: true,
                        title: true,
                        titleAr: true,
                        price: true,
                        status: true,
                        contentCategory: true,
                        _count: {
                            select: {
                                enrollments: true
                            }
                        }
                    }
                },
                channels: {
                    select: {
                        id: true,
                        name: true,
                        bronzePrice: true,
                        silverPrice: true,
                        goldPrice: true,
                        _count: {
                            select: {
                                subscriptions: true
                            }
                        }
                    }
                }
            }
        });

        if (!creator) {
            return NextResponse.json({ error: 'Creator profile not found' }, { status: 404 });
        }

        // Calculate current month earnings using period field
        const currentMonth = new Date().toISOString().substring(0, 7) // "2025-10"
        const monthlyEarnings = creator.earnings
            .filter(e => e.period === currentMonth)
            .reduce((sum, e) => sum + e.amount, 0)

        // Calculate last month earnings
        const lastMonth = new Date()
        lastMonth.setMonth(lastMonth.getMonth() - 1)
        const lastMonthStr = lastMonth.toISOString().substring(0, 7)
        const lastMonthEarnings = creator.earnings
            .filter(e => e.period === lastMonthStr)
            .reduce((sum, e) => sum + e.amount, 0)

        // Calculate available balance (total earnings - completed/pending payouts)
        const completedPayouts = creator.creatorPayouts
            .filter(p => p.status === 'COMPLETED')
            .reduce((sum, p) => sum + p.amount, 0)
        
        const pendingPayouts = creator.creatorPayouts
            .filter(p => p.status === 'PENDING' || p.status === 'PROCESSING')
            .reduce((sum, p) => sum + p.amount, 0)

        const availableBalance = creator.totalEarnings - completedPayouts - pendingPayouts

        // Group earnings by type for breakdown
        const earningsByType = creator.earnings.reduce((acc, earning) => {
            acc[earning.sourceType] = (acc[earning.sourceType] || 0) + earning.amount
            return acc
        }, {} as Record<string, number>)

        // Group earnings by month for chart
        const earningsByMonth = creator.earnings.reduce((acc, earning) => {
            acc[earning.period] = (acc[earning.period] || 0) + earning.amount
            return acc
        }, {} as Record<string, number>)

        // Get top earning courses
        const courseEarnings = creator.earnings
            .filter(e => e.sourceType === 'COURSE_ENROLLMENT' || e.sourceType === 'REVENUE_SHARE')
            .reduce((acc, e) => {
                acc[e.sourceId] = (acc[e.sourceId] || 0) + e.amount
                return acc
            }, {} as Record<string, number>)

        const topCourses = Object.entries(courseEarnings)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([courseId, amount]) => {
                const course = creator.courses.find(c => c.id === courseId)
                return {
                    id: courseId,
                    title: course?.title || 'Unknown Course',
                    titleAr: course?.titleAr,
                    earnings: amount,
                    enrollments: course?._count.enrollments || 0,
                    category: course?.contentCategory || 'CATEGORY_A'
                }
            })

        // Calculate growth percentage
        const growth = lastMonthEarnings > 0 
            ? ((monthlyEarnings - lastMonthEarnings) / lastMonthEarnings * 100)
            : monthlyEarnings > 0 ? 100 : 0

        return NextResponse.json({
            success: true,
            data: {
                overview: {
                    totalEarnings: creator.totalEarnings,
                    monthlyEarnings,
                    lastMonthEarnings,
                    availableBalance,
                    pendingPayouts,
                    growth: Math.round(growth * 10) / 10
                },
                breakdown: {
                    courseEnrollment: earningsByType['COURSE_ENROLLMENT'] || 0,
                    channelSubscription: earningsByType['CHANNEL_SUBSCRIPTION'] || 0,
                    meetingBooking: earningsByType['MEETING_BOOKING'] || 0,
                    revenueShare: earningsByType['REVENUE_SHARE'] || 0,
                    bonus: earningsByType['BONUS'] || 0
                },
                earningsByMonth: Object.entries(earningsByMonth)
                    .map(([period, amount]) => ({ period, amount }))
                    .sort((a, b) => a.period.localeCompare(b.period))
                    .slice(-12), // Last 12 months
                topCourses,
                recentEarnings: creator.earnings.slice(0, 10).map(e => ({
                    id: e.id,
                    type: e.sourceType,
                    amount: e.amount,
                    currency: e.currency,
                    period: e.period,
                    breakdown: e.breakdown,
                    createdAt: e.createdAt
                })),
                payoutHistory: creator.creatorPayouts.map(p => ({
                    id: p.id,
                    amount: p.amount,
                    netAmount: p.netAmount,
                    currency: p.currency,
                    status: p.status,
                    method: p.method,
                    requestedAt: p.requestedAt,
                    processedAt: p.processedAt,
                    transactionId: p.transactionId,
                    processingFee: p.processingFee,
                    notes: p.notes
                })),
                stats: {
                    totalCourses: creator.courses.length,
                    activeCourses: creator.courses.filter(c => c.status === 'PUBLISHED').length,
                    totalChannels: creator.channels.length,
                    totalSubscribers: creator.totalSubscribers
                }
            }
        });

    } catch (error) {
        console.error('Error fetching earnings:', error);
        return NextResponse.json(
            { error: 'Failed to fetch earnings data' },
            { status: 500 }
        );
    }
}

/**
 * POST /api/creator/earnings
 * Request a payout withdrawal
 */
export async function POST(request: NextRequest) {
    try {
        const session = await getServerSession(authOptions);

        if (!session || session.user.role !== 'CREATOR') {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await request.json();
        const { amount, method, accountDetails } = body;

        // Validation
        if (!amount || amount <= 0) {
            return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
        }

        if (!method || !['BANK_TRANSFER', 'PAYPAL', 'WALLET', 'VODAFONE_CASH', 'INSTAPAY'].includes(method)) {
            return NextResponse.json({ error: 'Invalid payout method' }, { status: 400 });
        }

        if (!accountDetails) {
            return NextResponse.json({ error: 'Account details required' }, { status: 400 });
        }

        // Get creator and check available balance
        const creator = await prisma.creator.findUnique({
            where: { userId: session.user.id },
            include: {
                creatorPayouts: {
                    where: {
                        status: { in: ['PENDING', 'PROCESSING', 'COMPLETED'] }
                    }
                }
            }
        });

        if (!creator) {
            return NextResponse.json({ error: 'Creator profile not found' }, { status: 404 });
        }

        // Calculate available balance
        const completedPayouts = creator.creatorPayouts
            .filter(p => p.status === 'COMPLETED')
            .reduce((sum, p) => sum + p.amount, 0);
        
        const pendingPayouts = creator.creatorPayouts
            .filter(p => p.status === 'PENDING' || p.status === 'PROCESSING')
            .reduce((sum, p) => sum + p.amount, 0);

        const availableBalance = creator.totalEarnings - completedPayouts - pendingPayouts;

        // Check minimum payout amount (500 EGP per blueprint)
        const MIN_PAYOUT = 500;
        if (amount < MIN_PAYOUT) {
            return NextResponse.json({ 
                error: `Minimum payout amount is ${MIN_PAYOUT} EGP` 
            }, { status: 400 });
        }

        // Check if balance is sufficient
        if (amount > availableBalance) {
            return NextResponse.json({ 
                error: `Insufficient balance. Available: ${availableBalance.toFixed(2)} EGP` 
            }, { status: 400 });
        }

        // Calculate processing fee (2.9% + 2 EGP standard for payment processing)
        const processingFee = (amount * 0.029) + 2;
        const netAmount = amount - processingFee;

        // Create payout request
        const payout = await prisma.creatorPayout.create({
            data: {
                creatorId: creator.id,
                amount,
                currency: 'EGP',
                method,
                accountDetails,
                processingFee,
                netAmount,
                status: 'PENDING'
            }
        });

        return NextResponse.json({
            success: true,
            message: 'Payout request submitted successfully',
            payout: {
                id: payout.id,
                amount: payout.amount,
                netAmount: payout.netAmount,
                processingFee: payout.processingFee,
                method: payout.method,
                status: payout.status,
                requestedAt: payout.requestedAt
            }
        }, { status: 201 });

    } catch (error) {
        console.error('Error requesting payout:', error);
        return NextResponse.json(
            { error: 'Failed to process payout request' },
            { status: 500 }
        );
    }
}
