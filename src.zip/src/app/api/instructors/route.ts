import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
    try {
        // Fetch all instructors with their related data
        const instructors = await prisma.creator.findMany({
            where: {
                kycStatus: 'VERIFIED' // Only show verified instructors
            },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                        arabicName: true,
                        bio: true,
                        profileImage: true,
                        createdAt: true
                    }
                },
                courses: {
                    include: {
                        enrollments: true,
                        lessons: true
                    }
                }
            },
            orderBy: {
                totalSubscribers: 'desc'
            }
        })

        // Fetch followers count separately for each instructor
        const instructorsWithFollowers = await Promise.all(
            instructors.map(async (instructor: any) => {
                const followersCount = await prisma.instructorFollow.count({
                    where: {
                        creatorId: instructor.id
                    }
                })

                const completedMeetings = await prisma.meeting.count({
                    where: {
                        creatorId: instructor.id,
                        status: 'COMPLETED'
                    }
                })

                // Get reviews for instructor's courses
                const reviews = await prisma.review.findMany({
                    where: {
                        courseId: {
                            in: instructor.courses.map((course: any) => course.id)
                        }
                    }
                })

                return {
                    ...instructor,
                    followersCount,
                    completedMeetings,
                    reviews
                }
            })
        )

        // Transform data to include calculated stats
        const instructorsWithStats = instructorsWithFollowers.map((instructor: any) => {
            const totalEnrollments = instructor.courses.reduce((total: number, course: any) => 
                total + course.enrollments.length, 0
            )

            const totalRatings = instructor.reviews.length

            const averageRating = totalRatings > 0 
                ? instructor.reviews.reduce((total: number, review: any) => total + review.rating, 0) / totalRatings
                : 5.0

            // Calculate years of experience (assuming account creation date)
            const yearsOfExperience = Math.max(1, 
                Math.floor((new Date().getTime() - new Date(instructor.user.createdAt).getTime()) / (1000 * 60 * 60 * 24 * 365))
            )

            return {
                id: instructor.id,
                userId: instructor.user.id, // Add the user ID
                user: {
                    id: instructor.user.id, // Include user ID in user object too
                    name: instructor.user.name,
                    arabicName: instructor.user.arabicName || instructor.user.name,
                    bio: instructor.user.bio || 'Experienced professional educator',
                    profileImage: instructor.user.profileImage
                },
                kycStatus: instructor.kycStatus,
                expertise: instructor.expertise || 'Professional Education',
                hourlyRate: instructor.hourlyRate || 0, // Legacy field
                // Subscription pricing (OnlyFans model)
                basicMonthlyPrice: instructor.basicMonthlyPrice,
                basicYearlyPrice: instructor.basicYearlyPrice,
                premiumMonthlyPrice: instructor.premiumMonthlyPrice,
                premiumYearlyPrice: instructor.premiumYearlyPrice,
                vipMonthlyPrice: instructor.vipMonthlyPrice,
                vipYearlyPrice: instructor.vipYearlyPrice,
                totalSubscribers: instructor.totalSubscribers || 0,
                availableForMeetings: instructor.availableForMeetings,
                languages: instructor.languages || 'English, Arabic',
                stats: {
                    totalCourses: instructor.courses.length,
                    totalStudents: totalEnrollments,
                    averageRating: parseFloat(averageRating.toFixed(1)),
                    totalFollowers: instructor.followersCount,
                    yearsOfExperience,
                    completedMeetings: instructor.completedMeetings
                }
            }
        })

        return NextResponse.json({
            success: true,
            instructors: instructorsWithStats,
            total: instructorsWithStats.length
        })

    } catch (error) {
        console.error('Error fetching instructors:', error)
        return NextResponse.json(
            { 
                success: false, 
                message: 'Failed to fetch instructors',
                error: error instanceof Error ? error.message : 'Unknown error'
            },
            { status: 500 }
        )
    }
}